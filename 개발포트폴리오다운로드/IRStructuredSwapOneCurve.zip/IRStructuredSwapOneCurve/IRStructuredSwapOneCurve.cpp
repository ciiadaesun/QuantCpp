#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "HW_Calibration.h"
#include "GetTextDump.h"

#ifndef UTILITY
#include "Util.h"
#endif

#ifndef DateFunction
#include "CalcDate.h"
#endif 
#include "Structure.h"
#include <crtdbg.h>

double rounding_double(double x, long n_decimal)
{
	if (n_decimal == 0)
	{
		return x;
	}
	else
	{
		long i;
		double div = 1.0;
		for (i = 0; i < min(15, n_decimal); i++) div *= 10.0;

		double resultvalue = ceil(x * div) / div;
		return resultvalue;
	}
}

DLLEXPORT(long) NCpnDate_Holiday_2Phase(long PriceDateYYYYMMDD, long SwapMat_YYYYMMDD, long AnnCpnOneYearPhase1, long Phase2UseFlag, long AnnCpnOneYearPhase2, long Phase2Date, long ModifiedFollowing)
{
	if (AnnCpnOneYearPhase1 < 0) AnnCpnOneYearPhase1 = 0;
	if (AnnCpnOneYearPhase2 < 0) AnnCpnOneYearPhase2 = 0;

	long Holidays[1] = { 19500101 };
	long NHoliday = 1;
	long FirstCpnDate = PriceDateYYYYMMDD;
	long LastForwardEndDate = (long)(SwapMat_YYYYMMDD / 100) * 100 + PriceDateYYYYMMDD - (long)(PriceDateYYYYMMDD / 100) * 100;
	if (Phase2UseFlag == 0 || PriceDateYYYYMMDD >= Phase2Date || Phase2Date < 0 || Phase2Date >= SwapMat_YYYYMMDD)
	{
		long NArray = 0;
		long* CpnDate;
		CpnDate = Malloc_CpnDate_Holiday(PriceDateYYYYMMDD, LastForwardEndDate, AnnCpnOneYearPhase1, NArray, FirstCpnDate, NHoliday, Holidays, ModifiedFollowing);
		return NArray;
	}
	else
	{
		long Phase1Maturity;
		long Phase1MaturityYYYY = (Phase2Date / 10000);
		long Phase1MaturityMMDD = LastForwardEndDate - (LastForwardEndDate / 10000) * 10000;
		Phase1Maturity = Phase1MaturityYYYY * 10000 + Phase1MaturityMMDD;
		long NumCpn=0;
		long N1 = 0, N2 = 0;
		long* CpnDate1 = Malloc_CpnDate_Holiday(PriceDateYYYYMMDD, Phase1Maturity, AnnCpnOneYearPhase1, N1, FirstCpnDate, NHoliday, Holidays, ModifiedFollowing);
		long* CpnDate2 = Malloc_CpnDate_Holiday(Phase2Date, LastForwardEndDate, AnnCpnOneYearPhase2, N2, FirstCpnDate, NHoliday, Holidays, ModifiedFollowing);

		NumCpn = N1 + N2;
		free(CpnDate1);
		free(CpnDate2);
		return NumCpn;
	}
}

long* Malloc_CpnDate_Holiday_2Phase(long PriceDateYYYYMMDD, long SwapMat_YYYYMMDD, long AnnCpnOneYearPhase1, long& lenArray, long& FirstCpnDate, long NHoliday, long* HolidayYYYYMMDD, long Phase2UseFlag, long AnnCpnOneYearPhase2, long Phase2Date, long ModifiedFollowing = 1)
{
	long i;
	if (AnnCpnOneYearPhase1 < 0) AnnCpnOneYearPhase1 = 0;
	if (AnnCpnOneYearPhase2 < 0) AnnCpnOneYearPhase2 = 0;

	long LastForwardEndDate = (long)(SwapMat_YYYYMMDD / 100) * 100 + PriceDateYYYYMMDD - (long)(PriceDateYYYYMMDD / 100) * 100;
	if (Phase2UseFlag == 0 || PriceDateYYYYMMDD == Phase2Date || Phase2Date < 0)
	{
		return Malloc_CpnDate_Holiday(PriceDateYYYYMMDD, LastForwardEndDate, AnnCpnOneYearPhase1, lenArray, FirstCpnDate, NHoliday, HolidayYYYYMMDD, ModifiedFollowing);
	}
	else
	{
		long Phase1Maturity;
		long Phase1MaturityYYYY = (Phase2Date / 10000);
		long Phase1MaturityMMDD = LastForwardEndDate - (LastForwardEndDate / 10000) * 10000;
		Phase1Maturity = Phase1MaturityYYYY * 10000 + Phase1MaturityMMDD;
		long NumCpn;
		long N1 = 0, N2 = 0;
		long* CpnDate1 = Malloc_CpnDate_Holiday(PriceDateYYYYMMDD, Phase1Maturity, AnnCpnOneYearPhase1, N1, FirstCpnDate, NHoliday, HolidayYYYYMMDD, ModifiedFollowing);
		long* CpnDate2 = Malloc_CpnDate_Holiday(Phase2Date, LastForwardEndDate, AnnCpnOneYearPhase2, N2, FirstCpnDate, NHoliday, HolidayYYYYMMDD, ModifiedFollowing);

		NumCpn = N1 + N2;
		lenArray = NumCpn;
		long* CpnDateResult = (long*)malloc(sizeof(long) * lenArray);
		for (i = 0; i < N1; i++) CpnDateResult[i] = CpnDate1[i];
		for (i = N1; i < N1 + N2; i++) CpnDateResult[i] = CpnDate2[i - N1];
		free(CpnDate1);
		free(CpnDate2);
		return CpnDateResult;
	}
}

double _stdcall s_2F(
	double sig1,
	double sig2,
	double corr_factor,
	double dt,
	double dx,
	double dy
)
{
	return 0.5 * sig1 * sig2 * corr_factor * dt / (4.0 * dx * dy);
}

double U_i_j(double** U, long i, long j, long N)
{
	if (i < 0 && j < 0)
	{
		return 0.5 * (2.0 * U[0][0] - U[0][1]) + 0.5 * (2.0 * U[0][0] - U[1][0]);
	}
	else if (i < 0 && j == N)
	{
		return 2.0 * U[0][N - 1] - U[1][N - 2];
	}
	else if (i == N && j < 0)
	{
		return 2.0 * U[N - 1][0] - U[N - 2][1];
	}
	else if (i < 0 && j >= 0 && j < N)
	{
		return (2.0 * U[0][j] - U[1][j]);
	}
	else if (i >= 0 && i < N && j < 0)
	{
		return (2.0 * U[i][0] - U[i][1]);
	}
	else if (i == N && j == N)
	{
		return 0.5 * (2.0 * U[N - 1][N - 1] - U[N - 1][N - 2]) + 0.5 * (2.0 * U[N - 1][N - 1] - U[N - 2][N - 1]);
	}
	else if (i == N && j < N)
	{
		return (2.0 * U[N - 1][j] - U[N - 2][j]);
	}
	else if (i < N && j == N)
	{
		return (2.0 * U[i][N - 1] - U[i][N - 2]);
	}
	else return U[i][j];
}

void ResultRHS_2F(
	long NGreed,
	double* x,
	double* y,
	double kappa1,
	double kappa2,
	double sig1,
	double sig2,
	double corr_factor,
	double dx,
	double dy,
	double dt,
	double** Value_2F,
	double** ResultRHS
)
{
	long i, j;
	double u_iu_jd, u_id_ju, u_iu_ju, u_id_jd;
	double s = s_2F(sig1, sig2, corr_factor, dt, dx, dy);

	for (i = 0; i < NGreed; i++)
	{
		for (j = 0; j < NGreed; j++)
		{
			u_iu_ju = U_i_j(Value_2F, i + 1, j + 1, NGreed);
			u_id_jd = U_i_j(Value_2F, i - 1, j - 1, NGreed);
			u_iu_jd = U_i_j(Value_2F, i + 1, j - 1, NGreed);
			u_id_ju = U_i_j(Value_2F, i - 1, j + 1, NGreed);
			ResultRHS[i][j] = s * (u_iu_ju + u_id_jd - u_iu_jd - u_id_ju) + Value_2F[i][j];
		}
	}
}

void Copy2dMatrix(double** CopyResult, double** MyMatrix, long p, long q)
{
	long i, j;
	for (i = 0; i < p; i++) for (j = 0; j < q; j++) CopyResult[i][j] = MyMatrix[i][j];
}

void TransposeMat(
	long N,
	double** Mat
)
{
	long i, j;
	double tempvalue = 0.0;
	for (i = 0; i < N; i++)
	{
		for (j = 0; j < N; j++)
		{
			if (i < j)
			{
				tempvalue = Mat[i][j] + 0.0;
				Mat[i][j] = Mat[j][i];
				Mat[j][i] = tempvalue;
			}
		}
	}
}


//	tri-diagonal ��� �������� ������ Ǭ��.(�ӽ� Array : TempAlpha, TempBeta, TempGamma�� �غ��ؼ� �Ҵ��� �ϴ� �ð� �� �Ҵ� �����ϴ� �ð��� ���ش�.)
//  V_T0����� V_T1[1], V_T1[2], ... , V_T1[N]�� ������� ����ȴ�.
// [[Beta[0], Gamma[0], 0.0,      0.0,       0.0,        ..........      , 0.0]     [V_T0[0]  ]     [V_T1[0]  ]    
//  [Alpha[1],Beta[1],  Gamma[1], 0.0,       0.0,        ..........      , 0.0]     [V_T0[1]  ]     [V_T1[1]  ]
//  [0.0,     Alpha[2], Beta[2],  Gamma[2],  0.0,        ..........      , 0.0]     [V_T0[2]  ]     [V_T1[2]  ]
//  [0.0,     0.0,      Alpha[3], Beta[3],   Gamma[3],   ........        , 0.0]     [V_T0[3]  ]     [V_T1[3]  ]
//  [~~~,     ~~,       ~~~~~,    ~~~,       ~~~~~~,   ........        , ...  ]   x [     ..  ]  =  [   ..    ]
//  [0.0,     0.0,      .....     Alpha[N-3],Beta[N-3],  Gamma[N-3],       0.0]     [V_T0[N-3]]     [V_T1[N-3]]
//  [0.0,     0.0,      .....,    0.0,       Alpha[N-2], Beta[N-2], Gamma[N-2]]     [V_T0[N-2]]     [V_T1[N-2]]
//  [0.0,     0.0,      .....,    0.0,       0.0,        Alpha[N-1], Beta[N-1]]]    [V_T0[N-1]]     [V_T1[N-1]]
long Tri_diagonal_Matrix_Fast(
	double* Alpha,    // Tridiagonal Matrix���� ���� �밢�� ���
	double* Beta,     // Tridiagonal Matrix���� �߾� �밢�� ���
	double* Gamma,    // Tridiagonal Matrix���� ������ �밢�� ���
	double** V_T1,     // V(T1)
	long N,           // �밢�� ��ĵ��� ����
	double* TempAlpha,// �ӽ� ���1 
	double* TempBeta, // �ӽ� ���2
	double* TempGamma // �ӽ� ���3
)
{
	long i;
	long j;
	for (j = 0; j < N; j++)
	{
		for (i = 0; i <= N - 1; i++)
		{
			TempAlpha[i] = Alpha[i];
			TempBeta[i] = Beta[i];
			TempGamma[i] = Gamma[i];
		}

		TempAlpha[0] = 0.0;
		TempGamma[N - 1] = 0.0;

		if (N <= 1) V_T1[0][j] /= TempBeta[0];
		else {
			for (i = 1; i <= N - 1; i++) {
				TempAlpha[i] /= TempBeta[i - 1];
				TempBeta[i] -= TempAlpha[i] * TempGamma[i - 1];
				V_T1[i][j] -= TempAlpha[i] * V_T1[i - 1][j];
			}
			V_T1[N - 1][j] /= TempBeta[N - 1];

			for (i = N - 2; i >= 0; i--) V_T1[i][j] = (V_T1[i][j] - TempGamma[i] * V_T1[i + 1][j]) / TempBeta[i];
		}
	}

	return 1;
}

double B_s_to_t(
	double kappa,
	double s,
	double t
)
{
	return (1.0 - exp(-kappa * (t - s))) / kappa;
}

double V_t_T(
	double kappa,
	double kappa2,
	double t,
	double T,
	double vol,
	double vol2
)
{
	return vol * vol2 / (kappa * kappa2) * (T - t + (exp(-kappa * (T - t)) - 1.0) / kappa + (exp(-kappa2 * (T - t)) - 1.0) / kappa2 - (exp(-(kappa + kappa2) * (T - t)) - 1.0) / (kappa + kappa2));
}

double V_t_T(double k1, double k2, double t, double T,
	double* tVol1, double* Vol1, long nVol1,
	double* tVol2, double* Vol2, long nVol2)
{
	long NInteg = 10;
	double RHS = 0.0;
	double du = (T - t) / (double)NInteg;
	double u, v1, v2, term;
	for (long i = 0; i < NInteg; i++)
	{
		u = t + du * (i + 0.5);
		v1 = Interpolate_Linear(tVol1, Vol1, nVol1, u);
		v2 = Interpolate_Linear(tVol2, Vol2, nVol2, u);

		term = v1 * v2 * (1.0 - exp(-k1 * (T - u))) / k1 * (1.0 - exp(-k2 * (T - u))) / k2 * du;
		RHS += term;
	}
	return RHS;
}

double HullWhiteQVTerm(
	double t,
	double T,
	double kappa,
	long NHWVol,
	double* HWVolTerm,
	double* HWVol
)
{
	double vol;
	double RHS = 0.0;
	double V_1, V_2, V_3;

	if (NHWVol == 1 || kappa > 0.1)
	{
		vol = Interpolate_Linear(HWVolTerm, HWVol, NHWVol, (t + T) / 2.);
		V_1 = V_t_T(kappa, kappa, t, T, vol, vol);
		V_2 = V_t_T(kappa, kappa, 0, T, vol, vol);
		V_3 = V_t_T(kappa, kappa, 0, t, vol, vol);
		RHS = 0.5 * (V_1);
	}
	else
	{
		V_1 = V_t_T(kappa, kappa, t, T, HWVolTerm, HWVol, NHWVol, HWVolTerm, HWVol, NHWVol);
		V_2 = V_t_T(kappa, kappa, 0, T, HWVolTerm, HWVol, NHWVol, HWVolTerm, HWVol, NHWVol);
		V_3 = V_t_T(kappa, kappa, 0, t, HWVolTerm, HWVol, NHWVol, HWVolTerm, HWVol, NHWVol);
		//RHS = 0.5 * (V_1 - V_2 + V_3);
		//RHS = 0.;
		//long NInteg = 10;
		//double u = t;
		//double du = (T - t) / ((double)NInteg);
		//double Bst = 0., BsT = 0.;
		//for (i = 0; i < NInteg; i++)
		//{
		//	vol = Interpolate_Linear(HWVolTerm, HWVol, NHWVol, u);
		//	Bst = B_s_to_t(kappa, u, t);
		//	BsT = B_s_to_t(kappa, u, T);
		//	RHS += 0.5 * vol * vol * (Bst * Bst - BsT * BsT) * du;
		//	u = u + du;
		//}
		RHS = 0.5 * (V_1);
	}
	return RHS;
}

double HullWhite2F_CrossTerm(
	double t,
	double T,
	double kappa,
	long NHWVol,
	double* HWVolTerm,
	double* HWVol,
	double kappa2,
	double* HWVolTerm2,
	double* HWVol2,
	double rho
)
{
	double vol, vol2;
	double RHS = 0.0;
	double V_1, V_2, V_3;

	if (NHWVol == 1 || kappa > 0.1)
	{
		vol = Interpolate_Linear(HWVolTerm, HWVol, NHWVol, (t + T) / 2.);
		vol2 = Interpolate_Linear(HWVolTerm2, HWVol2, NHWVol, (t + T) / 2.);
		V_1 = V_t_T(kappa, kappa2, t, T, vol, vol2);
		V_2 = V_t_T(kappa, kappa2, 0, T, vol, vol2);
		V_3 = V_t_T(kappa, kappa2, 0, t, vol, vol2);
		RHS = 2.0 * rho * 0.5 * (V_1);
	}
	else
	{
		V_1 = V_t_T(kappa, kappa2, t, T, HWVolTerm, HWVol, NHWVol, HWVolTerm2, HWVol2, NHWVol);
		V_2 = V_t_T(kappa, kappa2, 0, T, HWVolTerm, HWVol, NHWVol, HWVolTerm2, HWVol2, NHWVol);
		V_3 = V_t_T(kappa, kappa2, 0, t, HWVolTerm, HWVol, NHWVol, HWVolTerm2, HWVol2, NHWVol);
		RHS = 2.0 * rho * 0.5 * (V_1);
	}
	return RHS;
}

double HW_Rate(
	long ReferenceType,
	long NRateTerm,
	double* RateTerm,
	double* Rate,
	double ShortRate,
	long NCfSwap,
	long NCPN_Ann,
	double* PV_t_T,
	double* QVTerm,
	double* B_t_T,
	double* dt,
	long HW2FFlag,
	double ShortRate2F,
	double* QVTerm_2F,
	double* B_t_T_2F,
	double* CrossTerm_2F
)
{
	long i;
	double PtT;
	double term = 1.0 / ((double)NCPN_Ann);
	double ResultRate;
	double B;
	if (ReferenceType == 0) NCfSwap = 1;
	if (NCPN_Ann > 0)
	{
		B = 0.0;
		for (i = 0; i < NCfSwap; i++)
		{
			term = dt[i];
			PtT = PV_t_T[i] * exp(-ShortRate * B_t_T[i] + QVTerm[i]);
			if (HW2FFlag > 0) PtT = PtT * exp(-ShortRate2F * B_t_T_2F[i] + QVTerm_2F[i] + CrossTerm_2F[i]);
			B += term * PtT;
		}

		ResultRate = (1. - PtT) / B;
	}
	else
	{
		PtT = PV_t_T[0] * exp(-ShortRate * B_t_T[0] + QVTerm[0]);
		if (HW2FFlag > 0) PtT = PtT * exp(-ShortRate2F * B_t_T_2F[0] + QVTerm_2F[0] + CrossTerm_2F[0]);

		if (dt[0] < 1.0) ResultRate = (1.0 - PtT) / (dt[0] * PtT);
		else ResultRate = -1.0 / dt[0] * log(PtT);
	}

	return ResultRate;
}

long CountModRange(long start, long end, long mod, long remainder)
{
	// [start, end) �������� x % mod == remainder ����
	return (end - 1 - remainder) / mod
		- (start - 1 - remainder) / mod;
}

double DayCountFractionAtoB(long Day1, long Day2, long Flag)
{
	long i;
	double tau;
	double Div;
	long YearA, YearB;
	long MonthA, MonthB;
	long nMonth;

	if (Day1 < 19000000 && Day2 < 19000000)
	{
		Day1 = ExcelDateToCDate(Day1);
		Day2 = ExcelDateToCDate(Day2);
	}

	if (Flag == 0) return DayCountAtoB(Day1, Day2) / 365.0;
	else if (Flag == 1) return DayCountAtoB(Day1, Day2) / 360.;
	else if (Flag == 2)
	{
		long DayA, DayB;
		long CurrentY;
		long NextY;

		YearA = Day1 / 10000;
		MonthA = (Day1 - YearA * 10000) / 100;
		DayA = (Day1 - YearA * 10000 - MonthA * 100);

		YearB = Day2 / 10000;
		MonthB = (Day2 - YearB * 10000) / 100;
		DayB = (Day2 - YearB * 10000 - MonthB * 100);

		NextY = Day1 + 10000;
		if (Day2 > Day1 && Day2 < NextY)
		{
			Div = DayCountAtoB(Day1, NextY);
			return DayCountAtoB(Day1, Day2) / Div;
		}
		else
		{
			tau = 0.;
			for (i = 0; i <= YearB - YearA; i++)
			{
				CurrentY = Day1 + i * 10000;
				NextY = Day1 + (i + 1) * 10000;
				if (Day2 > CurrentY && Day2 <= NextY)
				{
					Div = DayCountAtoB(CurrentY, NextY);
					tau += DayCountAtoB(CurrentY, Day2) / Div;
					break;
				}
				else
				{
					tau += 1.0;
				}
			}
			return tau;
		}
	}
	else if (Flag == 3)
	{
		YearA = Day1 / 10000;
		MonthA = (Day1 - YearA * 10000) / 100;

		YearB = Day2 / 10000;
		MonthB = (Day2 - YearB * 10000) / 100;

		nMonth = (YearB - YearA) * 12 + (MonthB - MonthA);
		return ((double)30. * (nMonth)) / 360.0;
	}
	else
	{
		long ExcelEndDate;
		long ExcelDate1 = CDateToExcelDate(Day1);
		long ExcelDate2 = CDateToExcelDate(Day2);
		long nDayExceptWeekend = ExcelDate2 - ExcelDate1 - (CountModRange(ExcelDate1, ExcelDate2, 7, 0) + CountModRange(ExcelDate1, ExcelDate2, 7, 1));
		double nDayDiv;
		long nAvg;
		YearA = Day1 / 10000;
		MonthA = (Day1 - YearA * 10000) / 100;

		YearB = Day2 / 10000;
		MonthB = (Day2 - YearB * 10000) / 100;
		if (YearA == YearB)
		{
			ExcelEndDate = CDateToExcelDate(Day1 + 10000);
			nDayDiv = (double)(ExcelEndDate - ExcelDate1 - (CountModRange(ExcelDate1, ExcelEndDate, 7, 0) + CountModRange(ExcelDate1, ExcelEndDate, 7, 1)));
			return ((double)nDayExceptWeekend) / nDayDiv;
		}
		else
		{
			if (MonthA < MonthB)
			{
				ExcelEndDate = CDateToExcelDate(Day1 + (YearB - YearA + 1) * 10000);
				nDayDiv = (double)(ExcelEndDate - ExcelDate1 - (CountModRange(ExcelDate1, ExcelEndDate, 7, 0) + CountModRange(ExcelDate1, ExcelEndDate, 7, 1))) / ((double)(YearB - YearA + 1));
			}
			else 
			{
				ExcelEndDate = CDateToExcelDate(Day1 + (YearB - YearA) * 10000);
				nDayDiv = (double)(ExcelEndDate - ExcelDate1 - (CountModRange(ExcelDate1, ExcelEndDate, 7, 0) + CountModRange(ExcelDate1, ExcelEndDate, 7, 1))) / ((double)(YearB - YearA));
			}
			return ((double)nDayExceptWeekend) / nDayDiv;
		}
	}
}

DLLEXPORT(long) IRStructuredSwapFDM(
	long PriceDate,							// PricingDate As YYYYMMDD
	long EffectiveDate,						// EffeciveDate As YYYYMMDD
	long Maturity,							// Maturity As YYYYMMDD
	long NAFlag,							// Notional Use Flag
	double NA,								// Notional Amount

	long* NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
	long* AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
	long* NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
	long* NumCpnAnn,						// Number Coupon of 1y (len = 2)
	double* MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

	double* MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
	long* DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
	long* PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
	double* RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
	double* InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

	double RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
	double RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
	long RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
	double PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
	double PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

	long PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
	long Phase2UseFlag,						// Phase2UseFlag
	long Phase2Date,						// Phase2Date
	double Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
	double Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

	long Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
	double Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
	double Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
	long Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
	long* NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

	long NOption,							// Number of Option
	long* OptionDate,						// OptionDateArray As YYYYMMDD
	long* OptionPayDate,					// OptionPayDateArray
	long OptionType,						// 0 : Payer have option, 1: Receiver
	long NRcvRateHistory,					// Number of RcvRate History

	long* RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
	double* RcvRateHistory,					// Rcv FixingRate History Array
	long NPayRateHistory,					// Number of RcvRate History
	long* PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
	double* PayRateHistory,					// Pay FixingRate History Array

	long NZeroRate,
	double* ZeroTerm,
	double* ZeroRate,
	long NZeroDiscRate,
	double* ZeroDiscTerm,

	double* ZeroDiscRate,
	long HW2FFlag,
	long NHWVol,
	double* HWVolTerm,
	double* HWVol,

	double* kappa,
	double FactorCorrelation,
	long* RangeAccrualFlagRcvPay,
	long* InterestRateRoundingRcvPay,
	long* ResultCpnDateRcv,

	long* ResultCpnDatePay,
	double* ResultFixingRateCpn,
	long TextFlag
)
{
	if (PriceDate < 19000101) PriceDate = ExcelDateToCDate(PriceDate);
	if (Maturity < 19000101) Maturity = ExcelDateToCDate(Maturity);
	if (EffectiveDate < 19000101) EffectiveDate = ExcelDateToCDate(EffectiveDate);
	if (Phase2Date < 19000101) Phase2Date = ExcelDateToCDate(Phase2Date);
	long i, j, k, n;
	double w1, w2;
	for (i = 0; i < NAdditionalHolidays[0] + NAdditionalHolidays[1]; i++) if (AdditionalHolidays[i] < 19000101) AdditionalHolidays[i] = ExcelDateToCDate(AdditionalHolidays[i]);
	for (i = 0; i < NOption; i++) if (OptionDate[i] < 19000101) OptionDate[i] = ExcelDateToCDate(OptionDate[i]);
	for (i = 0; i < NOption; i++) if (OptionPayDate[i] < 19000101) OptionPayDate[i] = ExcelDateToCDate(OptionPayDate[i]);
	for (i = 0; i < NRcvRateHistory; i++) if (RcvRateHistoryDate[i] < 19000101) RcvRateHistoryDate[i] = ExcelDateToCDate(RcvRateHistoryDate[i]);
	for (i = 0; i < NPayRateHistory; i++) if (PayRateHistoryDate[i] < 19000101) PayRateHistoryDate[i] = ExcelDateToCDate(PayRateHistoryDate[i]);
	char CalcFunctionName[] = "IRStructuredSwapFDM";
	char SaveFileName[100];
	long RoundingRcv = InterestRateRoundingRcvPay[0];
	long RoundingPay = InterestRateRoundingRcvPay[1];
	get_filenameYYYYMMDD(SaveFileName, 100, CalcFunctionName);
	if (TextFlag > 0)
	{
		DumppingTextData(CalcFunctionName, SaveFileName, "PriceDate", PriceDate);
		DumppingTextData(CalcFunctionName, SaveFileName, "EffectiveDate", EffectiveDate);
		DumppingTextData(CalcFunctionName, SaveFileName, "Maturity", Maturity);
		DumppingTextData(CalcFunctionName, SaveFileName, "NAFlag", NAFlag);
		DumppingTextData(CalcFunctionName, SaveFileName, "NA", NA);

		DumppingTextDataArray(CalcFunctionName, SaveFileName, "NAdditionalHolidays", 2, NAdditionalHolidays);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "AdditionalHolidays", NAdditionalHolidays[0] + NAdditionalHolidays[1], AdditionalHolidays);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "NationFlag", 2, NationFlag);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "NumCpnAnn", 2, NumCpnAnn);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "MaxLossRetRcvPay", 4, MaxLossRetRcvPay);

		DumppingTextDataArray(CalcFunctionName, SaveFileName, "MultipleRatefixPayoffRcvPay", 4, MultipleRatefixPayoffRcvPay);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "DayCountRcvPay", 2, DayCountRcvPay);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "PowerSpreadFlagRcvPay", 2, PowerSpreadFlagRcvPay);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "RangeMaxMinRcvPay", 4, RangeMaxMinRcvPay);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "InfoRefRateRcvPay", 8, InfoRefRateRcvPay);

		DumppingTextData(CalcFunctionName, SaveFileName, "RcvLegFixedRate", RcvLegFixedRate);
		DumppingTextData(CalcFunctionName, SaveFileName, "RcvLegRangeCoupon", RcvLegRangeCoupon);
		DumppingTextData(CalcFunctionName, SaveFileName, "RcvLegStructuredFlag", RcvLegStructuredFlag);
		DumppingTextData(CalcFunctionName, SaveFileName, "PayLegFixedRate", PayLegFixedRate);
		DumppingTextData(CalcFunctionName, SaveFileName, "PayLegRangeCoupon", PayLegRangeCoupon);

		DumppingTextData(CalcFunctionName, SaveFileName, "PayLegStructuredFlag", PayLegStructuredFlag);
		DumppingTextData(CalcFunctionName, SaveFileName, "Phase2UseFlag", Phase2UseFlag);
		DumppingTextData(CalcFunctionName, SaveFileName, "Phase2Date", Phase2Date);
		DumppingTextData(CalcFunctionName, SaveFileName, "Phase2RcvLegFixedRate", Phase2RcvLegFixedRate);
		DumppingTextData(CalcFunctionName, SaveFileName, "Phase2RcvLegRangeCoupon", Phase2RcvLegRangeCoupon);

		DumppingTextData(CalcFunctionName, SaveFileName, "Phase2RcvLegStructuredFlag", Phase2RcvLegStructuredFlag);
		DumppingTextData(CalcFunctionName, SaveFileName, "Phase2PayLegFixedRate", Phase2PayLegFixedRate);
		DumppingTextData(CalcFunctionName, SaveFileName, "Phase2PayLegRangeCoupon", Phase2PayLegRangeCoupon);
		DumppingTextData(CalcFunctionName, SaveFileName, "Phase2PayLegStructuredFlag", Phase2PayLegStructuredFlag);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "NumCpnAnnPhase2RcvPay", 2, NumCpnAnnPhase2RcvPay);

		DumppingTextData(CalcFunctionName, SaveFileName, "NOption", NOption);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "OptionDate", NOption, OptionDate);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "OptionDate", NOption, OptionPayDate);
		DumppingTextData(CalcFunctionName, SaveFileName, "OptionType", OptionType);
		DumppingTextData(CalcFunctionName, SaveFileName, "NRcvRateHistory", NRcvRateHistory);

		DumppingTextDataArray(CalcFunctionName, SaveFileName, "RcvRateHistoryDate", NRcvRateHistory, RcvRateHistoryDate);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "RcvRateHistoryDate", NRcvRateHistory, RcvRateHistory);
		DumppingTextData(CalcFunctionName, SaveFileName, "NPayRateHistory", NPayRateHistory);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "PayRateHistoryDate", NPayRateHistory, PayRateHistoryDate);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "PayRateHistoryDate", NPayRateHistory, PayRateHistory);

		DumppingTextData(CalcFunctionName, SaveFileName, "NZeroRate", NZeroRate);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "ZeroTerm", NZeroRate, ZeroTerm);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "ZeroRate", NZeroRate, ZeroRate);
		DumppingTextData(CalcFunctionName, SaveFileName, "NZeroDiscRate", NZeroDiscRate);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "ZeroDiscTerm", NZeroDiscRate, ZeroDiscTerm);

		DumppingTextDataArray(CalcFunctionName, SaveFileName, "ZeroDiscRate", NZeroDiscRate, ZeroDiscRate);
		DumppingTextData(CalcFunctionName, SaveFileName, "HW2FFlag", HW2FFlag);
		DumppingTextData(CalcFunctionName, SaveFileName, "NHWVol", NHWVol);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "HWVolTerm", NHWVol, HWVolTerm);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "HWVol", NHWVol * 2, HWVol);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "kappa", 2, kappa);
		DumppingTextData(CalcFunctionName, SaveFileName, "FactorCorrelation", FactorCorrelation);
		DumppingTextDataArray(CalcFunctionName, SaveFileName, "InterestRateRoundingRcvPay", 2, InterestRateRoundingRcvPay);
	}
	long BondFlag = NAFlag < 0;
	if (BondFlag == 1) NAFlag = 1;

	long idx1, idx2;
	long RcvRangeAccrualFlag = RangeAccrualFlagRcvPay[0] > 0;
	long PayRangeAccrualFlag = RangeAccrualFlagRcvPay[1] > 0;
	long NHist;

	long NGreed = 100;

	long PowerSpreadFlagRcv = PowerSpreadFlagRcvPay[0];
	long PowerSpreadFlagPay = PowerSpreadFlagRcvPay[1];

	double* InfoRefRateRcv = InfoRefRateRcvPay;
	double* InfoRefRatePay = InfoRefRateRcvPay + 4;

	double* MaxLossRetRcv = MaxLossRetRcvPay;
	double* MaxLossRetPay = MaxLossRetRcvPay + 2;

	double* MultipleRatefixPayoffRcv = MultipleRatefixPayoffRcvPay;
	double* MultipleRatefixPayoffPay = MultipleRatefixPayoffRcvPay + 2;

	double* RangeMaxMinRcv = RangeMaxMinRcvPay;
	double* RangeMaxMinPay = RangeMaxMinRcvPay + 2;

	double NCPN_ANN_Rcv = InfoRefRateRcv[0];
	double Maturity_Rcv = InfoRefRateRcv[1];
	double Maturity1_Rcv = InfoRefRateRcv[2];
	double Maturity2_Rcv = InfoRefRateRcv[3];

	double NCPN_ANN_Pay = InfoRefRatePay[0];
	double Maturity_Pay = InfoRefRatePay[1];
	double Maturity1_Pay = InfoRefRatePay[2];
	double Maturity2_Pay = InfoRefRatePay[3];

	if (BondFlag == 1)
	{
		PowerSpreadFlagPay = PowerSpreadFlagRcv;
		MultipleRatefixPayoffPay[0] = 0.;
		MultipleRatefixPayoffPay[1] = 0.;
		MaxLossRetRcvPay[0] = 1.;
		MaxLossRetRcvPay[1] = 1.;
		DayCountRcvPay[1] = 0;
		PowerSpreadFlagRcvPay[1] = 0;
		RangeMaxMinPay[0] = 1.;
		RangeMaxMinPay[1] = -1.;
		NCPN_ANN_Pay = NCPN_ANN_Rcv;
		Maturity_Pay = Maturity_Rcv;
		Maturity1_Pay = Maturity1_Rcv;
		Maturity2_Pay = Maturity2_Rcv;
	}

	double kappa1 = kappa[0];
	double kappa2;
	double ResultValue = 0.;

	if (HW2FFlag > 0) kappa2 = kappa[1];
	else kappa2 = kappa[0];
	double* HWVol2 = HWVol + NHWVol;

	long NTotalHoliday[2] = { 0, 0 };
	long** TotalHolidays = (long**)malloc(sizeof(long*) * 2);															// �Ҵ�1
	long nsum = 0;
	long NCpnDate[2] = { 0, 0 };
	long** CpnDate = (long**)malloc(sizeof(long*) * 2);																	// �Ҵ�2
	long** CpnPayDate = (long**)malloc(sizeof(long*) * 2);																// �Ҵ�3

	long TempDate = PriceDate;
	long* TempHoliday;
	long NTempHoliday;
	long LastForwardEndDate = (long)(Maturity / 100) * 100 + EffectiveDate - (long)(EffectiveDate / 100) * 100;
	
	long TempExcelDate, TempYYYYMMDD;
	long NBD = 0;
	long NBDFromEndToPay = 0;
	long HolidayFlag, SaturSundayFlag;
	for (n = 0; n < 2; n++)
	{
		if (NationFlag[n] < 0)
		{
			NTotalHoliday[n] = NAdditionalHolidays[n];
			TotalHolidays[n] = (long*)malloc(sizeof(long) * max(1, NTotalHoliday[n]));
			TempHoliday = (long*)malloc(sizeof(long) * 1);
		}
		else
		{
			NTempHoliday = 0;
			NTempHoliday = Number_Holiday(EffectiveDate / 10000, Maturity / 10000 + 1, NationFlag[n]);
			TempHoliday = (long*)malloc(sizeof(long) * max(1, NTempHoliday));
			Mapping_Holiday_CType(EffectiveDate / 10000, Maturity / 10000 + 1, NationFlag[n], NTempHoliday, TempHoliday);
			NTotalHoliday[n] = NTempHoliday + NAdditionalHolidays[n];
			TotalHolidays[n] = (long*)malloc(sizeof(long) * max(1, NTotalHoliday[n]));
			for (i = 0; i < NTempHoliday; i++) TotalHolidays[n][i] = TempHoliday[i];
			for (i = 0; i < NAdditionalHolidays[n]; i++) TotalHolidays[n][i + NTempHoliday] = (AdditionalHolidays + nsum)[i];
		}
		NBD = NBusinessCountFromEndToPay(EffectiveDate, Maturity, TotalHolidays[n], NTotalHoliday[n], 1, &LastForwardEndDate);
		//CpnDate[n] = Malloc_CpnDate_Holiday(EffectiveDate, LastForwardEndDate, NumCpnAnn[n], NCpnDate[n], TempDate, NTotalHoliday[n], TotalHolidays[n], 1);
		CpnDate[n] = Malloc_CpnDate_Holiday_2Phase(EffectiveDate, LastForwardEndDate, NumCpnAnn[n], NCpnDate[n], TempDate, NTotalHoliday[n], TotalHolidays[n], Phase2UseFlag, NumCpnAnnPhase2RcvPay[n], Phase2Date);
		CpnPayDate[n] = (long*)malloc(sizeof(long) * NCpnDate[n]);
		NBD = 0;
		if (CpnDate[n][NCpnDate[n] - 1] >= Maturity) NBD = 0;
		else
		{
			TempExcelDate = CDateToExcelDate(CpnDate[n][NCpnDate[n] - 1]);
			for (i = 0; i < 100; i++)
			{
				TempExcelDate = TempExcelDate + 1;
				TempYYYYMMDD = ExcelDateToCDate(TempExcelDate);
				SaturSundayFlag = (TempExcelDate % 7 == 1 || TempExcelDate % 7 == 0);
				HolidayFlag = isin_Longtype(TempYYYYMMDD, TotalHolidays[n], NTotalHoliday[n]);
				if (SaturSundayFlag == 0 && HolidayFlag == 0) NBD += 1;

				if (TempYYYYMMDD >= Maturity)
				{
					break;
				}
			}
		}

		NBDFromEndToPay = NBD;
		for (i = 0; i < NCpnDate[n]; i++)
		{
			if (NBDFromEndToPay == 0) CpnPayDate[n][i] = CpnDate[n][i];
			else
			{
				TempExcelDate = CDateToExcelDate(CpnDate[n][i]);
				TempYYYYMMDD = CpnDate[n][i];
				NBD = 0;
				for (j = 0; j < 100; j++)
				{
					TempExcelDate = TempExcelDate + 1;
					TempYYYYMMDD = ExcelDateToCDate(TempExcelDate);
					SaturSundayFlag = (TempExcelDate % 7 == 1 || TempExcelDate % 7 == 0);
					HolidayFlag = isin_Longtype(TempYYYYMMDD, TotalHolidays[n], NTotalHoliday[n]);
					if (SaturSundayFlag == 0 && HolidayFlag == 0) NBD += 1;

					if (NBD >= NBDFromEndToPay)
					{
						CpnPayDate[n][i] = TempYYYYMMDD;
						break;
					}
				}
			}
		}
		free(TempHoliday);
		nsum += NAdditionalHolidays[n];
	}

	for (i = 0; i < NCpnDate[0]; i++)
	{
		ResultCpnDateRcv[i + NCpnDate[0]] = CpnDate[0][i];
		if (i == 0) ResultCpnDateRcv[i] = EffectiveDate;
		else ResultCpnDateRcv[i] = CpnDate[0][i - 1];
		ResultCpnDateRcv[i + 2 * NCpnDate[0]] = CpnPayDate[0][i];
	}

	for (i = 0; i < NCpnDate[1]; i++)
	{
		ResultCpnDatePay[i + NCpnDate[1]] = CpnDate[1][i];
		if (i == 0) ResultCpnDatePay[i] = EffectiveDate;
		else ResultCpnDatePay[i] = CpnDate[1][i - 1];
		ResultCpnDatePay[i + 2 * NCpnDate[1]] = CpnPayDate[1][i];
	}
	long NCpnDateRcv = NCpnDate[0];
	long NCpnDatePay = NCpnDate[1];
	long* RcvFixingDate = ResultCpnDateRcv;
	long* RcvPaymentDate = ResultCpnDateRcv + 2 * NCpnDate[0];
	long* PayFixingDate = ResultCpnDatePay;
	long* PayPaymentDate = ResultCpnDatePay + 2 * NCpnDate[1];

	long NTotalSimulNotAdj = NCpnDate[0] * 2 + NCpnDate[1] * 2 + NOption * 2 + 2;
	long* TotalArraySimulNotAdj = (long*)malloc(sizeof(long) * NTotalSimulNotAdj);													// �Ҵ� 4
	TotalArraySimulNotAdj[0] = EffectiveDate;
	TotalArraySimulNotAdj[1] = PriceDate;
	for (i = 0; i < NCpnDate[0]; i++) TotalArraySimulNotAdj[2 + i] = CpnDate[0][i];
	for (i = 0; i < NCpnDate[0]; i++) TotalArraySimulNotAdj[2 + i + NCpnDate[0]] = CpnPayDate[0][i];
	for (i = 0; i < NCpnDate[1]; i++) TotalArraySimulNotAdj[2 + i + 2 * NCpnDate[0]] = CpnDate[1][i];
	for (i = 0; i < NCpnDate[1]; i++) TotalArraySimulNotAdj[2 + i + 2 * NCpnDate[0] + NCpnDate[1]] = CpnPayDate[1][i];
	for (i = 0; i < NOption; i++) TotalArraySimulNotAdj[2 + i + 2 * NCpnDate[0] + 2 * NCpnDate[1]] = OptionDate[i];
	for (i = 0; i < NOption; i++) TotalArraySimulNotAdj[2 + i + 2 * NCpnDate[0] + 2 * NCpnDate[1] + NOption] = OptionPayDate[i];
	long NTotalSimul = 0;
	long* TotalArrayDateSimul;
	long ND, HolFlag, CDate;
	if (RcvRangeAccrualFlag != 1 && PayRangeAccrualFlag != 1)
	{
		TotalArrayDateSimul = MallocUnique(TotalArraySimulNotAdj, NTotalSimulNotAdj, NTotalSimul);								// �Ҵ� 5
	}
	else
	{
		ND = DayCountAtoB(PriceDate, max(CpnPayDate[0][NCpnDate[0] - 1], CpnPayDate[0][NCpnDate[1] - 1]));
		NBD = 0;		
		for (i = 0; i < ND; i++)
		{
			if (i == 0) CDate = PriceDate;
			else CDate = DayPlus(CDate, 1);
			if (isin_Longtype(CDate, TotalHolidays[0], NTotalHoliday[0]) && isin_Longtype(CDate, TotalHolidays[1], NTotalHoliday[1])) HolFlag = 1;
			else if (isweekendflag(CDate)) HolFlag = 1;
			else HolFlag = 0;

			if (isin_Longtype(CDate, RcvFixingDate, NCpnDateRcv)) HolFlag = 0;
			if (isin_Longtype(CDate, RcvPaymentDate, NCpnDateRcv)) HolFlag = 0;
			if (isin_Longtype(CDate, PayFixingDate, NCpnDatePay)) HolFlag = 0; // �Ƚ̵���Ʈ ������ �׳� �����Ϸ� ����
			if (isin_Longtype(CDate, PayPaymentDate, NCpnDateRcv)) HolFlag = 0;
			if (isin_Longtype(CDate, OptionDate, NOption)) HolFlag = 0;
			if (isin_Longtype(CDate, OptionPayDate, NOption)) HolFlag = 0;

			if (HolFlag == 0) NBD += 1;
		}
		NTotalSimul = NBD;
		TotalArrayDateSimul = (long*)malloc(sizeof(long) * NBD);
		k = 0;
		for (i = 0; i < ND; i++)
		{
			if (i == 0) CDate = PriceDate;
			else CDate = DayPlus(CDate, 1);
			if (isin_Longtype(CDate, TotalHolidays[0], NTotalHoliday[0]) && isin_Longtype(CDate, TotalHolidays[1], NTotalHoliday[1])) HolFlag = 1;
			else if (isweekendflag(CDate)) HolFlag = 1;
			else HolFlag = 0;

			if (isin_Longtype(CDate, RcvFixingDate, NCpnDateRcv)) HolFlag = 0;
			if (isin_Longtype(CDate, RcvPaymentDate, NCpnDateRcv)) HolFlag = 0;
			if (isin_Longtype(CDate, PayFixingDate, NCpnDatePay)) HolFlag = 0; // �Ƚ̵���Ʈ ������ �׳� �����Ϸ� ����
			if (isin_Longtype(CDate, PayPaymentDate, NCpnDateRcv)) HolFlag = 0;
			if (isin_Longtype(CDate, OptionDate, NOption)) HolFlag = 0;
			if (isin_Longtype(CDate, OptionPayDate, NOption)) HolFlag = 0;

			if (HolFlag == 0)
			{
				TotalArrayDateSimul[k] = CDate;
				k += 1;
			}
		}
	}
	bubble_sort_date(TotalArrayDateSimul, NTotalSimul, 1);
	double* dtime = (double*)malloc(sizeof(double) * NTotalSimul);																	// �Ҵ� 6
	double* Time = (double*)malloc(sizeof(double) * NTotalSimul);																	// �Ҵ� 7
	for (i = 0; i < NTotalSimul; i++)
	{
		Time[i] = ((double)DayCountAtoB(PriceDate, TotalArrayDateSimul[i])) / 365.;
		if (i == 0) dtime[i] = ((double)DayCountAtoB(PriceDate, TotalArrayDateSimul[i])) / 365.;
		else dtime[i] = ((double)DayCountAtoB(TotalArrayDateSimul[i - 1], TotalArrayDateSimul[i])) / 365.;
	}

	double* ResultFixingRateCpnRcv = ResultFixingRateCpn + 3;
	double* ResultFixingRateCpnPay = ResultFixingRateCpn + 3 + NCpnDate[0] * 2;

	//////////////////////////
	// KDB ZeroCallableSwap //
	//////////////////////////
	double DF_to_LastPayDate_Rcv = 1.0;
	double DF_to_LastPayDate_Pay = 1.0;
	double AccZeroCpnRcv, AccZeroCpnPay;
	double AccCpnDFRcv, AccCpnDFPay;
	double t_to_LastPayDate_Rcv = 0.;
	double t_to_LastPayDate_Pay = 0.;

	///////////////
	// FDM Greed //
	///////////////
	double xt_min = -0.1, xt_max = 0.4;
	double dxt = (xt_max - xt_min) / ((double)NGreed);
	double yt_min = -0.1, yt_max = 0.4;
	double dyt = (yt_max - yt_min) / ((double)NGreed);
	double x, y, Rate, Rate_p;

	double* xt = (double*)malloc(sizeof(double) * NGreed);																			// �Ҵ� 8
	double* yt = (double*)malloc(sizeof(double) * NGreed);																			// �Ҵ� 9
	for (i = 0; i < NGreed; i++) xt[i] = xt_min + ((double)i) * dxt;
	for (i = 0; i < NGreed; i++) yt[i] = yt_min + ((double)i) * dyt;
	double* RcvLastFixingPayoff_1F = (double*)malloc(sizeof(double) * NGreed);														// �Ҵ� 10
	double* RcvLastFixingPayoff_2F_Reshaped = (double*)malloc(sizeof(double) * NGreed * NGreed);									// �Ҵ� 11
	double** RcvLastFixingPayoff_2F = (double**)malloc(sizeof(double*) * NGreed);													// �Ҵ� 12
	for (i = 0; i < NGreed; i++) RcvLastFixingPayoff_2F[i] = RcvLastFixingPayoff_2F_Reshaped + i * NGreed;
	
	double* PayLastFixingPayoff_1F = (double*)malloc(sizeof(double) * NGreed);														// �Ҵ� 13
	double* PayLastFixingPayoff_2F_Reshaped = (double*)malloc(sizeof(double) * NGreed * NGreed);									// �Ҵ� 14
	double** PayLastFixingPayoff_2F = (double**)malloc(sizeof(double*) * NGreed);													// �Ҵ� 15
	for (i = 0; i < NGreed; i++) PayLastFixingPayoff_2F[i] = PayLastFixingPayoff_2F_Reshaped + i * NGreed;

	double* Rate_Rcv_1F_Reshaped = (double*)malloc(sizeof(double) * NTotalSimul * NGreed);											// �Ҵ� 16
	double** Rate_Rcv_1F = (double**)malloc(sizeof(double*) * NTotalSimul);															// �Ҵ� 17
	for (i = 0; i < NTotalSimul; i++) Rate_Rcv_1F[i] = Rate_Rcv_1F_Reshaped + i * NGreed;

	double* Rate_RcvPowerSpread_1F_Reshaped = (double*)malloc(sizeof(double) * NTotalSimul * NGreed);								// �Ҵ� 18
	double** Rate_RcvPowerSpread_1F = (double**)malloc(sizeof(double*) * NTotalSimul);												// �Ҵ� 19
	for (i = 0; i < NTotalSimul; i++) Rate_RcvPowerSpread_1F[i] = Rate_RcvPowerSpread_1F_Reshaped + i * NGreed;

	double* Rate_Rcv_2F_Reshaped = (double*)malloc(sizeof(double) * NTotalSimul * NGreed * NGreed);									// �Ҵ� 20
	double** Rate_Rcv_2F_Reshaped2 = (double**)malloc(sizeof(double*) * NTotalSimul * NGreed);										// �Ҵ� 21
	double*** Rate_Rcv_2F = (double***)malloc(sizeof(double**) * NTotalSimul);														// �Ҵ� 22
	for (i = 0; i < NTotalSimul; i++) Rate_Rcv_2F[i] = Rate_Rcv_2F_Reshaped2 + i * NGreed;
	for (i = 0; i < NTotalSimul; i++) for (j = 0; j < NGreed; j++) Rate_Rcv_2F[i][j] = Rate_Rcv_2F_Reshaped + i * NGreed * NGreed + j * NGreed;

	double* Rate_RcvPowerSpread_2F_Reshaped = (double*)malloc(sizeof(double) * NTotalSimul * NGreed * NGreed);						// �Ҵ� 23
	double** Rate_RcvPowerSpread_2F_Reshaped2 = (double**)malloc(sizeof(double*) * NTotalSimul * NGreed);							// �Ҵ� 24
	double*** Rate_RcvPowerSpread_2F = (double***)malloc(sizeof(double**) * NTotalSimul);											// �Ҵ� 25
	for (i = 0; i < NTotalSimul; i++) Rate_RcvPowerSpread_2F[i] = Rate_RcvPowerSpread_2F_Reshaped2 + i * NGreed;
	for (i = 0; i < NTotalSimul; i++) for (j = 0; j < NGreed; j++) Rate_RcvPowerSpread_2F[i][j] = Rate_RcvPowerSpread_2F_Reshaped + i * NGreed * NGreed + j * NGreed;

	double* Rate_Pay_1F_Reshaped = (double*)malloc(sizeof(double) * NTotalSimul * NGreed);											// �Ҵ� 26
	double** Rate_Pay_1F = (double**)malloc(sizeof(double*) * NTotalSimul);															// �Ҵ� 27
	for (i = 0; i < NTotalSimul; i++) Rate_Pay_1F[i] = Rate_Pay_1F_Reshaped + i * NGreed;

	double* Rate_PayPowerSpread_1F_Reshaped = (double*)malloc(sizeof(double) * NTotalSimul * NGreed);								// �Ҵ� 28
	double** Rate_PayPowerSpread_1F = (double**)malloc(sizeof(double*) * NTotalSimul);												// �Ҵ� 29
	for (i = 0; i < NTotalSimul; i++) Rate_PayPowerSpread_1F[i] = Rate_PayPowerSpread_1F_Reshaped + i * NGreed;

	double* Rate_Pay_2F_Reshaped = (double*)malloc(sizeof(double) * NTotalSimul * NGreed * NGreed);									// �Ҵ� 30
	double** Rate_Pay_2F_Reshaped2 = (double**)malloc(sizeof(double*) * NTotalSimul * NGreed);										// �Ҵ� 31
	double*** Rate_Pay_2F = (double***)malloc(sizeof(double**) * NTotalSimul);														// �Ҵ� 32
	for (i = 0; i < NTotalSimul; i++) Rate_Pay_2F[i] = Rate_Pay_2F_Reshaped2 + i * NGreed;
	for (i = 0; i < NTotalSimul; i++) for (j = 0; j < NGreed; j++) Rate_Pay_2F[i][j] = Rate_Pay_2F_Reshaped + i * NGreed * NGreed + j * NGreed;

	double* Rate_PayPowerSpread_2F_Reshaped = (double*)malloc(sizeof(double) * NTotalSimul * NGreed * NGreed);						// �Ҵ� 33
	double** Rate_PayPowerSpread_2F_Reshaped2 = (double**)malloc(sizeof(double*) * NTotalSimul * NGreed);							// �Ҵ� 34
	double*** Rate_PayPowerSpread_2F = (double***)malloc(sizeof(double**) * NTotalSimul);											// �Ҵ� 35
	for (i = 0; i < NTotalSimul; i++) Rate_PayPowerSpread_2F[i] = Rate_PayPowerSpread_2F_Reshaped2 + i * NGreed;		
	for (i = 0; i < NTotalSimul; i++) for (j = 0; j < NGreed; j++) Rate_PayPowerSpread_2F[i][j] = Rate_PayPowerSpread_2F_Reshaped + i * NGreed * NGreed + j * NGreed;

	////////////////////////////////////
	// Hull White Bond Pricing Params //
	////////////////////////////////////
	long* Rcv_ncpn = (long*)malloc(sizeof(long) * NTotalSimul);																		// �Ҵ� 36
	long* RcvPowerSpread_ncpn = (long*)malloc(sizeof(long) * NTotalSimul);															// �Ҵ� 37
	double** Rcv_DF_t_T = (double**)malloc(sizeof(double*) * NTotalSimul);															// �Ҵ� 38
	double** Rcv_B_t_T = (double**)malloc(sizeof(double*) * NTotalSimul);															// �Ҵ� 39
	double** Rcv_QVTerm = (double**)malloc(sizeof(double*) * NTotalSimul);															// �Ҵ� 40
	double** Rcv_dt = (double**)malloc(sizeof(double*) * NTotalSimul);																// �Ҵ� 41
	double** RcvPowerSpread_DF_t_T = (double**)malloc(sizeof(double*) * NTotalSimul);												// �Ҵ� 42
	double** RcvPowerSpread_B_t_T = (double**)malloc(sizeof(double*) * NTotalSimul);												// �Ҵ� 43
	double** RcvPowerSpread_QVTerm = (double**)malloc(sizeof(double*) * NTotalSimul);												// �Ҵ� 44
	double** RcvPowerSpread_dt = (double**)malloc(sizeof(double*) * NTotalSimul);													// �Ҵ� 45
	double** Rcv_B_t_T_2F = (double**)malloc(sizeof(double*) * NTotalSimul);														// �Ҵ� 46
	double** Rcv_QVTerm_2F = (double**)malloc(sizeof(double*) * NTotalSimul);														// �Ҵ� 47
	double** RcvPowerSpread_B_t_T_2F = (double**)malloc(sizeof(double*) * NTotalSimul);												// �Ҵ� 48
	double** RcvPowerSpread_QVTerm_2F = (double**)malloc(sizeof(double*) * NTotalSimul);											// �Ҵ� 49
	double** Rcv_Cross_t_T_2F = (double**)malloc(sizeof(double*) * NTotalSimul);													// �Ҵ� 50
	double** RcvPowerSpread_Cross_t_T_2F = (double**)malloc(sizeof(double*) * NTotalSimul);											// �Ҵ� 51

	long* Pay_ncpn = (long*)malloc(sizeof(long) * NTotalSimul);																		// �Ҵ� 52	
	long* PayPowerSpread_ncpn = (long*)malloc(sizeof(long) * NTotalSimul);															// �Ҵ� 53
	double** Pay_DF_t_T = (double**)malloc(sizeof(double*) * NTotalSimul);															// �Ҵ� 54
	double** Pay_B_t_T = (double**)malloc(sizeof(double*) * NTotalSimul);															// �Ҵ� 55
	double** Pay_QVTerm = (double**)malloc(sizeof(double*) * NTotalSimul);															// �Ҵ� 56
	double** Pay_dt = (double**)malloc(sizeof(double*) * NTotalSimul);																// �Ҵ� 57
	double** PayPowerSpread_DF_t_T = (double**)malloc(sizeof(double*) * NTotalSimul);												// �Ҵ� 58
	double** PayPowerSpread_B_t_T = (double**)malloc(sizeof(double*) * NTotalSimul);												// �Ҵ� 59
	double** PayPowerSpread_QVTerm = (double**)malloc(sizeof(double*) * NTotalSimul);												// �Ҵ� 60
	double** PayPowerSpread_dt = (double**)malloc(sizeof(double*) * NTotalSimul);													// �Ҵ� 61
	double** Pay_B_t_T_2F = (double**)malloc(sizeof(double*) * NTotalSimul);														// �Ҵ� 62
	double** Pay_QVTerm_2F = (double**)malloc(sizeof(double*) * NTotalSimul);														// �Ҵ� 63
	double** PayPowerSpread_B_t_T_2F = (double**)malloc(sizeof(double*) * NTotalSimul);												// �Ҵ� 64
	double** PayPowerSpread_QVTerm_2F = (double**)malloc(sizeof(double*) * NTotalSimul);											// �Ҵ� 65
	double** Pay_Cross_t_T_2F = (double**)malloc(sizeof(double*) * NTotalSimul);													// �Ҵ� 66
	double** PayPowerSpread_Cross_t_T_2F = (double**)malloc(sizeof(double*) * NTotalSimul);											// �Ҵ� 67
	double t, t1, t2, deltat;

	long Today, EndDate1, EndDate2, ncpn, ncpn1, ncpn2, isinflag = 0;
	long TodayIsOptionDate;
	double df_t, df_T, temp = 0., temp2 = 0.;
	long* TempDateArray;
	long* TempDateArray2;

	// Rcv Leg 
	for (i = 0; i < NTotalSimul; i++)
	{
		t1 = Time[i];
		Today = TotalArrayDateSimul[i];
		df_t = Calc_Discount_Factor(ZeroTerm, ZeroRate, NZeroRate, t1);
		TempDate = Today;
		ncpn = 0;
		ncpn1 = 0;
		ncpn2 = 0;
		x = 0.;
		y = 0.;
		if (PowerSpreadFlagRcv == 0)
		{
			EndDate1 = EDate_Cpp(Today, (long)(Maturity_Rcv * 12 + 0.00001));
			TempDateArray = Malloc_CpnDate_Holiday(Today, EndDate1, (long)NCPN_ANN_Rcv, ncpn, TempDate, NTotalHoliday[0], TotalHolidays[0], 1);

			Rcv_ncpn[i] = ncpn;
			Rcv_DF_t_T[i] = (double*)malloc(sizeof(double) * ncpn);
			Rcv_B_t_T[i] = (double*)malloc(sizeof(double) * ncpn);
			Rcv_QVTerm[i] = (double*)malloc(sizeof(double) * ncpn);
			Rcv_dt[i] = (double*)malloc(sizeof(double) * ncpn);
			Rcv_B_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn);
			Rcv_QVTerm_2F[i] = (double*)malloc(sizeof(double) * ncpn);
			Rcv_Cross_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn);

			RcvPowerSpread_ncpn[i] = ncpn;
			RcvPowerSpread_DF_t_T[i] = (double*)malloc(sizeof(double) * ncpn);
			RcvPowerSpread_B_t_T[i] = (double*)malloc(sizeof(double) * ncpn);
			RcvPowerSpread_QVTerm[i] = (double*)malloc(sizeof(double) * ncpn);
			RcvPowerSpread_dt[i] = (double*)malloc(sizeof(double) * ncpn);
			RcvPowerSpread_B_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn);
			RcvPowerSpread_QVTerm_2F[i] = (double*)malloc(sizeof(double) * ncpn);
			RcvPowerSpread_Cross_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn);

			for (j = 0; j < ncpn; j++)
			{
				if (j == 0) Rcv_dt[i][j] = DayCountFractionAtoB(Today, TempDateArray[j], DayCountRcvPay[0]);
				else Rcv_dt[i][j] = DayCountFractionAtoB(TempDateArray[j - 1], TempDateArray[j], DayCountRcvPay[0]);
				t2 = ((double)DayCountAtoB(PriceDate, TempDateArray[j])) / 365.;
				df_T = Calc_Discount_Factor(ZeroTerm, ZeroRate, NZeroRate, t2);
				Rcv_DF_t_T[i][j] = df_T / df_t;
				Rcv_B_t_T[i][j] = B_s_to_t(kappa1, t1, t2);
				Rcv_QVTerm[i][j] = HullWhiteQVTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol);
				if (HW2FFlag > 0)
				{
					Rcv_B_t_T_2F[i][j] = B_s_to_t(kappa2, t1, t2);
					Rcv_QVTerm_2F[i][j] = HullWhiteQVTerm(t1, t2, kappa2, NHWVol, HWVolTerm, HWVol2);
					Rcv_Cross_t_T_2F[i][j] = HullWhite2F_CrossTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol, kappa2, HWVolTerm, HWVol2, FactorCorrelation);
				}
			}

			if (HW2FFlag > 0)
			{
				for (idx1 = 0; idx1 < NGreed; idx1++)
				{
					x = xt[idx1];
					for (idx2 = 0; idx2 < NGreed; idx2++)
					{
						y = yt[idx2];
						Rate = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn, (long)NCPN_ANN_Rcv, Rcv_DF_t_T[i], Rcv_QVTerm[i], Rcv_B_t_T[i], Rcv_dt[i], HW2FFlag, y, Rcv_QVTerm_2F[i], Rcv_B_t_T_2F[i], Rcv_Cross_t_T_2F[i]);
						Rate_Rcv_2F[i][idx1][idx2] = Rate;
					}
				}
			}
			else
			{
				for (idx1 = 0; idx1 < NGreed; idx1++)
				{
					x = xt[idx1];
					Rate = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn, (long)NCPN_ANN_Rcv, Rcv_DF_t_T[i], Rcv_QVTerm[i], Rcv_B_t_T[i], Rcv_dt[i], HW2FFlag, y, Rcv_QVTerm_2F[i], Rcv_B_t_T_2F[i], Rcv_Cross_t_T_2F[i]);
					Rate_Rcv_1F[i][idx1] = Rate;
				}
			}

			if (Today == PriceDate)
			{
				temp = 0.;
				for (j = 0; j < ncpn; j++) temp += Rcv_dt[i][j] * Rcv_DF_t_T[i][j];
				temp = (1.0 - Rcv_DF_t_T[i][ncpn - 1]) / temp;

				if (HW2FFlag == 0)
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						Rate_Rcv_1F[i][idx1] = temp;
					}
				}
				else
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						for (idx2 = 0; idx2 < NGreed; idx2++)
						{
							Rate_Rcv_2F[i][idx1][idx2] = temp;
						}
					}
				}
			}
			else if (Today <= PriceDate)
			{
				isinflag = -1;
				for (j = 0; j < NRcvRateHistory; j++)
				{
					if (RcvRateHistoryDate[j] == Today)
					{
						isinflag = j;
						break;
					}
				}

				if (isinflag >= 0)
				{
					if (HW2FFlag == 0)
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							Rate_Rcv_1F[i][idx1] = RcvRateHistory[isinflag];
						}
					}
					else
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							for (idx2 = 0; idx2 < NGreed; idx2++)
							{
								Rate_Rcv_2F[i][idx1][idx2] = RcvRateHistory[isinflag];;
							}
						}
					}
				}
				else
				{
					if (HW2FFlag == 0) for (idx1 = 0; idx1 < NGreed; idx1++) Rate_Rcv_1F[i][idx1] = 0.;
					else for (idx1 = 0; idx1 < NGreed; idx1++) for (idx2 = 0; idx2 < NGreed; idx2++) Rate_Rcv_2F[i][idx1][idx2] = 0.;
				}
			}

			free(TempDateArray);
		}
		else
		{
			EndDate1 = EDate_Cpp(Today, (long)(Maturity1_Rcv * 12 + 0.00001));
			EndDate2 = EDate_Cpp(Today, (long)(Maturity2_Rcv * 12 + 0.00001));
			TempDateArray = Malloc_CpnDate_Holiday(Today, EndDate1, (long)NCPN_ANN_Rcv, ncpn1, TempDate, NTotalHoliday[0], TotalHolidays[0], 1);
			TempDateArray2 = Malloc_CpnDate_Holiday(Today, EndDate2, (long)NCPN_ANN_Rcv, ncpn2, TempDate, NTotalHoliday[0], TotalHolidays[0], 1);

			Rcv_ncpn[i] = ncpn1;
			Rcv_DF_t_T[i] = (double*)malloc(sizeof(double) * ncpn1);
			Rcv_B_t_T[i] = (double*)malloc(sizeof(double) * ncpn1);
			Rcv_QVTerm[i] = (double*)malloc(sizeof(double) * ncpn1);
			Rcv_dt[i] = (double*)malloc(sizeof(double) * ncpn1);
			Rcv_B_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn1);
			Rcv_QVTerm_2F[i] = (double*)malloc(sizeof(double) * ncpn1);
			Rcv_Cross_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn1);

			RcvPowerSpread_ncpn[i] = ncpn2;
			RcvPowerSpread_DF_t_T[i] = (double*)malloc(sizeof(double) * ncpn2);
			RcvPowerSpread_B_t_T[i] = (double*)malloc(sizeof(double) * ncpn2);
			RcvPowerSpread_QVTerm[i] = (double*)malloc(sizeof(double) * ncpn2);
			RcvPowerSpread_dt[i] = (double*)malloc(sizeof(double) * ncpn2);
			RcvPowerSpread_B_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn2);
			RcvPowerSpread_QVTerm_2F[i] = (double*)malloc(sizeof(double) * ncpn2);
			RcvPowerSpread_Cross_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn2);

			for (j = 0; j < ncpn1; j++)
			{
				if (j == 0) Rcv_dt[i][j] = DayCountFractionAtoB(Today, TempDateArray[j], DayCountRcvPay[0]);
				else Rcv_dt[i][j] = DayCountFractionAtoB(TempDateArray[j - 1], TempDateArray[j], DayCountRcvPay[0]);
				t2 = ((double)DayCountAtoB(PriceDate, TempDateArray[j])) / 365.;
				df_T = Calc_Discount_Factor(ZeroTerm, ZeroRate, NZeroRate, t2);
				Rcv_DF_t_T[i][j] = df_T / df_t;
				Rcv_B_t_T[i][j] = B_s_to_t(kappa1, t1, t2);
				Rcv_QVTerm[i][j] = HullWhiteQVTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol);
				if (HW2FFlag > 0)
				{
					Rcv_B_t_T_2F[i][j] = B_s_to_t(kappa2, t1, t2);
					Rcv_QVTerm_2F[i][j] = HullWhiteQVTerm(t1, t2, kappa2, NHWVol, HWVolTerm, HWVol2);
					Rcv_Cross_t_T_2F[i][j] = HullWhite2F_CrossTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol, kappa2, HWVolTerm, HWVol2, FactorCorrelation);
				}
			}

			for (j = 0; j < ncpn2; j++)
			{
				if (j == 0) RcvPowerSpread_dt[i][j] = DayCountFractionAtoB(Today, TempDateArray2[j], DayCountRcvPay[0]);
				else RcvPowerSpread_dt[i][j] = DayCountFractionAtoB(TempDateArray2[j - 1], TempDateArray2[j], DayCountRcvPay[0]);
				t2 = ((double)DayCountAtoB(PriceDate, TempDateArray2[j])) / 365.;
				df_T = Calc_Discount_Factor(ZeroTerm, ZeroRate, NZeroRate, t2);
				RcvPowerSpread_DF_t_T[i][j] = df_T / df_t;
				RcvPowerSpread_B_t_T[i][j] = B_s_to_t(kappa1, t1, t2);
				RcvPowerSpread_QVTerm[i][j] = HullWhiteQVTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol);
				if (HW2FFlag > 0)
				{
					RcvPowerSpread_B_t_T_2F[i][j] = B_s_to_t(kappa2, t1, t2);
					RcvPowerSpread_QVTerm_2F[i][j] = HullWhiteQVTerm(t1, t2, kappa2, NHWVol, HWVolTerm, HWVol2);
					RcvPowerSpread_Cross_t_T_2F[i][j] = HullWhite2F_CrossTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol, kappa2, HWVolTerm, HWVol2, FactorCorrelation);
				}
			}

			if (HW2FFlag > 0)
			{
				for (idx1 = 0; idx1 < NGreed; idx1++)
				{
					x = xt[idx1];
					for (idx2 = 0; idx2 < NGreed; idx2++)
					{
						y = yt[idx2];
						Rate = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn1, (long)NCPN_ANN_Rcv, Rcv_DF_t_T[i], Rcv_QVTerm[i], Rcv_B_t_T[i], Rcv_dt[i], HW2FFlag, y, Rcv_QVTerm_2F[i], Rcv_B_t_T_2F[i], Rcv_Cross_t_T_2F[i]);
						Rate_Rcv_2F[i][idx1][idx2] = Rate;
						Rate_p = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn2, (long)NCPN_ANN_Rcv, RcvPowerSpread_DF_t_T[i], RcvPowerSpread_QVTerm[i], RcvPowerSpread_B_t_T[i], RcvPowerSpread_dt[i], HW2FFlag, y, RcvPowerSpread_QVTerm_2F[i], RcvPowerSpread_B_t_T_2F[i], RcvPowerSpread_Cross_t_T_2F[i]);
						Rate_RcvPowerSpread_2F[i][idx1][idx2] = Rate_p;
					}
				}
			}
			else
			{
				for (idx1 = 0; idx1 < NGreed; idx1++)
				{
					x = xt[idx1];
					Rate = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn1, (long)NCPN_ANN_Rcv, Rcv_DF_t_T[i], Rcv_QVTerm[i], Rcv_B_t_T[i], Rcv_dt[i], HW2FFlag, y, Rcv_QVTerm_2F[i], Rcv_B_t_T_2F[i], Rcv_Cross_t_T_2F[i]);
					Rate_Rcv_1F[i][idx1] = Rate;
					Rate_p = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn2, (long)NCPN_ANN_Rcv, RcvPowerSpread_DF_t_T[i], RcvPowerSpread_QVTerm[i], RcvPowerSpread_B_t_T[i], RcvPowerSpread_dt[i], HW2FFlag, y, RcvPowerSpread_QVTerm_2F[i], RcvPowerSpread_B_t_T_2F[i], RcvPowerSpread_Cross_t_T_2F[i]);
					Rate_RcvPowerSpread_1F[i][idx1] = Rate_p;
				}
			}

			if (Today == PriceDate)
			{
				temp = 0.;
				for (j = 0; j < ncpn1; j++) temp += Rcv_dt[i][j] * Rcv_DF_t_T[i][j];
				temp = (1.0 - Rcv_DF_t_T[i][ncpn1 - 1]) / temp;
				temp2 = 0.;
				for (j = 0; j < ncpn2; j++) temp += RcvPowerSpread_dt[i][j] * RcvPowerSpread_DF_t_T[i][j];
				temp2 = (1.0 - RcvPowerSpread_DF_t_T[i][ncpn2 - 1]) / temp2;

				if (HW2FFlag == 0)
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						Rate_Rcv_1F[i][idx1] = temp;
						Rate_RcvPowerSpread_1F[i][idx1] = temp2;
					}
				}
				else
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						for (idx2 = 0; idx2 < NGreed; idx2++)
						{
							Rate_Rcv_2F[i][idx1][idx2] = temp;
							Rate_RcvPowerSpread_2F[i][idx1][idx2] = temp2;
						}
					}
				}
			}
			else if (Today <= PriceDate)
			{
				isinflag = -1;
				for (j = 0; j < NRcvRateHistory; j++)
				{
					if (RcvRateHistoryDate[j] == Today)
					{
						isinflag = j;
						break;
					}
				}

				if (isinflag >= 0)
				{
					if (HW2FFlag == 0)
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							Rate_Rcv_1F[i][idx1] = RcvRateHistory[isinflag];
						}
					}
					else
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							for (idx2 = 0; idx2 < NGreed; idx2++)
							{
								Rate_Rcv_2F[i][idx1][idx2] = RcvRateHistory[isinflag];;
							}
						}
					}
				}
				else
				{
					if (HW2FFlag == 0) for (idx1 = 0; idx1 < NGreed; idx1++) Rate_Rcv_1F[i][idx1] = 0.;
					else for (idx1 = 0; idx1 < NGreed; idx1++) for (idx2 = 0; idx2 < NGreed; idx2++) Rate_Rcv_2F[i][idx1][idx2] = 0.;
				}
			}

			free(TempDateArray);
			free(TempDateArray2);
		}
	}

	// Pay Leg 
	for (i = 0; i < NTotalSimul; i++)
	{
		t1 = Time[i];
		Today = TotalArrayDateSimul[i];
		df_t = Calc_Discount_Factor(ZeroTerm, ZeroRate, NZeroRate, t1);
		TempDate = Today;
		ncpn = 0;
		ncpn1 = 0;
		ncpn2 = 0;
		x = 0.;
		y = 0.;
		if (PowerSpreadFlagPay == 0)
		{
			EndDate1 = EDate_Cpp(Today, (long)(Maturity_Pay * 12 + 0.00001));
			TempDateArray = Malloc_CpnDate_Holiday(Today, EndDate1, (long)NCPN_ANN_Pay, ncpn, TempDate, NTotalHoliday[0], TotalHolidays[0], 1);

			Pay_ncpn[i] = ncpn;
			Pay_DF_t_T[i] = (double*)malloc(sizeof(double) * ncpn);
			Pay_B_t_T[i] = (double*)malloc(sizeof(double) * ncpn);
			Pay_QVTerm[i] = (double*)malloc(sizeof(double) * ncpn);
			Pay_dt[i] = (double*)malloc(sizeof(double) * ncpn);
			Pay_B_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn);
			Pay_QVTerm_2F[i] = (double*)malloc(sizeof(double) * ncpn);
			Pay_Cross_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn);

			PayPowerSpread_ncpn[i] = ncpn;
			PayPowerSpread_DF_t_T[i] = (double*)malloc(sizeof(double) * ncpn);
			PayPowerSpread_B_t_T[i] = (double*)malloc(sizeof(double) * ncpn);
			PayPowerSpread_QVTerm[i] = (double*)malloc(sizeof(double) * ncpn);
			PayPowerSpread_dt[i] = (double*)malloc(sizeof(double) * ncpn);
			PayPowerSpread_B_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn);
			PayPowerSpread_QVTerm_2F[i] = (double*)malloc(sizeof(double) * ncpn);
			PayPowerSpread_Cross_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn);

			for (j = 0; j < ncpn; j++)
			{
				if (j == 0) Pay_dt[i][j] = DayCountFractionAtoB(Today, TempDateArray[j], DayCountRcvPay[1]);
				else Pay_dt[i][j] = DayCountFractionAtoB(TempDateArray[j - 1], TempDateArray[j], DayCountRcvPay[1]);
				t2 = ((double)DayCountAtoB(PriceDate, TempDateArray[j])) / 365.;
				df_T = Calc_Discount_Factor(ZeroTerm, ZeroRate, NZeroRate, t2);
				Pay_DF_t_T[i][j] = df_T / df_t;
				Pay_B_t_T[i][j] = B_s_to_t(kappa1, t1, t2);
				Pay_QVTerm[i][j] = HullWhiteQVTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol);
				if (HW2FFlag > 0)
				{
					Pay_B_t_T_2F[i][j] = B_s_to_t(kappa2, t1, t2);
					Pay_QVTerm_2F[i][j] = HullWhiteQVTerm(t1, t2, kappa2, NHWVol, HWVolTerm, HWVol2);
					Pay_Cross_t_T_2F[i][j] = HullWhite2F_CrossTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol, kappa2, HWVolTerm, HWVol2, FactorCorrelation);
				}
			}

			if (HW2FFlag > 0)
			{
				for (idx1 = 0; idx1 < NGreed; idx1++)
				{
					x = xt[idx1];
					for (idx2 = 0; idx2 < NGreed; idx2++)
					{
						y = yt[idx2];
						Rate = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn, (long)NCPN_ANN_Pay, Pay_DF_t_T[i], Pay_QVTerm[i], Pay_B_t_T[i], Pay_dt[i], HW2FFlag, y, Pay_QVTerm_2F[i], Pay_B_t_T_2F[i], Pay_Cross_t_T_2F[i]);
						Rate_Pay_2F[i][idx1][idx2] = Rate;
					}
				}
			}
			else
			{
				for (idx1 = 0; idx1 < NGreed; idx1++)
				{
					x = xt[idx1];
					Rate = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn, (long)NCPN_ANN_Pay, Pay_DF_t_T[i], Pay_QVTerm[i], Pay_B_t_T[i], Pay_dt[i], HW2FFlag, y, Pay_QVTerm_2F[i], Pay_B_t_T_2F[i], Pay_Cross_t_T_2F[i]);
					Rate_Pay_1F[i][idx1] = Rate;
				}
			}

			if (Today == PriceDate)
			{
				temp = 0.;
				for (j = 0; j < ncpn; j++) temp += Pay_dt[i][j] * Pay_DF_t_T[i][j];
				temp = (1.0 - Pay_DF_t_T[i][ncpn - 1]) / temp;
				if (HW2FFlag == 0)
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						Rate_Pay_1F[i][idx1] = temp;
					}
				}
				else
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						for (idx2 = 0; idx2 < NGreed; idx2++)
						{
							Rate_Pay_2F[i][idx1][idx2] = temp;
						}
					}
				}
			}
			else if (Today <= PriceDate)
			{
				isinflag = -1;
				for (j = 0; j < NPayRateHistory; j++)
				{
					if (PayRateHistoryDate[j] == Today)
					{
						isinflag = j;
						break;
					}
				}

				if (isinflag >= 0)
				{
					if (HW2FFlag == 0)
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							Rate_Pay_1F[i][idx1] = PayRateHistory[isinflag];
						}
					}
					else
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							for (idx2 = 0; idx2 < NGreed; idx2++)
							{
								Rate_Pay_2F[i][idx1][idx2] = PayRateHistory[isinflag];;
							}
						}
					}
				}
				else
				{
					if (HW2FFlag == 0) for (idx1 = 0; idx1 < NGreed; idx1++) Rate_Pay_1F[i][idx1] = 0.;
					else for (idx1 = 0; idx1 < NGreed; idx1++) for (idx2 = 0; idx2 < NGreed; idx2++) Rate_Pay_2F[i][idx1][idx2] = 0.;
				}
			}
			free(TempDateArray);
		}
		else
		{
			EndDate1 = EDate_Cpp(Today, (long)(Maturity1_Pay * 12 + 0.00001));
			EndDate2 = EDate_Cpp(Today, (long)(Maturity2_Pay * 12 + 0.00001));
			TempDateArray = Malloc_CpnDate_Holiday(Today, EndDate1, (long)NCPN_ANN_Pay, ncpn1, TempDate, NTotalHoliday[0], TotalHolidays[0], 1);
			TempDateArray2 = Malloc_CpnDate_Holiday(Today, EndDate2, (long)NCPN_ANN_Pay, ncpn2, TempDate, NTotalHoliday[0], TotalHolidays[0], 1);

			Pay_ncpn[i] = ncpn1;
			Pay_DF_t_T[i] = (double*)malloc(sizeof(double) * ncpn1);
			Pay_B_t_T[i] = (double*)malloc(sizeof(double) * ncpn1);
			Pay_QVTerm[i] = (double*)malloc(sizeof(double) * ncpn1);
			Pay_dt[i] = (double*)malloc(sizeof(double) * ncpn1);
			Pay_B_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn1);
			Pay_QVTerm_2F[i] = (double*)malloc(sizeof(double) * ncpn1);
			Pay_Cross_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn1);

			PayPowerSpread_ncpn[i] = ncpn2;
			PayPowerSpread_DF_t_T[i] = (double*)malloc(sizeof(double) * ncpn2);
			PayPowerSpread_B_t_T[i] = (double*)malloc(sizeof(double) * ncpn2);
			PayPowerSpread_QVTerm[i] = (double*)malloc(sizeof(double) * ncpn2);
			PayPowerSpread_dt[i] = (double*)malloc(sizeof(double) * ncpn2);
			PayPowerSpread_B_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn2);
			PayPowerSpread_QVTerm_2F[i] = (double*)malloc(sizeof(double) * ncpn2);
			PayPowerSpread_Cross_t_T_2F[i] = (double*)malloc(sizeof(double) * ncpn2);

			for (j = 0; j < ncpn1; j++)
			{
				if (j == 0) Pay_dt[i][j] = DayCountFractionAtoB(Today, TempDateArray[j], DayCountRcvPay[1]);
				else Pay_dt[i][j] = DayCountFractionAtoB(TempDateArray[j - 1], TempDateArray[j], DayCountRcvPay[1]);
				t2 = ((double)DayCountAtoB(PriceDate, TempDateArray[j])) / 365.;
				df_T = Calc_Discount_Factor(ZeroTerm, ZeroRate, NZeroRate, t2);
				Pay_DF_t_T[i][j] = df_T / df_t;
				Pay_B_t_T[i][j] = B_s_to_t(kappa1, t1, t2);
				Pay_QVTerm[i][j] = HullWhiteQVTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol);
				if (HW2FFlag > 0)
				{
					Pay_B_t_T_2F[i][j] = B_s_to_t(kappa2, t1, t2);
					Pay_QVTerm_2F[i][j] = HullWhiteQVTerm(t1, t2, kappa2, NHWVol, HWVolTerm, HWVol2);
					Pay_Cross_t_T_2F[i][j] = HullWhite2F_CrossTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol, kappa2, HWVolTerm, HWVol2, FactorCorrelation);
				}
			}

			for (j = 0; j < ncpn2; j++)
			{
				if (j == 0) PayPowerSpread_dt[i][j] = DayCountFractionAtoB(Today, TempDateArray2[j], DayCountRcvPay[1]);
				else PayPowerSpread_dt[i][j] = DayCountFractionAtoB(TempDateArray2[j - 1], TempDateArray2[j], DayCountRcvPay[1]);
				t2 = ((double)DayCountAtoB(PriceDate, TempDateArray2[j])) / 365.;
				df_T = Calc_Discount_Factor(ZeroTerm, ZeroRate, NZeroRate, t2);
				PayPowerSpread_DF_t_T[i][j] = df_T / df_t;
				PayPowerSpread_B_t_T[i][j] = B_s_to_t(kappa1, t1, t2);
				PayPowerSpread_QVTerm[i][j] = HullWhiteQVTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol);
				if (HW2FFlag > 0)
				{
					PayPowerSpread_B_t_T_2F[i][j] = B_s_to_t(kappa2, t1, t2);
					PayPowerSpread_QVTerm_2F[i][j] = HullWhiteQVTerm(t1, t2, kappa2, NHWVol, HWVolTerm, HWVol2);
					PayPowerSpread_Cross_t_T_2F[i][j] = HullWhite2F_CrossTerm(t1, t2, kappa1, NHWVol, HWVolTerm, HWVol, kappa2, HWVolTerm, HWVol2, FactorCorrelation);
				}
			}

			if (HW2FFlag > 0)
			{
				for (idx1 = 0; idx1 < NGreed; idx1++)
				{
					x = xt[idx1];
					for (idx2 = 0; idx2 < NGreed; idx2++)
					{
						y = yt[idx2];
						Rate = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn1, (long)NCPN_ANN_Pay, Pay_DF_t_T[i], Pay_QVTerm[i], Pay_B_t_T[i], Pay_dt[i], HW2FFlag, y, Pay_QVTerm_2F[i], Pay_B_t_T_2F[i], Pay_Cross_t_T_2F[i]);
						Rate_Pay_2F[i][idx1][idx2] = Rate;
						Rate_p = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn2, (long)NCPN_ANN_Pay, PayPowerSpread_DF_t_T[i], PayPowerSpread_QVTerm[i], PayPowerSpread_B_t_T[i], PayPowerSpread_dt[i], HW2FFlag, y, PayPowerSpread_QVTerm_2F[i], PayPowerSpread_B_t_T_2F[i], PayPowerSpread_Cross_t_T_2F[i]);
						Rate_PayPowerSpread_2F[i][idx1][idx2] = Rate_p;
					}
				}
			}
			else
			{
				for (idx1 = 0; idx1 < NGreed; idx1++)
				{
					x = xt[idx1];
					Rate = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn1, (long)NCPN_ANN_Pay, Pay_DF_t_T[i], Pay_QVTerm[i], Pay_B_t_T[i], Pay_dt[i], HW2FFlag, y, Pay_QVTerm_2F[i], Pay_B_t_T_2F[i], Pay_Cross_t_T_2F[i]);
					Rate_Pay_1F[i][idx1] = Rate;
					Rate_p = HW_Rate(1, NZeroRate, ZeroTerm, ZeroRate, x, ncpn2, (long)NCPN_ANN_Pay, PayPowerSpread_DF_t_T[i], PayPowerSpread_QVTerm[i], PayPowerSpread_B_t_T[i], PayPowerSpread_dt[i], HW2FFlag, y, PayPowerSpread_QVTerm_2F[i], PayPowerSpread_B_t_T_2F[i], PayPowerSpread_Cross_t_T_2F[i]);
					Rate_PayPowerSpread_1F[i][idx1] = Rate_p;
				}
			}

			if (Today == PriceDate)
			{
				temp = 0.;
				for (j = 0; j < ncpn1; j++) temp += Pay_dt[i][j] * Pay_DF_t_T[i][j];
				temp = (1.0 - Pay_DF_t_T[i][ncpn1 - 1]) / temp;
				temp2 = 0.;
				for (j = 0; j < ncpn2; j++) temp += PayPowerSpread_dt[i][j] * PayPowerSpread_DF_t_T[i][j];
				temp2 = (1.0 - PayPowerSpread_DF_t_T[i][ncpn2 - 1]) / temp2;

				if (HW2FFlag == 0)
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						Rate_Pay_1F[i][idx1] = temp;
						Rate_PayPowerSpread_1F[i][idx1] = temp2;
					}
				}
				else
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						for (idx2 = 0; idx2 < NGreed; idx2++)
						{
							Rate_Pay_2F[i][idx1][idx2] = temp;
							Rate_PayPowerSpread_2F[i][idx1][idx2] = temp2;
						}
					}
				}
			}
			else if (Today <= PriceDate)
			{
				isinflag = -1;
				for (j = 0; j < NPayRateHistory; j++)
				{
					if (PayRateHistoryDate[j] == Today)
					{
						isinflag = j;
						break;
					}
				}

				if (isinflag >= 0)
				{
					if (HW2FFlag == 0)
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							Rate_Pay_1F[i][idx1] = PayRateHistory[isinflag];
						}
					}
					else
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							for (idx2 = 0; idx2 < NGreed; idx2++)
							{
								Rate_Pay_2F[i][idx1][idx2] = PayRateHistory[isinflag];;
							}
						}
					}
				}
				else
				{
					if (HW2FFlag == 0) for (idx1 = 0; idx1 < NGreed; idx1++) Rate_Pay_1F[i][idx1] = 0.;
					else for (idx1 = 0; idx1 < NGreed; idx1++) for (idx2 = 0; idx2 < NGreed; idx2++) Rate_Pay_2F[i][idx1][idx2] = 0.;
				}
			}

			free(TempDateArray);
			free(TempDateArray2);
		}
	}

	double* SlopeOfFixingRate_Rcv = (double*)malloc(sizeof(double) * NCpnDateRcv);														// �Ҵ� 68
	double* SlopeOfPayoff_Rcv = (double*)malloc(sizeof(double) * NCpnDateRcv);															// �Ҵ� 69
	double* FixedRate_Rcv = (double*)malloc(sizeof(double) * NCpnDateRcv);																// �Ҵ� 70
	long* Structured_Rcv = (long*)malloc(sizeof(long) * NCpnDateRcv);																	// �Ҵ� 71	
	double* RangeCpn_Rcv = (double*)malloc(sizeof(double) * NCpnDateRcv);																// �Ҵ� 72
	double* DeltatRcv = (double*)malloc(sizeof(double) * NCpnDateRcv);																	// �Ҵ� 73
	long* ZeroCouponFlagRcv = (long*)malloc(sizeof(long) * NCpnDateRcv);																// �Ҵ� 74
	long* NBD_Fixing_to_End_Rcv = (long*)malloc(sizeof(long) * NCpnDateRcv);															// �Ҵ� 106

	double* SlopeOfFixingRate_Pay = (double*)malloc(sizeof(double) * NCpnDatePay);														// �Ҵ� 75
	double* SlopeOfPayoff_Pay = (double*)malloc(sizeof(double) * NCpnDatePay);															// �Ҵ� 76	
	double* FixedRate_Pay = (double*)malloc(sizeof(double) * NCpnDatePay);																// �Ҵ� 77	
	long* Structured_Pay = (long*)malloc(sizeof(long) * NCpnDatePay);																	// �Ҵ� 78
	double* RangeCpn_Pay = (double*)malloc(sizeof(double) * NCpnDatePay);																// �Ҵ� 79
	double* DeltatPay = (double*)malloc(sizeof(double) * NCpnDatePay);																	// �Ҵ� 80
	long* ZeroCouponFlagPay = (long*)malloc(sizeof(long) * NCpnDatePay);																// �Ҵ� 81
	long* NBD_Fixing_to_End_Pay = (long*)malloc(sizeof(long) * NCpnDatePay);															// �Ҵ� 107

	long* CpnDateRcv = CpnDate[0];
	long* CpnDatePay = CpnDate[1];
	long DayCountFracRcv = DayCountRcvPay[0];
	long DayCountFracPay = DayCountRcvPay[1];
	long idxrcv = 0, idxpay = 0;
	for (i = 0; i < NCpnDateRcv; i++) NBD_Fixing_to_End_Rcv[i] = 0;
	for (i = 0; i < NCpnDatePay; i++) NBD_Fixing_to_End_Pay[i] = 0;

	for (i = 0; i < NTotalSimul; i++)
	{
		Today = TotalArrayDateSimul[NTotalSimul - 1 - i];
		idxrcv = -1;
		for (j = 0; j < NCpnDateRcv; j++)
		{
			if (RcvFixingDate[j] <= Today && CpnDateRcv[j] > Today)
			{
				idxrcv = j;
				break;
			}
		}
		if (idxrcv >= 0) NBD_Fixing_to_End_Rcv[idxrcv] += 1;

		idxpay = -1;
		for (j = 0; j < NCpnDatePay; j++)
		{
			if (PayFixingDate[j] <= Today && CpnDatePay[j] > Today)
			{
				idxpay = j;
				break;
			}
		}
		if (idxpay >= 0) NBD_Fixing_to_End_Pay[idxpay] += 1;
	}

	for (i = 0; i < NCpnDateRcv; i++)
	{
		SlopeOfFixingRate_Rcv[i] = MultipleRatefixPayoffRcv[0];
		SlopeOfPayoff_Rcv[i] = MultipleRatefixPayoffRcv[1];
		DeltatRcv[i] = DayCountFractionAtoB(RcvFixingDate[i], CpnDateRcv[i], DayCountFracRcv);
		if (RcvFixingDate[i] >= Phase2Date)
		{
			FixedRate_Rcv[i] = Phase2RcvLegFixedRate;
			Structured_Rcv[i] = Phase2RcvLegStructuredFlag;
			RangeCpn_Rcv[i] = Phase2RcvLegRangeCoupon;
			if (NumCpnAnnPhase2RcvPay[0] == 0 ) ZeroCouponFlagRcv[i] = 1;
			else if (NumCpnAnnPhase2RcvPay[0] == -1) ZeroCouponFlagRcv[i] = 2;
			else if (NumCpnAnnPhase2RcvPay[0] == -2) ZeroCouponFlagRcv[i] = 3;
			else ZeroCouponFlagRcv[i] = 0;
		}
		else
		{
			FixedRate_Rcv[i] = RcvLegFixedRate;
			Structured_Rcv[i] = RcvLegStructuredFlag;
			RangeCpn_Rcv[i] = RcvLegRangeCoupon;
			if (NumCpnAnn[0] == 0 ) ZeroCouponFlagRcv[i] = 1;
			else if (NumCpnAnn[0] == -1) ZeroCouponFlagRcv[i] = 2;
			else if (NumCpnAnn[0] == -2) ZeroCouponFlagRcv[i] = 3;
			else ZeroCouponFlagRcv[i] = 0;
		}
	}

	for (i = 0; i < NCpnDatePay; i++)
	{
		SlopeOfFixingRate_Pay[i] = MultipleRatefixPayoffPay[0];
		SlopeOfPayoff_Pay[i] = MultipleRatefixPayoffPay[1];
		DeltatPay[i] = DayCountFractionAtoB(PayFixingDate[i], CpnDatePay[i], DayCountFracPay);

		if (PayFixingDate[i] >= Phase2Date)
		{
			FixedRate_Pay[i] = Phase2PayLegFixedRate;
			Structured_Pay[i] = Phase2PayLegStructuredFlag;
			RangeCpn_Pay[i] = Phase2PayLegRangeCoupon;
			if (NumCpnAnnPhase2RcvPay[1] == 0) ZeroCouponFlagPay[i] = 1;
			else if (NumCpnAnnPhase2RcvPay[1] == -1) ZeroCouponFlagPay[i] = 2;
			else if (NumCpnAnnPhase2RcvPay[1] == -2) ZeroCouponFlagPay[i] = 3;
			else ZeroCouponFlagPay[i] = 0;
		}
		else
		{
			FixedRate_Pay[i] = PayLegFixedRate;
			Structured_Pay[i] = PayLegStructuredFlag;
			RangeCpn_Pay[i] = PayLegRangeCoupon;
			if (NumCpnAnn[1] == 0) ZeroCouponFlagPay[i] = 1;
			else if (NumCpnAnn[1] == -1) ZeroCouponFlagPay[i] = 2;
			else if (NumCpnAnn[1] == -2) ZeroCouponFlagPay[i] = 3;
			else ZeroCouponFlagPay[i] = 0;
		}
	}

	double* Alpha_1Curve = (double*)malloc(sizeof(double) * NGreed);		// IFDM 1F x_t Alpha or OS x_t						// �Ҵ� 82
	double* Beta_1Curve = (double*)malloc(sizeof(double) * NGreed);																// �Ҵ� 83
	double* Gamma_1Curve = (double*)malloc(sizeof(double) * NGreed);															// �Ҵ� 84

	double* Alpha_2Curve = (double*)malloc(sizeof(double) * NGreed);		// OS y_t 											// �Ҵ� 85
	double* Beta_2Curve = (double*)malloc(sizeof(double) * NGreed);																// �Ҵ� 86
	double* Gamma_2Curve = (double*)malloc(sizeof(double) * NGreed);															// �Ҵ� 87

	double* FDMValue_1F = (double*)malloc(sizeof(double) * NGreed);																// �Ҵ� 88
	double* FDMValue_2F_Reshaped = (double*)malloc(sizeof(double) * NGreed * NGreed);											// �Ҵ� 89
	double** FDMValue_2F = (double**)malloc(sizeof(double*) * NGreed);															// �Ҵ� 90	
	for (i = 0; i < NGreed; i++) FDMValue_2F[i] = FDMValue_2F_Reshaped + i * NGreed; 
	double* RHSValue_2F_Reshaped = (double*)malloc(sizeof(double) * NGreed * NGreed);											// �Ҵ� 91
	double** RHSValue_2F = (double**)malloc(sizeof(double*) * NGreed);															// �Ҵ� 92		
	for (i = 0; i < NGreed; i++) RHSValue_2F[i] = RHSValue_2F_Reshaped + i * NGreed;

	double* TempAlphaArray = (double*)malloc(sizeof(double) * NGreed);															// �Ҵ� 93
	double* TempBetaArray = (double*)malloc(sizeof(double) * NGreed);															// �Ҵ� 94
	double* TempGammaArray = (double*)malloc(sizeof(double) * NGreed);															// �Ҵ� 95
	double* TempCpnArrayRcv_1F = (double*)malloc(sizeof(double) * NGreed);														// �Ҵ� 96
	double* TempCpnArrayPay_1F = (double*)malloc(sizeof(double) * NGreed);														// �Ҵ� 97
	double* TempCpnArrayRcv_2F_Reshaped = (double*)malloc(sizeof(double) * NGreed * NGreed);									// �Ҵ� 98
	double* TempCpnArrayPay_2F_Reshaped = (double*)malloc(sizeof(double) * NGreed * NGreed);									// �Ҵ� 99
	double** TempCpnArrayRcv_2F = (double**)malloc(sizeof(double*) * NGreed);													// �Ҵ� 100
	double** TempCpnArrayPay_2F = (double**)malloc(sizeof(double*) * NGreed);													// �Ҵ� 101
	for (i = 0; i < NGreed; i++)
	{
		TempCpnArrayRcv_2F[i] = TempCpnArrayRcv_2F_Reshaped + i * NGreed;
		TempCpnArrayPay_2F[i] = TempCpnArrayPay_2F_Reshaped + i * NGreed;
	}

	double vol1 = 0., vol2 = 0., b0, c0, bN, aN, vols, volt;
	double Rate_Rcv, Rate_Pay, Rate_Rcv_p, Rate_Pay_p, RcvCpn, PayCpn, RgCpnRcv, RgCpnPay;
	double Instant_FwdDF, Instant_B_s_t, Instant_QVTerm, Instant_B_s_t_2F, Instant_QVTerm_2F, Instant_Cross_QVTerm_2F, PtT;
	long LastFixingDateRcv, LastFixingDatePay, LastFixingIdxRcv = 0, LastFixingIdxPay = 0, idxrcvfix = 0, idxpayfix = 0, idxhist = 0;

	long* OptionExerciseFlag_2F_Reshaped = (long*)malloc(sizeof(long) * NGreed * NGreed);										// �Ҵ� 102
	long** OptionExerciseFlag_2F = (long**)malloc(sizeof(long*) * NGreed);														// �Ҵ� 103
	for (i = 0; i < NGreed; i++) OptionExerciseFlag_2F[i] = OptionExerciseFlag_2F_Reshaped + i * NGreed;
	long* OptionExerciseFlag_1F = (long*)malloc(sizeof(long) * NGreed);															// �Ҵ� 104

	double* ForPrintVariable = (double*)malloc(sizeof(double) * 4);																// �Ҵ� 105
	double deltat_fixing_to_pay = 0.;
	LastFixingDateRcv = RcvFixingDate[NCpnDateRcv - 1];
	LastFixingDatePay = PayFixingDate[NCpnDatePay - 1];
	for (i = 0; i < NTotalSimul; i++)
	{
		if (TotalArrayDateSimul[i] == LastFixingDateRcv)
		{
			LastFixingIdxRcv = i;
			break;
		}
	}
	for (i = 0; i < NTotalSimul; i++)
	{
		if (TotalArrayDateSimul[i] == LastFixingDatePay)
		{
			LastFixingIdxPay = i;
			break;
		}
	}

	long nextoptidx = max(0, NOption - 1);
	long LastFixingIdx = -1;
	double LastFixingPayaoff = 0., cmpv = 0.;
	n = 0;
	for (i = 0; i < NTotalSimul; i++)
	{
		Today = TotalArrayDateSimul[NTotalSimul - 1 - i];
		t = Time[NTotalSimul - 1 - i];
		if (n == 0)
		{
			if (TextFlag > 0)
			{
				ForPrintVariable[0] = (double)Today;
				ForPrintVariable[1] = t;
				ForPrintVariable[2] = t;
				ForPrintVariable[3] = 1.0;
				DumppingTextDataArray(CalcFunctionName, SaveFileName, "DF_in_FDMTimeGreed", 4, ForPrintVariable);
			}

			if (HW2FFlag > 0)
			{
				if (PowerSpreadFlagRcv == 0)
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						for (idx2 = 0; idx2 < NGreed; idx2++)
						{
							Rate_Rcv = Rate_Rcv_2F[LastFixingIdxRcv][idx1][idx2];
							RgCpnRcv = 0.;
							if (Structured_Rcv[NCpnDateRcv - 1] > 0)
							{
								Rate = SlopeOfFixingRate_Rcv[NCpnDateRcv - 1] * Rate_Rcv;
								if (RcvRangeAccrualFlag == 0)
								{
									if ((Rate < RangeMaxMinRcv[0]) && (Rate > RangeMaxMinRcv[1])) RgCpnRcv = (SlopeOfPayoff_Rcv[NCpnDateRcv - 1] * Rate_Rcv) + RangeCpn_Rcv[NCpnDateRcv - 1];
								}
								else
								{
									if ((Rate < RangeMaxMinRcv[0]) && (Rate > RangeMaxMinRcv[1])) RgCpnRcv = (SlopeOfPayoff_Rcv[NCpnDateRcv - 1] * Rate_Rcv) + RangeCpn_Rcv[NCpnDateRcv - 1] / (double)NBD_Fixing_to_End_Rcv[NCpnDateRcv - 1];
								}
							}
							
							if (ZeroCouponFlagRcv[NCpnDateRcv - 1] == 0)
							{
								RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv) * DeltatRcv[NCpnDateRcv - 1])), RoundingRcv);
							}
							else if (ZeroCouponFlagRcv[NCpnDateRcv - 1] == 1)
							{
								deltat_fixing_to_pay = DeltatRcv[NCpnDateRcv - 1];
								RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
							}
							else 
							{
								deltat_fixing_to_pay = DeltatRcv[NCpnDateRcv - 1];
								RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
							}
							TempCpnArrayRcv_2F[idx1][idx2] = RcvCpn;
							FDMValue_2F[idx1][idx2] = RcvCpn;
						}
					}
					ResultFixingRateCpnRcv[NCpnDateRcv - 1] = Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Rcv_2F[LastFixingIdxRcv], 0.0, 0.0);
					ResultFixingRateCpnRcv[2 * NCpnDateRcv - 1] = Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayRcv_2F, 0.0, 0.0);
					if (RcvRangeAccrualFlag == 1)
					{
						ResultFixingRateCpnRcv[NCpnDateRcv - 1] /= (double)NBD_Fixing_to_End_Rcv[NCpnDateRcv - 1];
					}
				}
				else
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						for (idx2 = 0; idx2 < NGreed; idx2++)
						{
							Rate_Rcv = Rate_Rcv_2F[LastFixingIdxRcv][idx1][idx2];
							Rate_Rcv_p = Rate_RcvPowerSpread_2F[LastFixingIdxRcv][idx1][idx2];
							RgCpnRcv = 0.;
							if (Structured_Rcv[NCpnDateRcv - 1] > 0)
							{
								Rate = SlopeOfFixingRate_Rcv[NCpnDateRcv - 1] * (Rate_Rcv - Rate_Rcv_p);
								if (RcvRangeAccrualFlag == 0)
								{
									if ((Rate < RangeMaxMinRcv[0]) && (Rate > RangeMaxMinRcv[1])) RgCpnRcv = (SlopeOfPayoff_Rcv[NCpnDateRcv - 1] * (Rate_Rcv - Rate_Rcv_p)) + RangeCpn_Rcv[NCpnDateRcv - 1];
								}
								else
								{
									if ((Rate < RangeMaxMinRcv[0]) && (Rate > RangeMaxMinRcv[1])) RgCpnRcv = (SlopeOfPayoff_Rcv[NCpnDateRcv - 1] * (Rate_Rcv - Rate_Rcv_p)) + RangeCpn_Rcv[NCpnDateRcv - 1] / (double)NBD_Fixing_to_End_Rcv[NCpnDateRcv - 1];
								}
							}

							if (ZeroCouponFlagRcv[NCpnDateRcv - 1] == 0)
							{
								RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv) * DeltatRcv[NCpnDateRcv - 1])), RoundingRcv);
							}
							else if (ZeroCouponFlagRcv[NCpnDateRcv - 1] == 1)
							{
								deltat_fixing_to_pay = DeltatRcv[NCpnDateRcv - 1];
								RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
							}
							else
							{
								deltat_fixing_to_pay = DeltatRcv[NCpnDateRcv - 1];
								RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
							}
							TempCpnArrayRcv_2F[idx1][idx2] = RcvCpn;
							FDMValue_2F[idx1][idx2] = RcvCpn;
						}
					}
					ResultFixingRateCpnRcv[NCpnDateRcv - 1] = Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Rcv_2F[LastFixingIdxRcv], 0.0, 0.0) - Calc_Volatility(NGreed, NGreed, xt, yt, Rate_RcvPowerSpread_2F[LastFixingIdxRcv], 0.0, 0.0);
					ResultFixingRateCpnRcv[2 * NCpnDateRcv - 1] = Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayRcv_2F, 0.0, 0.0);
					if (RcvRangeAccrualFlag == 1)
					{
						ResultFixingRateCpnRcv[NCpnDateRcv - 1] /= (double)NBD_Fixing_to_End_Rcv[NCpnDateRcv - 1];
					}

				}

				if (PowerSpreadFlagPay == 0)
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						for (idx2 = 0; idx2 < NGreed; idx2++)
						{
							Rate_Pay = Rate_Pay_2F[LastFixingIdxPay][idx1][idx2];
							RgCpnPay = 0.;
							if (Structured_Pay[NCpnDatePay - 1] > 0)
							{
								Rate = SlopeOfFixingRate_Pay[NCpnDatePay - 1] * Rate_Pay;
								if (PayRangeAccrualFlag == 0)
								{
									if ((Rate < RangeMaxMinPay[0]) && (Rate > RangeMaxMinPay[1])) RgCpnPay = (SlopeOfPayoff_Pay[NCpnDatePay - 1] * Rate_Pay) + RangeCpn_Pay[NCpnDatePay - 1];
								}
								else
								{
									if ((Rate < RangeMaxMinPay[0]) && (Rate > RangeMaxMinPay[1])) RgCpnPay = (SlopeOfPayoff_Pay[NCpnDatePay - 1] * Rate_Pay) + RangeCpn_Pay[NCpnDatePay - 1] / (double)NBD_Fixing_to_End_Pay[NCpnDatePay - 1] ;
								}
							}

							if (ZeroCouponFlagPay[NCpnDatePay - 1] == 0)
							{
								PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay) * DeltatPay[NCpnDatePay - 1])), RoundingPay);
							}
							else if (ZeroCouponFlagPay[NCpnDatePay - 1] == 1)
							{
								deltat_fixing_to_pay = DeltatPay[NCpnDatePay - 1];
								PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
							}
							else 
							{
								deltat_fixing_to_pay = DeltatPay[NCpnDatePay - 1];
								PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
							}
							TempCpnArrayPay_2F[idx1][idx2] = PayCpn;
							if (BondFlag == 0) FDMValue_2F[idx1][idx2] -= PayCpn;
						}
					}
					ResultFixingRateCpnPay[NCpnDatePay - 1] = Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Pay_2F[LastFixingIdxPay], 0.0, 0.0);
					ResultFixingRateCpnPay[2 * NCpnDatePay - 1] = Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayPay_2F, 0.0, 0.0);
					if (PayRangeAccrualFlag == 1)
					{
						ResultFixingRateCpnPay[NCpnDatePay - 1] /= (double)NBD_Fixing_to_End_Pay[NCpnDatePay - 1];
					}
				}
				else
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						for (idx2 = 0; idx2 < NGreed; idx2++)
						{
							Rate_Pay = Rate_Pay_2F[LastFixingIdxPay][idx1][idx2];
							Rate_Pay_p = Rate_PayPowerSpread_2F[LastFixingIdxPay][idx1][idx2];
							RgCpnPay = 0.;
							if (Structured_Pay[NCpnDatePay - 1] > 0)
							{
								Rate = SlopeOfFixingRate_Pay[NCpnDatePay - 1] * (Rate_Pay - Rate_Pay_p);
								if (PayRangeAccrualFlag == 0)
								{
									if ((Rate < RangeMaxMinPay[0]) && (Rate > RangeMaxMinPay[1])) RgCpnPay = (SlopeOfPayoff_Pay[NCpnDatePay - 1] * (Rate_Pay - Rate_Pay_p)) + RangeCpn_Pay[NCpnDatePay - 1];
								}
								else
								{
									if ((Rate < RangeMaxMinPay[0]) && (Rate > RangeMaxMinPay[1])) RgCpnPay = (SlopeOfPayoff_Pay[NCpnDatePay - 1] * (Rate_Pay - Rate_Pay_p)) + RangeCpn_Pay[NCpnDatePay - 1]/ (double)NBD_Fixing_to_End_Pay[NCpnDatePay - 1];
								}
							}

							if (ZeroCouponFlagPay[NCpnDatePay - 1] == 0)
							{
								PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay) * DeltatPay[NCpnDatePay - 1])), RoundingPay);
							}
							else if (ZeroCouponFlagPay[NCpnDatePay - 1] == 1)
							{
								deltat_fixing_to_pay = DeltatPay[NCpnDatePay - 1];
								PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
							}
							else
							{
								deltat_fixing_to_pay = DeltatPay[NCpnDatePay - 1];
								PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
							}
							TempCpnArrayPay_2F[idx1][idx2] = PayCpn;
							if (BondFlag == 0) FDMValue_2F[idx1][idx2] -= PayCpn;
						}
					}
					ResultFixingRateCpnPay[NCpnDatePay - 1] = Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Pay_2F[LastFixingIdxPay], 0.0, 0.0) - Calc_Volatility(NGreed, NGreed, xt, yt, Rate_PayPowerSpread_2F[LastFixingIdxPay], 0.0, 0.0);
					ResultFixingRateCpnPay[2 * NCpnDatePay - 1] = Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayPay_2F, 0.0, 0.0);
					if (PayRangeAccrualFlag == 1)
					{
						ResultFixingRateCpnPay[NCpnDatePay - 1] /= (double)NBD_Fixing_to_End_Pay[NCpnDatePay - 1];
					}
				}
			}
			else
			{
				if (PowerSpreadFlagRcv == 0)
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						Rate_Rcv = Rate_Rcv_1F[LastFixingIdxRcv][idx1];
						RgCpnRcv = 0.;
						if (Structured_Rcv[NCpnDateRcv - 1] > 0)
						{
							Rate = SlopeOfFixingRate_Rcv[NCpnDateRcv - 1] * Rate_Rcv;
							if (RcvRangeAccrualFlag == 0)
							{
								if ((Rate < RangeMaxMinRcv[0]) && (Rate > RangeMaxMinRcv[1])) RgCpnRcv = (SlopeOfPayoff_Rcv[NCpnDateRcv - 1] * Rate_Rcv) + RangeCpn_Rcv[NCpnDateRcv - 1];
							}
							else
							{
								if ((Rate < RangeMaxMinRcv[0]) && (Rate > RangeMaxMinRcv[1])) RgCpnRcv = (SlopeOfPayoff_Rcv[NCpnDateRcv - 1] * Rate_Rcv) + RangeCpn_Rcv[NCpnDateRcv - 1] / (double)NBD_Fixing_to_End_Rcv[NCpnDateRcv - 1] ;
							}
						}

						if (ZeroCouponFlagRcv[NCpnDateRcv - 1] == 0)
						{
							RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv) * DeltatRcv[NCpnDateRcv - 1])), RoundingRcv);
						}
						else if (ZeroCouponFlagRcv[NCpnDateRcv - 1] == 1)
						{
							deltat_fixing_to_pay = DeltatRcv[NCpnDateRcv - 1];
							RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
						}
						else 
						{
							deltat_fixing_to_pay = DeltatRcv[NCpnDateRcv - 1];
							RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
						}
						TempCpnArrayRcv_1F[idx1] = RcvCpn;
						FDMValue_1F[idx1] = RcvCpn;
					}
					ResultFixingRateCpnRcv[NCpnDateRcv - 1] = Interpolate_Linear(xt, Rate_Rcv_1F[LastFixingIdxRcv], NGreed, 0.0);
					ResultFixingRateCpnRcv[2 * NCpnDateRcv - 1] = Interpolate_Linear(xt, TempCpnArrayRcv_1F, NGreed, 0.0);
					if (RcvRangeAccrualFlag == 1)
					{
						ResultFixingRateCpnRcv[NCpnDateRcv - 1] /= (double)NBD_Fixing_to_End_Rcv[NCpnDateRcv - 1];
					}
				}
				else
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						Rate_Rcv = Rate_Rcv_1F[LastFixingIdxRcv][idx1];
						Rate_Rcv_p = Rate_RcvPowerSpread_1F[LastFixingIdxRcv][idx1];
						RgCpnRcv = 0.;
						if (Structured_Rcv[NCpnDateRcv - 1] > 0)
						{
							Rate = SlopeOfFixingRate_Rcv[NCpnDateRcv - 1] * (Rate_Rcv - Rate_Rcv_p);
							if (RcvRangeAccrualFlag == 0)
							{
								if ((Rate < RangeMaxMinRcv[0]) && (Rate > RangeMaxMinRcv[1])) RgCpnRcv = (SlopeOfPayoff_Rcv[NCpnDateRcv - 1] * (Rate_Rcv - Rate_Rcv_p)) + RangeCpn_Rcv[NCpnDateRcv - 1];
							}
							else
							{
								if ((Rate < RangeMaxMinRcv[0]) && (Rate > RangeMaxMinRcv[1])) RgCpnRcv = (SlopeOfPayoff_Rcv[NCpnDateRcv - 1] * (Rate_Rcv - Rate_Rcv_p)) + RangeCpn_Rcv[NCpnDateRcv - 1] / (double)NBD_Fixing_to_End_Rcv[NCpnDateRcv - 1];
							}
						}

						if (ZeroCouponFlagRcv[NCpnDateRcv - 1] == 0)
						{
							RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv) * DeltatRcv[NCpnDateRcv - 1])), RoundingRcv);
						}
						else if (ZeroCouponFlagRcv[NCpnDateRcv - 1] == 1)
						{
							deltat_fixing_to_pay = DeltatRcv[NCpnDateRcv - 1];
							RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
						}
						else
						{
							deltat_fixing_to_pay = DeltatRcv[NCpnDateRcv - 1];
							RcvCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[NCpnDateRcv - 1] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
						}

						TempCpnArrayRcv_1F[idx1] = RcvCpn;
						FDMValue_1F[idx1] = RcvCpn;
					}
					ResultFixingRateCpnRcv[NCpnDateRcv - 1] = Interpolate_Linear(xt, Rate_Rcv_1F[LastFixingIdxRcv], NGreed, 0.0) - Interpolate_Linear(xt, Rate_RcvPowerSpread_1F[LastFixingIdxRcv], NGreed, 0.0);
					ResultFixingRateCpnRcv[2 * NCpnDateRcv - 1] = Interpolate_Linear(xt, TempCpnArrayRcv_1F, NGreed, 0.0);
					if (RcvRangeAccrualFlag == 1)
					{
						ResultFixingRateCpnRcv[NCpnDateRcv - 1] /= (double)NBD_Fixing_to_End_Rcv[NCpnDateRcv - 1];
					}
				}

				if (PowerSpreadFlagPay == 0)
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						Rate_Pay = Rate_Pay_1F[LastFixingIdxPay][idx1];
						RgCpnPay = 0.;
						if (Structured_Pay[NCpnDatePay - 1] > 0)
						{
							Rate = SlopeOfFixingRate_Pay[NCpnDatePay - 1] * Rate_Pay;
							if (PayRangeAccrualFlag == 0)
							{
								if ((Rate < RangeMaxMinPay[0]) && (Rate > RangeMaxMinPay[1])) RgCpnPay = (SlopeOfPayoff_Pay[NCpnDatePay - 1] * Rate_Pay) + RangeCpn_Pay[NCpnDatePay - 1];
							}
							else
							{
								if ((Rate < RangeMaxMinPay[0]) && (Rate > RangeMaxMinPay[1])) RgCpnPay = (SlopeOfPayoff_Pay[NCpnDatePay - 1] * Rate_Pay) + RangeCpn_Pay[NCpnDatePay - 1] / (double)NBD_Fixing_to_End_Pay[NCpnDatePay - 1];
							}
						}

						if (ZeroCouponFlagPay[NCpnDatePay - 1] == 0)
						{
							PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay) * DeltatPay[NCpnDatePay - 1])), RoundingPay);
						}
						else if (ZeroCouponFlagPay[NCpnDatePay - 1] == 1)
						{
							deltat_fixing_to_pay = DeltatPay[NCpnDatePay - 1];
							PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
						}
						else
						{
							deltat_fixing_to_pay = DeltatPay[NCpnDatePay - 1];
							PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
						}
						TempCpnArrayPay_1F[idx1] = PayCpn;
						if (BondFlag == 0) FDMValue_1F[idx1] -= PayCpn;
					}
					ResultFixingRateCpnPay[NCpnDatePay - 1] = Interpolate_Linear(xt, Rate_Pay_1F[LastFixingIdxPay], NGreed, 0.0);
					ResultFixingRateCpnPay[2 * NCpnDatePay - 1] = Interpolate_Linear(xt, TempCpnArrayPay_1F, NGreed, 0.0);
					if (PayRangeAccrualFlag == 1)
					{
						ResultFixingRateCpnPay[NCpnDatePay - 1] /= (double)NBD_Fixing_to_End_Pay[NCpnDatePay - 1];
					}
				}
				else
				{
					for (idx1 = 0; idx1 < NGreed; idx1++)
					{
						Rate_Pay = Rate_Pay_1F[LastFixingIdxPay][idx1];
						Rate_Pay_p = Rate_PayPowerSpread_1F[LastFixingIdxPay][idx1];
						RgCpnPay = 0.;
						if (Structured_Pay[NCpnDatePay - 1] > 0)
						{
							Rate = SlopeOfFixingRate_Pay[NCpnDatePay - 1] * (Rate_Pay - Rate_Pay_p);
							if (PayRangeAccrualFlag == 0)
							{
								if ((Rate < RangeMaxMinPay[0]) && (Rate > RangeMaxMinPay[1])) RgCpnPay = (SlopeOfPayoff_Pay[NCpnDatePay - 1] * (Rate_Pay - Rate_Pay_p)) + RangeCpn_Pay[NCpnDatePay - 1];
							}
							else
							{
								if ((Rate < RangeMaxMinPay[0]) && (Rate > RangeMaxMinPay[1])) RgCpnPay = (SlopeOfPayoff_Pay[NCpnDatePay - 1] * (Rate_Pay - Rate_Pay_p)) + RangeCpn_Pay[NCpnDatePay - 1]  / (double)NBD_Fixing_to_End_Pay[NCpnDatePay - 1];
							}
						}

						if (ZeroCouponFlagPay[NCpnDatePay - 1] == 0)
						{
							PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay) * DeltatPay[NCpnDatePay - 1])), RoundingPay);
						}
						else if (ZeroCouponFlagPay[NCpnDatePay - 1] == 1)
						{
							deltat_fixing_to_pay = DeltatPay[NCpnDatePay - 1];
							PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
						}
						else
						{
							deltat_fixing_to_pay = DeltatPay[NCpnDatePay - 1];
							PayCpn = NA * (double)NAFlag + NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[NCpnDatePay - 1] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
						}
						TempCpnArrayPay_1F[idx1] = PayCpn;
						if (BondFlag == 0) FDMValue_1F[idx1] -= PayCpn;
					}
					ResultFixingRateCpnPay[NCpnDatePay - 1] = Interpolate_Linear(xt, Rate_Pay_1F[LastFixingIdxPay], NGreed, 0.0) - Interpolate_Linear(xt, Rate_PayPowerSpread_1F[LastFixingIdxPay], NGreed, 0.0);
					ResultFixingRateCpnPay[2 * NCpnDatePay - 1] = Interpolate_Linear(xt, TempCpnArrayPay_1F, NGreed, 0.0);
					if (PayRangeAccrualFlag == 1)
					{
						ResultFixingRateCpnPay[NCpnDatePay - 1] /= (double)NBD_Fixing_to_End_Pay[NCpnDatePay - 1];
					}
				}
			}
		}
		else
		{
			t2 = Time[NTotalSimul - i];
			t1 = Time[NTotalSimul - 1 - i];
			df_t = Calc_Discount_Factor(ZeroDiscTerm, ZeroDiscRate, NZeroDiscRate, t1);
			df_T = Calc_Discount_Factor(ZeroDiscTerm, ZeroDiscRate, NZeroDiscRate, t2);
			vols = Interpolate_Linear(HWVolTerm, HWVol, NHWVol, t1);
			volt = Interpolate_Linear(HWVolTerm, HWVol, NHWVol, t2);
			vol1 = Interpolate_Linear(HWVolTerm, HWVol, NHWVol, (t1 + t2) / 2.0);
			Instant_FwdDF = df_T / df_t;
			if (TextFlag > 0)
			{
				ForPrintVariable[0] = (double)Today;
				ForPrintVariable[1] = t1;
				ForPrintVariable[2] = t2;
				ForPrintVariable[3] = Instant_FwdDF;
				DumppingTextDataArray(CalcFunctionName, SaveFileName, "DF_in_FDMTimeGreed", 4, ForPrintVariable);
			}
			deltat = t2 - t1;
			Instant_B_s_t = B_s_to_t(kappa1, t1, t2);
			Instant_QVTerm = HullWhiteQVTerm(t1, t2, kappa1, 1, HWVolTerm, &vol1);
			if (HW2FFlag > 0)
			{
				vols = Interpolate_Linear(HWVolTerm, HWVol2, NHWVol, t1);
				volt = Interpolate_Linear(HWVolTerm, HWVol2, NHWVol, t2);
				vol2 = Interpolate_Linear(HWVolTerm, HWVol2, NHWVol, (t1 + t2) / 2.0);
				Instant_B_s_t_2F = B_s_to_t(kappa2, t1, t2);
				Instant_QVTerm_2F = HullWhiteQVTerm(t1, t2, kappa2, 1, HWVolTerm, &vol2);
				Instant_Cross_QVTerm_2F = HullWhite2F_CrossTerm(t1, t2, kappa1, 1, HWVolTerm, &vol1, kappa2, HWVolTerm, &vol2, FactorCorrelation);

				for (idx1 = 0; idx1 < NGreed; idx1++)
				{
					PtT = Instant_FwdDF;
					Alpha_1Curve[idx1] = -deltat * 0.5 * (kappa1 * xt[idx1] / dxt + vol1 * vol1 / (dxt * dxt));
					Beta_1Curve[idx1] = (1.0 + deltat * vol1 * vol1 / (dxt * dxt)) + (1.0 / PtT - 1.0) * 0.5;
					Gamma_1Curve[idx1] = deltat * 0.5 * (kappa1 * xt[idx1] / dxt - vol1 * vol1 / (dxt * dxt));
				}

				for (idx2 = 0; idx2 < NGreed; idx2++)
				{
					PtT = Instant_FwdDF;
					Alpha_2Curve[idx2] = -deltat * 0.5 * (kappa2 * yt[idx2] / dyt + vol2 * vol2 / (dyt * dyt));
					Beta_2Curve[idx2] = (1.0 + deltat * vol2 * vol2 / (dyt * dyt)) + (1.0 / PtT - 1.0) * 0.5;
					Gamma_2Curve[idx2] = deltat * 0.5 * (kappa2 * yt[idx2] / dyt - vol2 * vol2 / (dyt * dyt));
				}

				b0 = Beta_1Curve[0] + 2.0 * Alpha_1Curve[0];
				c0 = Gamma_1Curve[0] - Alpha_1Curve[0];
				bN = Beta_1Curve[NGreed - 1] + 2.0 * Gamma_1Curve[NGreed - 1];
				aN = Alpha_1Curve[NGreed - 1] - Gamma_1Curve[NGreed - 1];
				Beta_1Curve[0] = b0;
				Gamma_1Curve[0] = c0;
				Beta_1Curve[NGreed - 1] = bN;
				Alpha_1Curve[NGreed - 1] = aN;

				ResultRHS_2F(NGreed, xt, yt, kappa1, kappa2, vol1, vol2, FactorCorrelation, dxt, dyt, deltat, FDMValue_2F, RHSValue_2F);
				Tri_diagonal_Matrix_Fast(Alpha_1Curve, Beta_1Curve, Gamma_1Curve, RHSValue_2F, NGreed, TempAlphaArray, TempBetaArray, TempGammaArray);
				TransposeMat(NGreed, RHSValue_2F);
				Copy2dMatrix(FDMValue_2F, RHSValue_2F, NGreed, NGreed);

				b0 = Beta_2Curve[0] + 2.0 * Alpha_2Curve[0];
				c0 = Gamma_2Curve[0] - Alpha_2Curve[0];
				bN = Beta_2Curve[NGreed - 1] + 2.0 * Gamma_2Curve[NGreed - 1];
				aN = Alpha_2Curve[NGreed - 1] - Gamma_2Curve[NGreed - 1];
				Beta_2Curve[0] = b0;
				Gamma_2Curve[0] = c0;
				Beta_2Curve[NGreed - 1] = bN;;
				Alpha_2Curve[NGreed - 1] = aN;
				ResultRHS_2F(NGreed, xt, yt, kappa1, kappa2, vol1, vol2, FactorCorrelation, dxt, dyt, deltat, FDMValue_2F, RHSValue_2F);
				Tri_diagonal_Matrix_Fast(Alpha_2Curve, Beta_2Curve, Gamma_2Curve, RHSValue_2F, NGreed, TempAlphaArray, TempBetaArray, TempGammaArray);
				TransposeMat(NGreed, RHSValue_2F);
				Copy2dMatrix(FDMValue_2F, RHSValue_2F, NGreed, NGreed);

			}
			else
			{
				for (idx1 = 0; idx1 < NGreed; idx1++)
				{
					PtT = Instant_FwdDF;
					Alpha_1Curve[idx1] = -deltat * 0.5 * (kappa1 * xt[idx1] / dxt + vol1 * vol1 / (dxt * dxt));
					Beta_1Curve[idx1] = (1.0 + deltat * vol1 * vol1 / (dxt * dxt)) + (1.0 / PtT - 1.0);
					Gamma_1Curve[idx1] = deltat * 0.5 * (kappa1 * xt[idx1] / dxt - vol1 * vol1 / (dxt * dxt));
				}

				b0 = Beta_1Curve[0] + 2.0 * Alpha_1Curve[0];
				c0 = Gamma_1Curve[0] - Alpha_1Curve[0];
				bN = Beta_1Curve[NGreed - 1] + 2.0 * Gamma_1Curve[NGreed - 1];
				aN = Alpha_1Curve[NGreed - 1] - Gamma_1Curve[NGreed - 1];
				Beta_1Curve[0] = b0;
				Gamma_1Curve[0] = c0;
				Beta_1Curve[NGreed - 1] = bN;;
				Alpha_1Curve[NGreed - 1] = aN;

				Tri_diagonal_Fast(Alpha_1Curve, Beta_1Curve, Gamma_1Curve, FDMValue_1F, NGreed, TempAlphaArray, TempBetaArray, TempGammaArray);
			}

			if (RcvRangeAccrualFlag == 1)
			{
				// Range Accrual Swap�� ��� �߰� 2026.05.26
				idxrcv = -1;

				for (j = 0; j < NCpnDateRcv; j++)
				{
					if (RcvFixingDate[j] <= Today && CpnDateRcv[j] > Today)
					{
						idxrcv = j;
						break;
					}
				}
				t2 = ((double)DayCountAtoB(PriceDate, RcvPaymentDate[idxrcv]))/365.;
				df_T = Calc_Discount_Factor(ZeroDiscTerm, ZeroDiscRate, NZeroDiscRate, t2);
				Instant_FwdDF = df_T / df_t;

				if (HW2FFlag > 0)
				{
					if (PowerSpreadFlagRcv == 0)
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							for (idx2 = 0; idx2 < NGreed; idx2++)
							{
								Rate_Rcv = Rate_Rcv_2F[NTotalSimul - 1 - i][idx1][idx2];
								RgCpnRcv = 0.;
								if (Structured_Rcv[idxrcv] > 0)
								{
									Rate = SlopeOfFixingRate_Rcv[idxrcv] * Rate_Rcv;
									if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[idxrcv] * Rate_Rcv + RangeCpn_Rcv[idxrcv]/ (double)NBD_Fixing_to_End_Rcv[idxrcv];//�ӽû��� * Instant_FwdDF ;
								}

								if (ZeroCouponFlagRcv[idxrcv] == 0)
								{
									RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * DeltatRcv[idxrcv])), RoundingRcv);
								}
								else if (ZeroCouponFlagRcv[idxrcv] == 1)
								{
									deltat_fixing_to_pay = DeltatRcv[idxrcv];
									RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[idxrcv] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
								}
								else
								{
									deltat_fixing_to_pay = DeltatRcv[idxrcv];
									RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
								}
								TempCpnArrayRcv_2F[idx1][idx2] = RcvCpn;
								FDMValue_2F[idx1][idx2] += RcvCpn * Instant_FwdDF;
							}
						}
						ResultFixingRateCpnRcv[idxrcv] += Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Rcv_2F[NTotalSimul - 1 - i], 0.0, 0.0) / (double)NBD_Fixing_to_End_Rcv[idxrcv];
						ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] += Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayRcv_2F, 0.0, 0.0);
					}
					else
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							for (idx2 = 0; idx2 < NGreed; idx2++)
							{
								Rate_Rcv = Rate_Rcv_2F[NTotalSimul - 1 - i][idx1][idx2];
								Rate_Rcv_p = Rate_RcvPowerSpread_2F[NTotalSimul - 1 - i][idx1][idx2];
								RgCpnRcv = 0.;
								if (Structured_Rcv[idxrcv] > 0)
								{
									Rate = SlopeOfFixingRate_Rcv[idxrcv] * (Rate_Rcv - Rate_Rcv_p);
									if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[idxrcv] * (Rate_Rcv - Rate_Rcv_p) + RangeCpn_Rcv[idxrcv] / (double)NBD_Fixing_to_End_Rcv[idxrcv];//�ӽû��� * Instant_FwdDF ;
								}

								if (ZeroCouponFlagRcv[idxrcv] == 0)
								{
									RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * DeltatRcv[idxrcv])), RoundingRcv);
								}
								else if (ZeroCouponFlagRcv[idxrcv] == 1)
								{
									deltat_fixing_to_pay = DeltatRcv[idxrcv];
									RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[idxrcv] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
								}
								else
								{
									deltat_fixing_to_pay = DeltatRcv[idxrcv];
									RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
								}
								TempCpnArrayRcv_2F[idx1][idx2] = RcvCpn;
								FDMValue_2F[idx1][idx2] += RcvCpn * Instant_FwdDF;
							}
						}
						ResultFixingRateCpnRcv[idxrcv] += (Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Rcv_2F[NTotalSimul - 1 - i], 0.0, 0.0) - Calc_Volatility(NGreed, NGreed, xt, yt, Rate_RcvPowerSpread_2F[NTotalSimul - 1 - i], 0.0, 0.0)) / (double)NBD_Fixing_to_End_Rcv[idxrcv];
						ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] += Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayRcv_2F, 0.0, 0.0) ;
					}
				}
				else
				{
					if (PowerSpreadFlagRcv == 0)
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							Rate_Rcv = Rate_Rcv_1F[NTotalSimul - 1 - i][idx1];
							RgCpnRcv = 0.;
							if (Structured_Rcv[idxrcv] > 0)
							{
								Rate = SlopeOfFixingRate_Rcv[idxrcv] * Rate_Rcv;
								if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[idxrcv] * Rate_Rcv + RangeCpn_Rcv[idxrcv] / (double)NBD_Fixing_to_End_Rcv[idxrcv];//�ӽû��� * Instant_FwdDF;
							}

							if (ZeroCouponFlagRcv[idxrcv] == 0)
							{
								RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * DeltatRcv[idxrcv])), RoundingRcv);
							}
							else if (ZeroCouponFlagRcv[idxrcv] == 1)
							{
								deltat_fixing_to_pay = DeltatRcv[idxrcv];
								RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[idxrcv] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
							}
							else
							{
								deltat_fixing_to_pay = DeltatRcv[idxrcv];
								RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
							}
							TempCpnArrayRcv_1F[idx1] = RcvCpn;
							FDMValue_1F[idx1] += RcvCpn * Instant_FwdDF;
						}
						ResultFixingRateCpnRcv[idxrcv] += Interpolate_Linear(xt, Rate_Rcv_1F[NTotalSimul - 1 - i], NGreed, 0.0) / (double)NBD_Fixing_to_End_Rcv[idxrcv];
						ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] += Interpolate_Linear(xt, TempCpnArrayRcv_1F, NGreed, 0.0);
					}
					else
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							Rate_Rcv = Rate_Rcv_1F[NTotalSimul - 1 - i][idx1];
							Rate_Rcv_p = Rate_RcvPowerSpread_1F[NTotalSimul - 1 - i][idx1];
							RgCpnRcv = 0.;
							if (Structured_Rcv[idxrcv] > 0)
							{
								Rate = SlopeOfFixingRate_Rcv[idxrcv] * (Rate_Rcv - Rate_Rcv_p);
								if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[idxrcv] * (Rate_Rcv - Rate_Rcv_p) + RangeCpn_Rcv[idxrcv]  / (double)NBD_Fixing_to_End_Rcv[idxrcv];//�ӽû��� * Instant_FwdDF;
							}

							if (ZeroCouponFlagRcv[idxrcv] == 0)
							{
								RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * DeltatRcv[idxrcv])), RoundingRcv);
							}
							else if (ZeroCouponFlagRcv[idxrcv] == 1)
							{
								deltat_fixing_to_pay = DeltatRcv[idxrcv];
								RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[idxrcv] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
							}
							else
							{
								deltat_fixing_to_pay = DeltatRcv[idxrcv];
								RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
							}

							TempCpnArrayRcv_1F[idx1] = RcvCpn;
							FDMValue_1F[idx1] += RcvCpn * Instant_FwdDF;
						}
						ResultFixingRateCpnRcv[idxrcv] += Interpolate_Linear(xt, Rate_Rcv_1F[NTotalSimul - 1 - i], NGreed, 0.0) / (double)NBD_Fixing_to_End_Rcv[idxrcv];
						ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] += Interpolate_Linear(xt, TempCpnArrayRcv_1F, NGreed, 0.0) ;
					}
				}
				temp = 0.;
			}

			if (PayRangeAccrualFlag == 1)
			{
				// Range Accrual Swap�� ��� �߰� 2026.05.26
				idxpay = -1;

				for (j = 0; j < NCpnDatePay; j++)
				{
					if (PayFixingDate[j] <= Today && CpnDatePay[j] > Today)
					{
						idxpay = j;
						break;
					}
				}
				t2 = ((double)DayCountAtoB(PriceDate, PayPaymentDate[idxpay])) / 365.;
				df_T = Calc_Discount_Factor(ZeroDiscTerm, ZeroDiscRate, NZeroDiscRate, t2);
				Instant_FwdDF = df_T / df_t;

				if (HW2FFlag > 0)
				{
					if (PowerSpreadFlagPay == 0)
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							for (idx2 = 0; idx2 < NGreed; idx2++)
							{
								Rate_Pay = Rate_Pay_2F[NTotalSimul - 1 - i][idx1][idx2];
								RgCpnPay = 0.;
								if (Structured_Pay[idxpay] > 0)
								{
									Rate = SlopeOfFixingRate_Pay[idxpay] * Rate_Pay;
									if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[idxpay] * Rate_Pay + RangeCpn_Pay[idxpay] / (double)NBD_Fixing_to_End_Pay[idxpay];//�ӽû��� * Instant_FwdDF ;
								}

								if (ZeroCouponFlagPay[idxpay] == 0)
								{
									PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * DeltatPay[idxpay])), RoundingPay);
								}
								else if (ZeroCouponFlagPay[idxpay] == 1)
								{
									deltat_fixing_to_pay = DeltatPay[idxpay];
									PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[idxpay] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
								}
								else
								{
									deltat_fixing_to_pay = DeltatPay[idxpay];
									PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
								}
								TempCpnArrayPay_2F[idx1][idx2] = PayCpn;
								FDMValue_2F[idx1][idx2] += PayCpn * Instant_FwdDF;
							}
						}
						ResultFixingRateCpnPay[idxpay] += Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Pay_2F[NTotalSimul - 1 - i], 0.0, 0.0) / (double)NBD_Fixing_to_End_Pay[idxpay];
						ResultFixingRateCpnPay[NCpnDatePay + idxpay] += Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayPay_2F, 0.0, 0.0) ;
					}
					else
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							for (idx2 = 0; idx2 < NGreed; idx2++)
							{
								Rate_Pay = Rate_Pay_2F[NTotalSimul - 1 - i][idx1][idx2];
								Rate_Pay_p = Rate_PayPowerSpread_2F[NTotalSimul - 1 - i][idx1][idx2];
								RgCpnPay = 0.;
								if (Structured_Pay[idxpay] > 0)
								{
									Rate = SlopeOfFixingRate_Pay[idxpay] * (Rate_Pay - Rate_Pay_p);
									if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[idxpay] * (Rate_Pay - Rate_Pay_p) + RangeCpn_Pay[idxpay] / (double)NBD_Fixing_to_End_Pay[idxpay];//�ӽû��� * Instant_FwdDF ;
								}

								if (ZeroCouponFlagPay[idxpay] == 0)
								{
									PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * DeltatPay[idxpay])), RoundingPay);
								}
								else if (ZeroCouponFlagPay[idxpay] == 1)
								{
									deltat_fixing_to_pay = DeltatPay[idxpay];
									PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[idxpay] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
								}
								else
								{
									deltat_fixing_to_pay = DeltatPay[idxpay];
									PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
								}
								TempCpnArrayPay_2F[idx1][idx2] = PayCpn;
								FDMValue_2F[idx1][idx2] += PayCpn * Instant_FwdDF;
							}
						}
						ResultFixingRateCpnPay[idxpay] += (Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Pay_2F[NTotalSimul - 1 - i], 0.0, 0.0) - Calc_Volatility(NGreed, NGreed, xt, yt, Rate_PayPowerSpread_2F[NTotalSimul - 1 - i], 0.0, 0.0)) / (double)NBD_Fixing_to_End_Pay[idxpay];
						ResultFixingRateCpnPay[NCpnDatePay + idxpay] += Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayPay_2F, 0.0, 0.0);
					}
				}
				else
				{
					if (PowerSpreadFlagPay == 0)
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							Rate_Pay = Rate_Pay_1F[NTotalSimul - 1 - i][idx1];
							RgCpnPay = 0.;
							if (Structured_Pay[idxpay] > 0)
							{
								Rate = SlopeOfFixingRate_Pay[idxpay] * Rate_Pay;
								if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[idxpay] * Rate_Pay + RangeCpn_Pay[idxpay] / (double)NBD_Fixing_to_End_Pay[idxpay];//�ӽû��� * Instant_FwdDF ;
							}

							if (ZeroCouponFlagPay[idxpay] == 0)
							{
								PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * DeltatPay[idxpay])), RoundingPay);
							}
							else if (ZeroCouponFlagPay[idxpay] == 1)
							{
								deltat_fixing_to_pay = DeltatPay[idxpay];
								PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[idxpay] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
							}
							else
							{
								deltat_fixing_to_pay = DeltatPay[idxpay];
								PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
							}
							TempCpnArrayPay_1F[idx1] = PayCpn;
							FDMValue_1F[idx1] += PayCpn * Instant_FwdDF;
						}
						ResultFixingRateCpnPay[idxpay] += Interpolate_Linear(xt, Rate_Pay_1F[NTotalSimul - 1 - i], NGreed, 0.0) / (double)NBD_Fixing_to_End_Pay[idxpay];
						ResultFixingRateCpnPay[NCpnDatePay + idxpay] += Interpolate_Linear(xt, TempCpnArrayPay_1F, NGreed, 0.0);
					}
					else
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							Rate_Pay = Rate_Pay_1F[NTotalSimul - 1 - i][idx1];
							Rate_Pay_p = Rate_PayPowerSpread_1F[NTotalSimul - 1 - i][idx1];
							RgCpnPay = 0.;
							if (Structured_Pay[idxpay] > 0)
							{
								Rate = SlopeOfFixingRate_Pay[idxpay] * (Rate_Pay - Rate_Pay_p);
								if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[idxpay] * (Rate_Pay - Rate_Pay_p) + RangeCpn_Pay[idxpay] / (double)NBD_Fixing_to_End_Pay[idxpay];//�ӽû��� *Instant_FwdDF;
							}

							if (ZeroCouponFlagPay[idxpay] == 0)
							{
								PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * DeltatPay[idxpay])), RoundingPay);
							}
							else if (ZeroCouponFlagPay[idxpay] == 1)
							{
								deltat_fixing_to_pay = DeltatPay[idxpay];
								PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[idxpay] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
							}
							else
							{
								deltat_fixing_to_pay = DeltatPay[idxpay];
								PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
							}

							TempCpnArrayPay_1F[idx1] = PayCpn;
							FDMValue_1F[idx1] += PayCpn * Instant_FwdDF;
						}
						ResultFixingRateCpnPay[idxpay] += Interpolate_Linear(xt, Rate_Pay_1F[NTotalSimul - 1 - i], NGreed, 0.0) / (double)NBD_Fixing_to_End_Pay[idxpay];
						ResultFixingRateCpnPay[NCpnDatePay + idxpay] += Interpolate_Linear(xt, TempCpnArrayPay_1F, NGreed, 0.0);
					}
				}
				temp = 0.;
			}

			if (Today <= PriceDate)
			{
				// ���� ������ �����̶�� FDM ����
				if (RcvRangeAccrualFlag == 1)
				{
					idxrcv = -1;
					// RA�� ��� �̹� Fixing�� RA ���������� ����ϰ� ����
					for (i = 0; i < NCpnDateRcv; i++)
					{
						if (RcvFixingDate[i] < PriceDate && RcvPaymentDate[i] > PriceDate)
						{
							idxrcv = i;
							break;
						}
					}
					NHist = 0;
					n = 0;
					for (j = 0; j < NRcvRateHistory; j++)
					{
						if (RcvRateHistoryDate[j] > RcvFixingDate[idxrcv] && RcvRateHistoryDate[j] < PriceDate)
						{
							if (RcvRateHistory[j] < RangeMaxMinRcv[0] && RcvRateHistory[j]> RangeMaxMinRcv[1]) n += 1;
							NHist += 1;
						}
					}
					w1 = ((double)DayCountAtoB(RcvFixingDate[idxrcv], PriceDate)) / ((double)DayCountAtoB(RcvFixingDate[idxrcv], CpnDateRcv[idxrcv]));
					w2 = ((double)DayCountAtoB(PriceDate, CpnDateRcv[idxrcv])) / ((double)DayCountAtoB(RcvFixingDate[idxrcv], CpnDateRcv[idxrcv]));
					if (NHist > 0)
					{
						ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RangeCpn_Rcv[idxrcv]) * DeltatRcv[idxrcv])), RoundingRcv) * w1 * ((double)n) / ((double)NHist) + ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] * w2;
					}

					idxpay = -1;
					for (i = 0; i < NCpnDatePay; i++)
					{
						if (PayFixingDate[i] < PriceDate && PayPaymentDate[i] > PriceDate)
						{
							idxpay = i;
							break;
						}
					}
					NHist = 0;
					n = 0;
					for (j = 0; j < NPayRateHistory; j++)
					{
						if (PayRateHistoryDate[j] > PayFixingDate[idxpay] && PayRateHistoryDate[j] < PriceDate)
						{
							if (PayRateHistory[j] < RangeMaxMinPay[0] && PayRateHistory[j]> RangeMaxMinPay[1]) n += 1;
							NHist += 1;
						}
					}
					w1 = ((double)DayCountAtoB(PayFixingDate[idxpay], PriceDate)) / ((double)DayCountAtoB(PayFixingDate[idxpay], CpnDatePay[idxpay]));
					w2 = ((double)DayCountAtoB(PriceDate, CpnDatePay[idxpay])) / ((double)DayCountAtoB(PayFixingDate[idxpay], CpnDatePay[idxpay]));
					if (NHist > 0)
					{
						ResultFixingRateCpnPay[NCpnDatePay + idxpay] = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RangeCpn_Pay[idxpay]) * DeltatPay[idxpay])), RoundingPay) * w1 * ((double)n) / ((double)NHist) + ResultFixingRateCpnPay[NCpnDatePay + idxpay] * w2;
					}
				}

				break;
			}

			if (i != 0 && isin_Longtype(Today, RcvPaymentDate, NCpnDateRcv) && RcvRangeAccrualFlag == 0)
			{
				idxrcv = -1;
				for (idxrcv = 0; idxrcv < NCpnDateRcv; idxrcv++)
				{
					if (RcvPaymentDate[idxrcv] == Today)
					{
						break;
					}
				}

				idxrcvfix = -1;
				for (j = 0; j < NTotalSimul; j++)
				{
					if (TotalArrayDateSimul[j] == RcvFixingDate[idxrcv])
					{
						idxrcvfix = j;
						break;
					}
				}

				if (RcvPaymentDate[idxrcv] > PriceDate)
				{
					if (idxrcvfix >= 0)
					{
						if (TotalArrayDateSimul[idxrcvfix] >= PriceDate)
						{
							if (HW2FFlag > 0)
							{
								if (PowerSpreadFlagRcv == 0)
								{
									for (idx1 = 0; idx1 < NGreed; idx1++)
									{
										for (idx2 = 0; idx2 < NGreed; idx2++)
										{
											Rate_Rcv = Rate_Rcv_2F[idxrcvfix][idx1][idx2];
											RgCpnRcv = 0.;
											if (Structured_Rcv[idxrcv] > 0)
											{
												Rate = SlopeOfFixingRate_Rcv[idxrcv] * Rate_Rcv;
												if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[idxrcv] * Rate_Rcv + RangeCpn_Rcv[idxrcv];
											}

											if (ZeroCouponFlagRcv[idxrcv] == 0)
											{
												RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * DeltatRcv[idxrcv])), RoundingRcv);
											}
											else if (ZeroCouponFlagRcv[idxrcv] == 1)
											{
												deltat_fixing_to_pay = DeltatRcv[idxrcv];
												RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[idxrcv] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
											}
											else
											{
												deltat_fixing_to_pay = DeltatRcv[idxrcv];
												RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
											}
											TempCpnArrayRcv_2F[idx1][idx2] = RcvCpn;
											FDMValue_2F[idx1][idx2] += RcvCpn;
										}
									}
									ResultFixingRateCpnRcv[idxrcv] = Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Rcv_2F[idxrcvfix], 0.0, 0.0);
									ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] = Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayRcv_2F, 0.0, 0.0);
								}
								else
								{
									for (idx1 = 0; idx1 < NGreed; idx1++)
									{
										for (idx2 = 0; idx2 < NGreed; idx2++)
										{
											Rate_Rcv = Rate_Rcv_2F[idxrcvfix][idx1][idx2];
											Rate_Rcv_p = Rate_RcvPowerSpread_2F[idxrcvfix][idx1][idx2];
											RgCpnRcv = 0.;
											if (Structured_Rcv[idxrcv] > 0)
											{
												Rate = SlopeOfFixingRate_Rcv[idxrcv] * (Rate_Rcv - Rate_Rcv_p);
												if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[idxrcv] * (Rate_Rcv - Rate_Rcv_p) + RangeCpn_Rcv[idxrcv];
											}

											if (ZeroCouponFlagRcv[idxrcv] == 0)
											{
												RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * DeltatRcv[idxrcv])), RoundingRcv);
											}
											else if (ZeroCouponFlagRcv[idxrcv] == 1)
											{
												deltat_fixing_to_pay = DeltatRcv[idxrcv];
												RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[idxrcv] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
											}
											else
											{
												deltat_fixing_to_pay = DeltatRcv[idxrcv];
												RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
											}
											TempCpnArrayRcv_2F[idx1][idx2] = RcvCpn;
											FDMValue_2F[idx1][idx2] += RcvCpn;
										}
									}
									ResultFixingRateCpnRcv[idxrcv] = Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Rcv_2F[idxrcvfix], 0.0, 0.0) - Calc_Volatility(NGreed, NGreed, xt, yt, Rate_RcvPowerSpread_2F[idxrcvfix], 0.0, 0.0);
									ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] = Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayRcv_2F, 0.0, 0.0);
								}
							}
							else
							{
								if (PowerSpreadFlagRcv == 0)
								{
									for (idx1 = 0; idx1 < NGreed; idx1++)
									{
										Rate_Rcv = Rate_Rcv_1F[idxrcvfix][idx1];
										RgCpnRcv = 0.;
										if (Structured_Rcv[idxrcv] > 0)
										{
											Rate = SlopeOfFixingRate_Rcv[idxrcv] * Rate_Rcv;
											if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[idxrcv] * Rate_Rcv + RangeCpn_Rcv[idxrcv];
										}

										if (ZeroCouponFlagRcv[idxrcv] == 0)
										{
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * DeltatRcv[idxrcv])), RoundingRcv);
										}
										else if (ZeroCouponFlagRcv[idxrcv] == 1)
										{
											deltat_fixing_to_pay = DeltatRcv[idxrcv];
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[idxrcv] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
										}
										else
										{
											deltat_fixing_to_pay = DeltatRcv[idxrcv];
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
										}
										TempCpnArrayRcv_1F[idx1] = RcvCpn;
										FDMValue_1F[idx1] += RcvCpn;
									}
									ResultFixingRateCpnRcv[idxrcv] = Interpolate_Linear(xt, Rate_Rcv_1F[idxrcvfix], NGreed, 0.0);
									ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] = Interpolate_Linear(xt, TempCpnArrayRcv_1F, NGreed, 0.0);
								}
								else
								{
									for (idx1 = 0; idx1 < NGreed; idx1++)
									{
										Rate_Rcv = Rate_Rcv_1F[idxrcvfix][idx1];
										Rate_Rcv_p = Rate_RcvPowerSpread_1F[idxrcvfix][idx1];
										RgCpnRcv = 0.;
										if (Structured_Rcv[idxrcv] > 0)
										{
											Rate = SlopeOfFixingRate_Rcv[idxrcv] * (Rate_Rcv - Rate_Rcv_p);
											if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[idxrcv] * (Rate_Rcv - Rate_Rcv_p) + RangeCpn_Rcv[idxrcv];
										}

										if (ZeroCouponFlagRcv[idxrcv] == 0)
										{
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * DeltatRcv[idxrcv])), RoundingRcv);
										}
										else if (ZeroCouponFlagRcv[idxrcv] == 1)
										{
											deltat_fixing_to_pay = DeltatRcv[idxrcv];
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[idxrcv] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
										}
										else
										{
											deltat_fixing_to_pay = DeltatRcv[idxrcv];
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
										}

										TempCpnArrayRcv_1F[idx1] = RcvCpn;
										FDMValue_1F[idx1] += RcvCpn;
									}
									ResultFixingRateCpnRcv[idxrcv] = Interpolate_Linear(xt, Rate_Rcv_1F[idxrcvfix], NGreed, 0.0);
									ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] = Interpolate_Linear(xt, TempCpnArrayRcv_1F, NGreed, 0.0);
								}
							}
						}
						else if (isin_Longtype(TotalArrayDateSimul[idxrcvfix], RcvRateHistoryDate, NRcvRateHistory))
						{
							for (idxhist = 0; idxhist < NRcvRateHistory; idxhist++)
							{
								if (TotalArrayDateSimul[idxrcvfix] == RcvRateHistoryDate[idxhist])
								{
									break;
								}
							}
							Rate_Rcv = RcvRateHistory[idxhist];
							RgCpnRcv = 0.;
							if (Structured_Rcv[idxrcv] > 0)
							{
								Rate = SlopeOfFixingRate_Rcv[idxrcv] * Rate_Rcv;
								if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[idxrcv] * Rate_Rcv + RangeCpn_Rcv[idxrcv];
							}

							if (ZeroCouponFlagRcv[idxrcv] == 0)
							{
								RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * DeltatRcv[idxrcv])), RoundingRcv);
							}
							else if (ZeroCouponFlagRcv[idxrcv] == 1)
							{
								deltat_fixing_to_pay = DeltatRcv[idxrcv];
								RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[idxrcv] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
							}
							else
							{
								deltat_fixing_to_pay = DeltatRcv[idxrcv];
								RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
							}
							if (HW2FFlag == 0) for (idx1 = 0; idx1 < NGreed; idx1++) FDMValue_1F[idx1] += RcvCpn;
							else for (idx1 = 0; idx1 < NGreed; idx1++) for (idx2 = 0; idx2 < NGreed; idx2++) FDMValue_2F[idx1][idx2] += RcvCpn;
							ResultFixingRateCpnRcv[idxrcv] = Rate_Rcv;
							ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] = RcvCpn;
						}
					}
					else if (idxrcvfix == -1 && RcvFixingDate[idxrcv] < PriceDate && RcvPaymentDate[idxrcv] > PriceDate && isin_Longtype(RcvFixingDate[idxrcv], RcvRateHistoryDate, NRcvRateHistory))
					{
						for (idxhist = 0; idxhist < NRcvRateHistory; idxhist++)
						{
							if (RcvFixingDate[idxrcv] == RcvRateHistoryDate[idxhist])
							{
								break;
							}
						}
						Rate_Rcv = RcvRateHistory[idxhist];
						RgCpnRcv = 0.;
						if (Structured_Rcv[idxrcv] > 0)
						{
							Rate = SlopeOfFixingRate_Rcv[idxrcv] * Rate_Rcv;
							if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[idxrcv] * Rate_Rcv + RangeCpn_Rcv[idxrcv];
						}

						if (ZeroCouponFlagRcv[idxrcv] == 0)
						{
							RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * DeltatRcv[idxrcv])), RoundingRcv);
						}
						else if (ZeroCouponFlagRcv[idxrcv] == 1)
						{
							deltat_fixing_to_pay = DeltatRcv[idxrcv];
							RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], pow(1.0 + FixedRate_Rcv[idxrcv] + RgCpnRcv, deltat_fixing_to_pay) - 1.0)), RoundingRcv);
						}
						else
						{
							deltat_fixing_to_pay = DeltatRcv[idxrcv];
							RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[idxrcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
						}
						if (HW2FFlag == 0) for (idx1 = 0; idx1 < NGreed; idx1++) FDMValue_1F[idx1] += RcvCpn;
						else for (idx1 = 0; idx1 < NGreed; idx1++) for (idx2 = 0; idx2 < NGreed; idx2++) FDMValue_2F[idx1][idx2] += RcvCpn;
						ResultFixingRateCpnRcv[idxrcv] = Rate_Rcv;
						ResultFixingRateCpnRcv[NCpnDateRcv + idxrcv] = RcvCpn;
					}
				}
				else
				{

				}
			}

			if (i != 0 && isin_Longtype(Today, PayPaymentDate, NCpnDatePay) && PayRangeAccrualFlag == 0)
			{
				idxpay = -1;
				for (idxpay = 0; idxpay < NCpnDatePay; idxpay++)
				{
					if (PayPaymentDate[idxpay] == Today)
					{
						break;
					}
				}

				idxpayfix = -1;
				for (j = 0; j < NTotalSimul; j++)
				{
					if (TotalArrayDateSimul[j] == PayFixingDate[idxpay])
					{
						idxpayfix = j;
						break;
					}
				}

				if (PayPaymentDate[idxpay] > PriceDate)
				{
					if (idxpayfix >= 0)
					{
						if (TotalArrayDateSimul[idxpayfix] >= PriceDate)
						{
							if (HW2FFlag > 0)
							{
								if (PowerSpreadFlagPay == 0)
								{
									for (idx1 = 0; idx1 < NGreed; idx1++)
									{
										for (idx2 = 0; idx2 < NGreed; idx2++)
										{
											Rate_Pay = Rate_Pay_2F[idxpayfix][idx1][idx2];
											RgCpnPay = 0.;
											if (Structured_Pay[idxpay] > 0)
											{
												Rate = SlopeOfFixingRate_Pay[idxpay] * Rate_Pay;
												if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[idxpay] * Rate_Pay + RangeCpn_Pay[idxpay];
											}

											if (ZeroCouponFlagPay[idxpay] == 0)
											{
												PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * DeltatPay[idxpay])), RoundingPay);
											}
											else if (ZeroCouponFlagPay[idxpay] == 1)
											{
												deltat_fixing_to_pay = DeltatPay[idxpay];
												PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[idxpay] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
											}
											else
											{
												deltat_fixing_to_pay = DeltatPay[idxpay];
												PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
											}
											TempCpnArrayPay_2F[idx1][idx2] = PayCpn;
											if (BondFlag == 0) FDMValue_2F[idx1][idx2] -= PayCpn;
										}
									}
									ResultFixingRateCpnPay[idxpay] = Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Pay_2F[idxpayfix], 0.0, 0.0);
									ResultFixingRateCpnPay[NCpnDatePay + idxpay] = Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayPay_2F, 0.0, 0.0);
								}
								else
								{
									for (idx1 = 0; idx1 < NGreed; idx1++)
									{
										for (idx2 = 0; idx2 < NGreed; idx2++)
										{
											Rate_Pay = Rate_Pay_2F[idxpayfix][idx1][idx2];
											Rate_Pay_p = Rate_PayPowerSpread_2F[idxpayfix][idx1][idx2];
											RgCpnPay = 0.;
											if (Structured_Pay[idxpay] > 0)
											{
												Rate = SlopeOfFixingRate_Pay[idxpay] * (Rate_Pay - Rate_Pay_p);
												if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[idxpay] * (Rate_Pay - Rate_Pay_p) + RangeCpn_Pay[idxpay];
											}

											if (ZeroCouponFlagPay[idxpay] == 0)
											{
												PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * DeltatPay[idxpay])), RoundingPay);
											}
											else if (ZeroCouponFlagPay[idxpay] == 1)
											{
												deltat_fixing_to_pay = DeltatPay[idxpay];
												PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[idxpay] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
											}
											else
											{
												deltat_fixing_to_pay = DeltatPay[idxpay];
												PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
											}
											TempCpnArrayPay_2F[idx1][idx2] = PayCpn;
											if (BondFlag == 0) FDMValue_2F[idx1][idx2] -= PayCpn;
										}
									}
									ResultFixingRateCpnPay[idxpay] = Calc_Volatility(NGreed, NGreed, xt, yt, Rate_Pay_2F[idxpayfix], 0.0, 0.0) - Calc_Volatility(NGreed, NGreed, xt, yt, Rate_PayPowerSpread_2F[idxpayfix], 0.0, 0.0);
									ResultFixingRateCpnPay[NCpnDatePay + idxpay] = Calc_Volatility(NGreed, NGreed, xt, yt, TempCpnArrayPay_2F, 0.0, 0.0);
								}
							}
							else
							{
								if (PowerSpreadFlagPay == 0)
								{
									for (idx1 = 0; idx1 < NGreed; idx1++)
									{
										Rate_Pay = Rate_Pay_1F[idxpayfix][idx1];
										RgCpnPay = 0.;
										if (Structured_Pay[idxpay] > 0)
										{
											Rate = SlopeOfFixingRate_Pay[idxpay] * Rate_Pay;
											if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[idxpay] * Rate_Pay + RangeCpn_Pay[idxpay];
										}

										if (ZeroCouponFlagPay[idxpay] == 0)
										{
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * DeltatPay[idxpay])), RoundingPay);
										}
										else if (ZeroCouponFlagPay[idxpay] == 1)
										{
											deltat_fixing_to_pay = DeltatPay[idxpay];
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[idxpay] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
										}
										else
										{
											deltat_fixing_to_pay = DeltatPay[idxpay];
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
										}
										TempCpnArrayPay_1F[idx1] = PayCpn;
										if (BondFlag == 0) FDMValue_1F[idx1] -= PayCpn;
									}
									ResultFixingRateCpnPay[idxpay] = Interpolate_Linear(xt, Rate_Pay_1F[idxpayfix], NGreed, 0.0);
									ResultFixingRateCpnPay[NCpnDatePay + idxpay] = Interpolate_Linear(xt, TempCpnArrayPay_1F, NGreed, 0.0);
								}
								else
								{
									for (idx1 = 0; idx1 < NGreed; idx1++)
									{
										Rate_Pay = Rate_Pay_1F[idxpayfix][idx1];
										Rate_Pay_p = Rate_PayPowerSpread_1F[idxpayfix][idx1];
										RgCpnPay = 0.;
										if (Structured_Pay[idxpay] > 0)
										{
											Rate = SlopeOfFixingRate_Pay[idxpay] * (Rate_Pay - Rate_Pay_p);
											if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[idxpay] * (Rate_Pay - Rate_Pay_p) + RangeCpn_Pay[idxpay];
										}

										if (ZeroCouponFlagPay[idxpay] == 0)
										{
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * DeltatPay[idxpay])), RoundingPay);
										}
										else if (ZeroCouponFlagPay[idxpay] == 1)
										{
											deltat_fixing_to_pay = DeltatPay[idxpay];
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[idxpay] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
										}
										else
										{
											deltat_fixing_to_pay = DeltatPay[idxpay];
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
										}
										TempCpnArrayPay_1F[idx1] = PayCpn;
										if (BondFlag == 0) FDMValue_1F[idx1] -= PayCpn;
									}
									ResultFixingRateCpnPay[idxpay] = Interpolate_Linear(xt, Rate_Pay_1F[idxpayfix], NGreed, 0.0);
									ResultFixingRateCpnPay[NCpnDatePay + idxpay] = Interpolate_Linear(xt, TempCpnArrayPay_1F, NGreed, 0.0);
								}
							}
						}
						else if (isin_Longtype(TotalArrayDateSimul[idxpayfix], PayRateHistoryDate, NPayRateHistory))// History ����
						{
							for (idxhist = 0; idxhist < NPayRateHistory; idxhist++)
							{
								if (TotalArrayDateSimul[idxpayfix] == PayRateHistoryDate[idxhist])
								{
									break;
								}
							}
							Rate_Pay = PayRateHistory[idxhist];
							RgCpnPay = 0.;
							if (Structured_Pay[idxpay] > 0)
							{
								Rate = SlopeOfFixingRate_Pay[idxpay] * Rate_Pay;
								if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[idxpay] * Rate_Pay + RangeCpn_Pay[idxpay];
							}

							if (ZeroCouponFlagPay[idxpay] == 0)
							{
								PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * DeltatPay[idxpay])), RoundingPay);
							}
							else if (ZeroCouponFlagPay[idxpay] == 1)
							{
								deltat_fixing_to_pay = DeltatPay[idxpay];
								PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[idxpay] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
							}
							else
							{
								deltat_fixing_to_pay = DeltatPay[idxpay];
								PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
							}
							if (HW2FFlag == 0) for (idx1 = 0; idx1 < NGreed; idx1++) FDMValue_1F[idx1] -= PayCpn * (double)(BondFlag == 0);
							else for (idx1 = 0; idx1 < NGreed; idx1++) for (idx2 = 0; idx2 < NGreed; idx2++) FDMValue_2F[idx1][idx2] -= PayCpn * (double)(BondFlag == 0);
							ResultFixingRateCpnPay[idxpay] = Rate_Pay;
							ResultFixingRateCpnPay[NCpnDatePay + idxpay] = PayCpn;
						}
					}
					else if (idxpayfix == -1 && PayFixingDate[idxpay] < PriceDate && PayPaymentDate[idxpay] > PriceDate && isin_Longtype(PayFixingDate[idxpay], PayRateHistoryDate, NPayRateHistory))
					{
						for (idxhist = 0; idxhist < NPayRateHistory; idxhist++)
						{
							if (PayFixingDate[idxpay] == PayRateHistoryDate[idxhist])
							{
								break;
							}
						}
						Rate_Pay = PayRateHistory[idxhist];
						RgCpnPay = 0.;
						if (Structured_Pay[idxpay] > 0)
						{
							Rate = SlopeOfFixingRate_Pay[idxpay] * Rate_Pay;
							if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[idxpay] * Rate_Pay + RangeCpn_Pay[idxpay];
						}

						if (ZeroCouponFlagPay[idxpay] == 0)
						{
							PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * DeltatPay[idxpay])), RoundingPay);
						}
						else if (ZeroCouponFlagPay[idxpay] == 1)
						{
							deltat_fixing_to_pay = DeltatPay[idxpay];
							PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], pow(1.0 + FixedRate_Pay[idxpay] + RgCpnPay, deltat_fixing_to_pay) - 1.0)), RoundingPay);
						}
						else
						{
							deltat_fixing_to_pay = DeltatPay[idxpay];
							PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[idxpay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
						}
						if (HW2FFlag == 0) for (idx1 = 0; idx1 < NGreed; idx1++) FDMValue_1F[idx1] -= PayCpn * (double)(BondFlag == 0);
						else for (idx1 = 0; idx1 < NGreed; idx1++) for (idx2 = 0; idx2 < NGreed; idx2++) FDMValue_2F[idx1][idx2] -= PayCpn * (double)(BondFlag == 0);
						ResultFixingRateCpnPay[idxpay] = Rate_Pay;
						ResultFixingRateCpnPay[NCpnDatePay + idxpay] = PayCpn;
					}
				}
				else
				{

				}
			}

			//if (RcvRangeAccrualFlag == 0 || PayRangeAccrualFlag == 0)
			TodayIsOptionDate = (Today <= OptionPayDate[nextoptidx] && Today >= OptionDate[nextoptidx]);
			if (i != 0 && NOption > 0 && TodayIsOptionDate)
			{
				if (RcvRangeAccrualFlag == 0 && PayRangeAccrualFlag == 0)
				{
					if (Today == OptionPayDate[nextoptidx])
					{
						if (HW2FFlag == 0)
						{
							for (idx1 = 0; idx1 < NGreed; idx1++) OptionExerciseFlag_1F[idx1] = 0;
						}
						else
						{
							for (idx1 = 0; idx1 < NGreed; idx1++) for (idx2 = 0; idx2 < NGreed; idx2++) OptionExerciseFlag_2F[idx1][idx2] = 0;
						}
					}

					t1 = t;
					t2 = ((double)DayCountAtoB(PriceDate, OptionPayDate[nextoptidx])) / 365.;
					df_T = Calc_Discount_Factor(ZeroDiscTerm, ZeroDiscRate, NZeroRate, t2);
					df_t = Calc_Discount_Factor(ZeroDiscTerm, ZeroDiscRate, NZeroRate, t1);

					LastFixingIdxRcv = -1;
					for (idx1 = 0; idx1 < NCpnDateRcv; idx1++)
					{
						if (OptionDate[nextoptidx] <= RcvPaymentDate[idx1] && RcvFixingDate[idx1] <= OptionDate[nextoptidx])
						{
							LastFixingIdxRcv = idx1;
							break;
						}
					}

					idxrcv = -1;
					if (LastFixingIdxRcv >= 0)
					{
						for (idx1 = 0; idx1 < NTotalSimul; idx1++)
						{
							if (RcvFixingDate[LastFixingIdxRcv] == TotalArrayDateSimul[idx1])
							{
								idxrcv = idx1;
								break;
							}
						}
					}

					DF_to_LastPayDate_Rcv = df_T;
					AccCpnDFRcv = df_T;
					AccZeroCpnRcv = 0.;
					if (LastFixingIdxRcv >= 0)
					{
						if (ZeroCouponFlagRcv[LastFixingIdxRcv] > 0)
						{
							// ZeroCouponCallable Swap ���� ����
							AccCpnDFRcv = Calc_Discount_Factor(ZeroDiscTerm, ZeroDiscRate, NZeroDiscRate, DayCountFractionAtoB(PriceDate, RcvPaymentDate[NCpnDateRcv - 1], 0));
							if (nextoptidx > 0)
							{
								if (ZeroCouponFlagRcv[LastFixingIdxRcv] == 1)
								{
									deltat_fixing_to_pay = (DayCountFractionAtoB(RcvFixingDate[LastFixingIdxRcv], OptionPayDate[nextoptidx - 1], 3));
									cmpv = pow(1.0 + FixedRate_Rcv[LastFixingIdxRcv], deltat_fixing_to_pay);
									AccZeroCpnRcv = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], cmpv - 1.0)), RoundingRcv);
								}
								else if (ZeroCouponFlagRcv[LastFixingIdxRcv] >= 1)
								{
									deltat_fixing_to_pay = (DayCountFractionAtoB(RcvFixingDate[LastFixingIdxRcv], OptionPayDate[nextoptidx - 1], 3));
									AccZeroCpnRcv = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], FixedRate_Rcv[LastFixingIdxRcv] * deltat_fixing_to_pay)), RoundingRcv);
								}
							}
						}

						if (HW2FFlag > 0)
						{
							if (PowerSpreadFlagRcv == 0)
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									for (idx2 = 0; idx2 < NGreed; idx2++)
									{
										Rate_Rcv = Rate_Rcv_2F[idxrcv][idx1][idx2];
										RgCpnRcv = 0.;
										if (Structured_Rcv[LastFixingIdxRcv] > 0)
										{
											Rate = SlopeOfFixingRate_Rcv[LastFixingIdxRcv] * Rate_Rcv;
											if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[LastFixingIdxRcv] * Rate_Rcv + RangeCpn_Rcv[LastFixingIdxRcv];
										}

										if (ZeroCouponFlagRcv[LastFixingIdxRcv] == 0)
										{
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv) * DeltatRcv[LastFixingIdxRcv])), RoundingRcv);
										}
										else if (ZeroCouponFlagRcv[LastFixingIdxRcv] == 1)
										{
											deltat_fixing_to_pay = (DayCountFractionAtoB(RcvFixingDate[LastFixingIdxRcv], OptionPayDate[nextoptidx], 3));
											cmpv = pow(1.0 + FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv, deltat_fixing_to_pay);
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], cmpv - 1.0)), RoundingRcv);
										}
										else
										{
											deltat_fixing_to_pay = (DayCountFractionAtoB(RcvFixingDate[LastFixingIdxRcv], OptionPayDate[nextoptidx], 3));
											cmpv = pow(1.0 + FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv, deltat_fixing_to_pay);
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
										}
										RcvLastFixingPayoff_2F[idx1][idx2] = RcvCpn;
									}
								}
							}
							else
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									for (idx2 = 0; idx2 < NGreed; idx2++)
									{
										Rate_Rcv = Rate_Rcv_2F[idxrcv][idx1][idx2];
										Rate_Rcv_p = Rate_RcvPowerSpread_2F[idxrcv][idx1][idx2];
										RgCpnRcv = 0.;
										if (Structured_Rcv[LastFixingIdxRcv] > 0)
										{
											Rate = SlopeOfFixingRate_Rcv[LastFixingIdxRcv] * (Rate_Rcv - Rate_Rcv_p);
											if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[LastFixingIdxRcv] * (Rate_Rcv - Rate_Rcv_p) + RangeCpn_Rcv[LastFixingIdxRcv];
										}

										if (ZeroCouponFlagRcv[LastFixingIdxRcv] == 0)
										{
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv) * DeltatRcv[LastFixingIdxRcv])), RoundingRcv);
										}
										else if (ZeroCouponFlagRcv[LastFixingIdxRcv] == 1)
										{
											deltat_fixing_to_pay = (DayCountFractionAtoB(RcvFixingDate[LastFixingIdxRcv], OptionPayDate[nextoptidx], 3));
											cmpv = pow(1.0 + FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv, deltat_fixing_to_pay);
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], cmpv - 1.0)), RoundingRcv);
										}
										else
										{
											deltat_fixing_to_pay = (DayCountFractionAtoB(RcvFixingDate[LastFixingIdxRcv], OptionPayDate[nextoptidx], 3));
											cmpv = pow(1.0 + FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv, deltat_fixing_to_pay);
											RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
										}
										RcvLastFixingPayoff_2F[idx1][idx2] = RcvCpn;
									}
								}
							}
						}
						else
						{
							if (PowerSpreadFlagRcv == 0)
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									Rate_Rcv = Rate_Rcv_1F[idxrcv][idx1];
									RgCpnRcv = 0.;
									if (Structured_Rcv[LastFixingIdxRcv] > 0)
									{
										Rate = SlopeOfFixingRate_Rcv[LastFixingIdxRcv] * Rate_Rcv;
										if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[LastFixingIdxRcv] * Rate_Rcv + RangeCpn_Rcv[LastFixingIdxRcv];
									}

									if (ZeroCouponFlagRcv[LastFixingIdxRcv] == 0)
									{
										RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv) * DeltatRcv[LastFixingIdxRcv])), RoundingRcv);
									}
									else if (ZeroCouponFlagRcv[LastFixingIdxRcv] == 1)
									{
										deltat_fixing_to_pay = (DayCountFractionAtoB(RcvFixingDate[LastFixingIdxRcv], OptionPayDate[nextoptidx], 3));
										cmpv = pow(1.0 + FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv, deltat_fixing_to_pay);
										RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], cmpv - 1.0)), RoundingRcv);
									}
									else
									{
										deltat_fixing_to_pay = (DayCountFractionAtoB(RcvFixingDate[LastFixingIdxRcv], OptionPayDate[nextoptidx], 3));
										cmpv = pow(1.0 + FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv, deltat_fixing_to_pay);
										RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
									}
									RcvLastFixingPayoff_1F[idx1] = RcvCpn;
								}
							}
							else
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									Rate_Rcv = Rate_Rcv_1F[idxrcv][idx1];
									Rate_Rcv_p = Rate_RcvPowerSpread_1F[idxrcv][idx1];
									RgCpnRcv = 0.;
									if (Structured_Rcv[LastFixingIdxRcv] > 0)
									{
										Rate = SlopeOfFixingRate_Rcv[LastFixingIdxRcv] * (Rate_Rcv - Rate_Rcv_p);
										if (Rate < RangeMaxMinRcv[0] && Rate > RangeMaxMinRcv[1]) RgCpnRcv = SlopeOfPayoff_Rcv[LastFixingIdxRcv] * (Rate_Rcv - Rate_Rcv_p) + RangeCpn_Rcv[LastFixingIdxRcv];
									}

									if (ZeroCouponFlagRcv[LastFixingIdxRcv] == 0)
									{
										RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv) * DeltatRcv[LastFixingIdxRcv])), RoundingRcv);
									}
									else if (ZeroCouponFlagRcv[LastFixingIdxRcv] == 1)
									{
										deltat_fixing_to_pay = (DayCountFractionAtoB(RcvFixingDate[LastFixingIdxRcv], OptionPayDate[nextoptidx], 3));
										cmpv = pow(1.0 + FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv, deltat_fixing_to_pay);
										RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], cmpv - 1.0)), RoundingRcv);
									}
									else
									{
										deltat_fixing_to_pay = (DayCountFractionAtoB(RcvFixingDate[LastFixingIdxRcv], OptionPayDate[nextoptidx], 3));
										cmpv = pow(1.0 + FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv, deltat_fixing_to_pay);
										RcvCpn = NA * rounding_double(min(MaxLossRetRcv[1], max(-MaxLossRetRcv[0], (FixedRate_Rcv[LastFixingIdxRcv] + RgCpnRcv) * deltat_fixing_to_pay)), RoundingRcv);
									}
									RcvLastFixingPayoff_1F[idx1] = RcvCpn;
								}
							}

							if (TextFlag > 0)
							{
								DumppingTextDataArray(CalcFunctionName, SaveFileName, "RcvLastFixingPayoff_1F", NGreed, RcvLastFixingPayoff_1F);
							}
						}
					}
					else
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							RcvLastFixingPayoff_1F[idx1] = 0.0;
							for (idx2 = 0; idx2 < NGreed; idx2++)
							{
								RcvLastFixingPayoff_2F[idx1][idx2] = 0.0;
							}
						}
					}

					LastFixingIdxPay = -1;
					for (idx1 = 0; idx1 < NCpnDatePay; idx1++)
					{
						if (OptionDate[nextoptidx] <= PayPaymentDate[idx1] && PayFixingDate[idx1] <= OptionDate[nextoptidx])
						{
							LastFixingIdxPay = idx1;
							break;
						}
					}

					idxpay = -1;
					if (LastFixingIdxPay >= 0)
					{
						for (idx1 = 0; idx1 < NTotalSimul; idx1++)
						{
							if (PayFixingDate[LastFixingIdxPay] == TotalArrayDateSimul[idx1])
							{
								idxpay = idx1;
								break;
							}
						}
					}

					DF_to_LastPayDate_Pay = df_T;
					AccCpnDFPay = df_T;
					AccZeroCpnPay = 0.;
					if (LastFixingIdxPay >= 0)
					{
						if (ZeroCouponFlagPay[LastFixingIdxPay] > 0)
						{
							// ZeroCouponCallable Swap ���� ����
							AccCpnDFPay = Calc_Discount_Factor(ZeroDiscTerm, ZeroDiscRate, NZeroDiscRate, DayCountFractionAtoB(PriceDate, PayPaymentDate[NCpnDatePay - 1], 0));
							if (nextoptidx > 0)
							{
								if (ZeroCouponFlagPay[LastFixingIdxPay] == 1)
								{
									deltat_fixing_to_pay = (DayCountFractionAtoB(PayFixingDate[LastFixingIdxPay], OptionPayDate[nextoptidx - 1], 3));
									cmpv = pow(1.0 + FixedRate_Pay[LastFixingIdxPay], deltat_fixing_to_pay);
									AccZeroCpnPay = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], cmpv - 1.0)), RoundingPay);
								}
								else if (ZeroCouponFlagPay[LastFixingIdxPay] >= 1)
								{
									deltat_fixing_to_pay = (DayCountFractionAtoB(PayFixingDate[LastFixingIdxPay], OptionPayDate[nextoptidx - 1], 3));
									AccZeroCpnPay = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], FixedRate_Pay[LastFixingIdxPay] * deltat_fixing_to_pay)), RoundingPay);
								}
							}

						}

						if (HW2FFlag > 0)
						{
							if (PowerSpreadFlagPay == 0)
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									for (idx2 = 0; idx2 < NGreed; idx2++)
									{
										Rate_Pay = Rate_Pay_2F[idxpay][idx1][idx2];
										RgCpnPay = 0.;
										if (Structured_Pay[LastFixingIdxPay] > 0)
										{
											Rate = SlopeOfFixingRate_Pay[LastFixingIdxPay] * Rate_Pay;
											if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[LastFixingIdxPay] * Rate_Pay + RangeCpn_Pay[LastFixingIdxPay];
										}

										if (ZeroCouponFlagPay[LastFixingIdxPay] == 0)
										{
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[LastFixingIdxPay] + RgCpnPay) * DeltatPay[LastFixingIdxPay])), RoundingPay);
										}
										else if (ZeroCouponFlagPay[LastFixingIdxPay] == 1)
										{
											deltat_fixing_to_pay = (DayCountFractionAtoB(PayFixingDate[LastFixingIdxPay], OptionPayDate[nextoptidx], 3));
											cmpv = pow(1.0 + FixedRate_Pay[LastFixingIdxPay] + RgCpnPay, deltat_fixing_to_pay);
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], cmpv - 1.0)), RoundingPay);
										}
										else
										{
											deltat_fixing_to_pay = (DayCountFractionAtoB(PayFixingDate[LastFixingIdxPay], OptionPayDate[nextoptidx], 3));
											cmpv = pow(1.0 + FixedRate_Pay[LastFixingIdxPay] + RgCpnPay, deltat_fixing_to_pay);
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[LastFixingIdxPay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
										}
										PayLastFixingPayoff_2F[idx1][idx2] = PayCpn;
									}
								}
							}
							else
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									for (idx2 = 0; idx2 < NGreed; idx2++)
									{
										Rate_Pay = Rate_Pay_2F[idxpay][idx1][idx2];
										Rate_Pay_p = Rate_PayPowerSpread_2F[idxpay][idx1][idx2];
										RgCpnPay = 0.;
										if (Structured_Pay[LastFixingIdxPay] > 0)
										{
											Rate = SlopeOfFixingRate_Pay[LastFixingIdxPay] * (Rate_Pay - Rate_Pay_p);
											if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[LastFixingIdxPay] * (Rate_Pay - Rate_Pay_p) + RangeCpn_Pay[LastFixingIdxPay];
										}

										if (ZeroCouponFlagPay[LastFixingIdxPay] == 0)
										{
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[LastFixingIdxPay] + RgCpnPay) * DeltatPay[LastFixingIdxPay])), RoundingPay);
										}
										else if (ZeroCouponFlagPay[LastFixingIdxPay] == 1)
										{
											deltat_fixing_to_pay = (DayCountFractionAtoB(PayFixingDate[LastFixingIdxPay], OptionPayDate[nextoptidx], 3));
											cmpv = pow(1.0 + FixedRate_Pay[LastFixingIdxPay] + RgCpnPay, deltat_fixing_to_pay);
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], cmpv - 1.0)), RoundingPay);
										}
										else
										{
											deltat_fixing_to_pay = (DayCountFractionAtoB(PayFixingDate[LastFixingIdxPay], OptionPayDate[nextoptidx], 3));
											cmpv = pow(1.0 + FixedRate_Pay[LastFixingIdxPay] + RgCpnPay, deltat_fixing_to_pay);
											PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[LastFixingIdxPay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
										}
										PayLastFixingPayoff_2F[idx1][idx2] = PayCpn;
									}
								}
							}
						}
						else
						{
							if (PowerSpreadFlagPay == 0)
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									Rate_Pay = Rate_Pay_1F[idxpay][idx1];
									RgCpnPay = 0.;
									if (Structured_Pay[LastFixingIdxPay] > 0)
									{
										Rate = SlopeOfFixingRate_Pay[LastFixingIdxPay] * Rate_Pay;
										if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[LastFixingIdxPay] * Rate_Pay + RangeCpn_Pay[LastFixingIdxPay];
									}

									if (ZeroCouponFlagPay[LastFixingIdxPay] == 0)
									{
										PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[LastFixingIdxPay] + RgCpnPay) * DeltatPay[LastFixingIdxPay])), RoundingPay);
									}
									else if (ZeroCouponFlagPay[LastFixingIdxPay] == 1)
									{
										deltat_fixing_to_pay = (DayCountFractionAtoB(PayFixingDate[LastFixingIdxPay], OptionPayDate[nextoptidx], 3));
										cmpv = pow(1.0 + FixedRate_Pay[LastFixingIdxPay] + RgCpnPay, deltat_fixing_to_pay);
										PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], cmpv - 1.0)), RoundingPay);
									}
									else
									{
										deltat_fixing_to_pay = (DayCountFractionAtoB(PayFixingDate[LastFixingIdxPay], OptionPayDate[nextoptidx], 3));
										cmpv = pow(1.0 + FixedRate_Pay[LastFixingIdxPay] + RgCpnPay, deltat_fixing_to_pay);
										PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[LastFixingIdxPay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
									}
									PayLastFixingPayoff_1F[idx1] = PayCpn;
								}
							}
							else
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									Rate_Pay = Rate_Pay_1F[idxpay][idx1];
									Rate_Pay_p = Rate_PayPowerSpread_1F[idxpay][idx1];
									RgCpnPay = 0.;
									if (Structured_Pay[LastFixingIdxPay] > 0)
									{
										Rate = SlopeOfFixingRate_Pay[LastFixingIdxPay] * (Rate_Pay - Rate_Pay_p);
										if (Rate < RangeMaxMinPay[0] && Rate > RangeMaxMinPay[1]) RgCpnPay = SlopeOfPayoff_Pay[LastFixingIdxPay] * (Rate_Pay - Rate_Pay_p) + RangeCpn_Pay[LastFixingIdxPay];
									}

									if (ZeroCouponFlagPay[LastFixingIdxPay] == 0)
									{
										PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[LastFixingIdxPay] + RgCpnPay) * DeltatPay[LastFixingIdxPay])), RoundingPay);
									}
									else if (ZeroCouponFlagPay[LastFixingIdxPay] == 1)
									{
										deltat_fixing_to_pay = (DayCountFractionAtoB(PayFixingDate[LastFixingIdxPay], OptionPayDate[nextoptidx], 3));
										cmpv = pow(1.0 + FixedRate_Pay[LastFixingIdxPay] + RgCpnPay, deltat_fixing_to_pay);
										PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], cmpv - 1.0)), RoundingPay);
									}
									else
									{
										deltat_fixing_to_pay = (DayCountFractionAtoB(PayFixingDate[LastFixingIdxPay], OptionPayDate[nextoptidx], 3));
										cmpv = pow(1.0 + FixedRate_Pay[LastFixingIdxPay] + RgCpnPay, deltat_fixing_to_pay);
										PayCpn = NA * rounding_double(min(MaxLossRetPay[1], max(-MaxLossRetPay[0], (FixedRate_Pay[LastFixingIdxPay] + RgCpnPay) * deltat_fixing_to_pay)), RoundingPay);
									}
									PayLastFixingPayoff_1F[idx1] = PayCpn;
								}
							}

							if (TextFlag > 0)
							{
								DumppingTextDataArray(CalcFunctionName, SaveFileName, "PayLastFixingPayoff_1F", NGreed, PayLastFixingPayoff_1F);
							}
						}
					}
					else
					{
						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							PayLastFixingPayoff_1F[idx1] = 0.0;
							for (idx2 = 0; idx2 < NGreed; idx2++)
							{
								PayLastFixingPayoff_2F[idx1][idx2] = 0.0;
							}
						}
					}

					if (HW2FFlag > 0)
					{
						if (Today == OptionPayDate[nextoptidx])
						{
							for (idx1 = 0; idx1 < NGreed; idx1++)
							{
								for (idx2 = 0; idx2 < NGreed; idx2++)
								{
									if (BondFlag == 0)
									{
										if (OptionType == 0)
										{
											if (AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_2F[idx1][idx2] - AccZeroCpnRcv) - AccZeroCpnPay * AccCpnDFPay / df_t - DF_to_LastPayDate_Pay / df_t * (PayLastFixingPayoff_2F[idx1][idx2] - AccZeroCpnPay) > FDMValue_2F[idx1][idx2]) OptionExerciseFlag_2F[idx1][idx2] = 1;
											else OptionExerciseFlag_2F[idx1][idx2] = 0;
										}
										else
										{
											if (AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_2F[idx1][idx2] - AccZeroCpnRcv) - AccZeroCpnPay * AccCpnDFPay / df_t - DF_to_LastPayDate_Pay / df_t * (PayLastFixingPayoff_2F[idx1][idx2] - AccZeroCpnPay) < FDMValue_2F[idx1][idx2]) OptionExerciseFlag_2F[idx1][idx2] = 1;
											else OptionExerciseFlag_2F[idx1][idx2] = 0;
										}
									}
									else
									{
										if (OptionType == 0)
										{
											if (AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_2F[idx1][idx2] - AccZeroCpnRcv + NA) > FDMValue_2F[idx1][idx2]) OptionExerciseFlag_2F[idx1][idx2] = 1;
											else OptionExerciseFlag_2F[idx1][idx2] = 0;
										}
										else
										{
											if (AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_2F[idx1][idx2] - AccZeroCpnRcv + NA) < FDMValue_2F[idx1][idx2]) OptionExerciseFlag_2F[idx1][idx2] = 1;
											else OptionExerciseFlag_2F[idx1][idx2] = 0;
										}

									}
								}
							}
						}

						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							for (idx2 = 0; idx2 < NGreed; idx2++)
							{
								if (OptionExerciseFlag_2F[idx1][idx2] == 1)
								{
									if (BondFlag == 0) FDMValue_2F[idx1][idx2] = AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_2F[idx1][idx2] - AccZeroCpnRcv) - AccZeroCpnPay * AccCpnDFPay / df_t - DF_to_LastPayDate_Pay / df_t * (PayLastFixingPayoff_2F[idx1][idx2] - AccZeroCpnPay);
									else FDMValue_2F[idx1][idx2] = AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_2F[idx1][idx2] - AccZeroCpnRcv) + NA;
								}
							}
						}
					}
					else
					{
						if (Today == OptionPayDate[nextoptidx])
						{
							for (idx1 = 0; idx1 < NGreed; idx1++)
							{
								if (BondFlag == 0)
								{
									if (OptionType == 0)
									{
										if (AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_1F[idx1] - AccZeroCpnRcv) - AccZeroCpnPay * AccCpnDFPay / df_t - DF_to_LastPayDate_Pay / df_t * (PayLastFixingPayoff_1F[idx1] - AccZeroCpnPay) > FDMValue_1F[idx1]) OptionExerciseFlag_1F[idx1] = 1;
										else OptionExerciseFlag_1F[idx1] = 0;
									}
									else
									{
										if (AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_1F[idx1] - AccZeroCpnRcv) - AccZeroCpnPay * AccCpnDFPay / df_t - DF_to_LastPayDate_Pay / df_t * (PayLastFixingPayoff_1F[idx1] - AccZeroCpnPay) < FDMValue_1F[idx1]) OptionExerciseFlag_1F[idx1] = 1;
										else OptionExerciseFlag_1F[idx1] = 0;
									}
								}
								else
								{
									if (OptionType == 0)
									{
										if (AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_1F[idx1] - AccZeroCpnRcv) + NA > FDMValue_1F[idx1]) OptionExerciseFlag_1F[idx1] = 1;
										else OptionExerciseFlag_1F[idx1] = 0;
									}
									else
									{
										if (AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_1F[idx1] - AccZeroCpnRcv) + NA < FDMValue_1F[idx1]) OptionExerciseFlag_1F[idx1] = 1;
										else OptionExerciseFlag_1F[idx1] = 0;
									}

								}
							}
						}

						if (TextFlag == 1)
						{
							DumppingTextData(CalcFunctionName, SaveFileName, "Today", Today);
							DumppingTextDataArray(CalcFunctionName, SaveFileName, "FDMValue_1F_OptDate_Before", NGreed, FDMValue_1F);
						}

						for (idx1 = 0; idx1 < NGreed; idx1++)
						{
							if (BondFlag == 0)
							{
								if (OptionExerciseFlag_1F[idx1] == 1) FDMValue_1F[idx1] = AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_1F[idx1] - AccZeroCpnRcv) - AccZeroCpnPay * AccCpnDFPay / df_t - DF_to_LastPayDate_Pay / df_t * (PayLastFixingPayoff_1F[idx1] - AccZeroCpnPay);
							}
							else
							{
								if (OptionExerciseFlag_1F[idx1] == 1) FDMValue_1F[idx1] = AccZeroCpnRcv * AccCpnDFRcv / df_t + DF_to_LastPayDate_Rcv / df_t * (RcvLastFixingPayoff_1F[idx1] - AccZeroCpnRcv) + NA;
							}
						}

						if (TextFlag == 1)
						{
							DumppingTextDataArray(CalcFunctionName, SaveFileName, "FDMValue_1F_OptDate", NGreed, FDMValue_1F);
						}
					}

					if (Today == min(OptionDate[nextoptidx], OptionPayDate[nextoptidx]))
					{
						nextoptidx = max(0, nextoptidx - 1);
					}
				}
				else
				{
					if (RcvRangeAccrualFlag == 1 || PayRangeAccrualFlag == 1)
					{
						if (Today == OptionPayDate[nextoptidx])
						{
							if (HW2FFlag == 0)
							{
								for (idx1 = 0; idx1 < NGreed; idx1++) OptionExerciseFlag_1F[idx1] = 0;
							}
							else
							{
								for (idx1 = 0; idx1 < NGreed; idx1++) for (idx2 = 0; idx2 < NGreed; idx2++) OptionExerciseFlag_2F[idx1][idx2] = 0;
							}
						}

						if (HW2FFlag == 1)
						{
							if (Today == OptionPayDate[nextoptidx])
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									for (idx2 = 0; idx2 < NGreed; idx2++)
									{
										if (BondFlag == 0)
										{
											if (OptionType == 0)
											{
												if (0. > FDMValue_2F[idx1][idx2]) OptionExerciseFlag_2F[idx1][idx2] = 1;
												else OptionExerciseFlag_2F[idx1][idx2] = 0;
											}
											else
											{
												if (0. < FDMValue_2F[idx1][idx2]) OptionExerciseFlag_2F[idx1][idx2] = 1;
												else OptionExerciseFlag_2F[idx1][idx2] = 0;
											}
										}
										else
										{
											if (OptionType == 0)
											{
												if (NA > FDMValue_2F[idx1][idx2]) OptionExerciseFlag_2F[idx1][idx2] = 1;
												else OptionExerciseFlag_2F[idx1][idx2] = 0;
											}
											else
											{
												if (NA < FDMValue_2F[idx1][idx2]) OptionExerciseFlag_2F[idx1][idx2] = 1;
												else OptionExerciseFlag_2F[idx1][idx2] = 0;
											}

										}
									}
								}
							}

							for (idx1 = 0; idx1 < NGreed; idx1++)
							{
								for (idx2 = 0; idx2 < NGreed; idx2++)
								{
									if (OptionExerciseFlag_2F[idx1][idx2] == 1)
									{
										if (BondFlag == 0) FDMValue_2F[idx1][idx2] = 0.;
										else FDMValue_2F[idx1][idx2] = NA;
									}
								}
							}
						}
						else
						{
							if (Today == OptionPayDate[nextoptidx])
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									if (BondFlag == 0)
									{
										if (OptionType == 0)
										{
											if (0. > FDMValue_1F[idx1]) OptionExerciseFlag_1F[idx1] = 1;
											else OptionExerciseFlag_1F[idx1] = 0;
										}
										else
										{
											if (0. < FDMValue_1F[idx1]) OptionExerciseFlag_1F[idx1] = 1;
											else OptionExerciseFlag_1F[idx1] = 0;
										}
									}
									else
									{
										if (OptionType == 0)
										{
											if (NA > FDMValue_1F[idx1]) OptionExerciseFlag_1F[idx1] = 1;
											else OptionExerciseFlag_1F[idx1] = 0;
										}
										else
										{
											if (NA < FDMValue_1F[idx1]) OptionExerciseFlag_1F[idx1] = 1;
											else OptionExerciseFlag_1F[idx1] = 0;
										}
									}
								}
							}

							if (TextFlag == 1)
							{
								DumppingTextData(CalcFunctionName, SaveFileName, "Today", Today);
								DumppingTextDataArray(CalcFunctionName, SaveFileName, "FDMValue_1F_OptDate_Before", NGreed, FDMValue_1F);
							}

							if (BondFlag == 0)
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									if (OptionExerciseFlag_1F[idx1] == 1) FDMValue_1F[idx1] = 0.;
								}
							}
							else
							{
								for (idx1 = 0; idx1 < NGreed; idx1++)
								{
									if (OptionExerciseFlag_1F[idx1] == 1) FDMValue_1F[idx1] = NA;
								}
							}

							if (TextFlag == 1)
							{
								DumppingTextDataArray(CalcFunctionName, SaveFileName, "FDMValue_1F_OptDate", NGreed, FDMValue_1F);
							}
						}

						if (Today == min(OptionDate[nextoptidx], OptionPayDate[nextoptidx]))
						{
							nextoptidx = max(0, nextoptidx - 1);
						}
					}
				}
			}
		}

		n += 1;
	}

	if (HW2FFlag == 0) ResultValue = Interpolate_Linear(xt, FDMValue_1F, NGreed, 0.0);
	else ResultValue = Calc_Volatility(NGreed, NGreed, xt, yt, FDMValue_2F, 0.0, 0.0);
	ResultFixingRateCpn[0] = ResultValue;
	double RcvValueNotOpt, PayValueNotOpt;
	RcvValueNotOpt = 0.;
	PayValueNotOpt = 0.;

	for (i = 0; i < NCpnDateRcv; i++)
	{
		t = ((double)DayCountAtoB(PriceDate, RcvPaymentDate[i]))/365.;
		RcvValueNotOpt += Calc_Discount_Factor(ZeroDiscTerm, ZeroDiscRate, NZeroDiscRate, t) * ResultFixingRateCpnRcv[NCpnDateRcv + i];
	}

	for (i = 0; i < NCpnDatePay; i++)
	{
		t = ((double)DayCountAtoB(PriceDate, PayPaymentDate[i])) / 365.;
		PayValueNotOpt += Calc_Discount_Factor(ZeroDiscTerm, ZeroDiscRate, NZeroDiscRate, t) * ResultFixingRateCpnPay[NCpnDatePay + i];
	}
	ResultFixingRateCpn[1] = RcvValueNotOpt;
	if (BondFlag == 0) ResultFixingRateCpn[2] = PayValueNotOpt;
	else ResultFixingRateCpn[2] = 0.;

	for (i = 0; i < 2; i++) free(TotalHolidays[i]);
	free(TotalHolidays);																						// �Ҵ����� 1
	for (i = 0; i < 2; i++) free(CpnDate[i]);																	// �Ҵ����� 2
	free(CpnDate);
	for (i = 0; i < 2; i++) free(CpnPayDate[i]);																// �Ҵ����� 3
	free(CpnPayDate);
	free(TotalArraySimulNotAdj);																				// �Ҵ����� 4
	free(TotalArrayDateSimul);																					// �Ҵ����� 5
	free(dtime);																								// �Ҵ����� 6
	free(Time);																									// �Ҵ����� 7
	free(xt);																									// �Ҵ����� 8
	free(yt);																									// �Ҵ����� 9

	free(RcvLastFixingPayoff_1F);																				// �Ҵ����� 10
	free(RcvLastFixingPayoff_2F_Reshaped);																		// �Ҵ����� 11
	free(RcvLastFixingPayoff_2F);																				// �Ҵ����� 12

	free(PayLastFixingPayoff_1F);																				// �Ҵ����� 13
	free(PayLastFixingPayoff_2F_Reshaped);																		// �Ҵ����� 14
	free(PayLastFixingPayoff_2F);																				// �Ҵ����� 15

	free(Rate_Rcv_1F_Reshaped);																					// �Ҵ����� 16
	free(Rate_Rcv_1F);																							// �Ҵ����� 17
	free(Rate_RcvPowerSpread_1F_Reshaped);																		// �Ҵ����� 18
	free(Rate_RcvPowerSpread_1F);																				// �Ҵ����� 19	

	free(Rate_Rcv_2F_Reshaped);																					// �Ҵ����� 20
	free(Rate_Rcv_2F_Reshaped2);																				// �Ҵ����� 21
	free(Rate_Rcv_2F);																							// �Ҵ����� 22
	free(Rate_RcvPowerSpread_2F_Reshaped);																		// �Ҵ����� 23
	free(Rate_RcvPowerSpread_2F_Reshaped2);																		// �Ҵ����� 24
	free(Rate_RcvPowerSpread_2F);																				// �Ҵ����� 25

	free(Rate_Pay_1F_Reshaped);																					// �Ҵ����� 26
	free(Rate_Pay_1F);																							// �Ҵ����� 27
	free(Rate_PayPowerSpread_1F_Reshaped);																		// �Ҵ����� 28
	free(Rate_PayPowerSpread_1F);																				// �Ҵ����� 29

	free(Rate_Pay_2F_Reshaped);																					// �Ҵ����� 30
	free(Rate_Pay_2F_Reshaped2);																				// �Ҵ����� 31
	free(Rate_Pay_2F);																							// �Ҵ����� 32
	free(Rate_PayPowerSpread_2F_Reshaped);																		// �Ҵ����� 33
	free(Rate_PayPowerSpread_2F_Reshaped2);																		// �Ҵ����� 34
	free(Rate_PayPowerSpread_2F);																				// �Ҵ����� 35

	free(Rcv_ncpn);																								// �Ҵ����� 36
	free(RcvPowerSpread_ncpn);																					// �Ҵ����� 37
	for (i = 0; i < NTotalSimul; i++)
	{
		free(Rcv_DF_t_T[i]);																					
		free(Rcv_B_t_T[i]);
		free(Rcv_QVTerm[i]);
		free(Rcv_dt[i]);
		free(RcvPowerSpread_DF_t_T[i]);
		free(RcvPowerSpread_B_t_T[i]);
		free(RcvPowerSpread_QVTerm[i]);
		free(RcvPowerSpread_dt[i]);
		free(Rcv_B_t_T_2F[i]);
		free(Rcv_QVTerm_2F[i]);
		free(RcvPowerSpread_B_t_T_2F[i]);
		free(RcvPowerSpread_QVTerm_2F[i]);
		free(Rcv_Cross_t_T_2F[i]);
		free(RcvPowerSpread_Cross_t_T_2F[i]);
	}
	free(Rcv_DF_t_T);																							// �Ҵ����� 38
	free(Rcv_B_t_T);																							// �Ҵ����� 39
	free(Rcv_QVTerm);																							// �Ҵ����� 40
	free(Rcv_dt);																								// �Ҵ����� 41
	free(RcvPowerSpread_DF_t_T);																				// �Ҵ����� 42
	free(RcvPowerSpread_B_t_T);																					// �Ҵ����� 43
	free(RcvPowerSpread_QVTerm);																				// �Ҵ����� 44
	free(RcvPowerSpread_dt);																					// �Ҵ����� 45
	free(Rcv_B_t_T_2F);																							// �Ҵ����� 46
	free(Rcv_QVTerm_2F);																						// �Ҵ����� 47
	free(RcvPowerSpread_B_t_T_2F);																				// �Ҵ����� 48
	free(RcvPowerSpread_QVTerm_2F);																				// �Ҵ����� 49
	free(Rcv_Cross_t_T_2F);																						// �Ҵ����� 50
	free(RcvPowerSpread_Cross_t_T_2F);																			// �Ҵ����� 51

	free(Pay_ncpn);																								// �Ҵ����� 52 
	free(PayPowerSpread_ncpn);																					// �Ҵ����� 53
	for (i = 0; i < NTotalSimul; i++)
	{
		free(Pay_DF_t_T[i]);
		free(Pay_B_t_T[i]);
		free(Pay_QVTerm[i]);
		free(Pay_dt[i]);
		free(PayPowerSpread_DF_t_T[i]);
		free(PayPowerSpread_B_t_T[i]);
		free(PayPowerSpread_QVTerm[i]);
		free(PayPowerSpread_dt[i]);
		free(Pay_B_t_T_2F[i]);
		free(Pay_QVTerm_2F[i]);
		free(PayPowerSpread_B_t_T_2F[i]);
		free(PayPowerSpread_QVTerm_2F[i]);
		free(Pay_Cross_t_T_2F[i]);
		free(PayPowerSpread_Cross_t_T_2F[i]);
	}
	free(Pay_DF_t_T);																							// �Ҵ����� 54
	free(Pay_B_t_T);																							// �Ҵ����� 55
	free(Pay_QVTerm);																							// �Ҵ����� 56
	free(Pay_dt);																								// �Ҵ����� 57
	free(PayPowerSpread_DF_t_T);																				// �Ҵ����� 58
	free(PayPowerSpread_B_t_T);																					// �Ҵ����� 59
	free(PayPowerSpread_QVTerm);																				// �Ҵ����� 60
	free(PayPowerSpread_dt);																					// �Ҵ����� 61
	free(Pay_B_t_T_2F);																							// �Ҵ����� 62
	free(Pay_QVTerm_2F);																						// �Ҵ����� 63
	free(PayPowerSpread_B_t_T_2F);																				// �Ҵ����� 64
	free(PayPowerSpread_QVTerm_2F);																				// �Ҵ����� 65
	free(Pay_Cross_t_T_2F);																						// �Ҵ����� 66
	free(PayPowerSpread_Cross_t_T_2F);																			// �Ҵ����� 67

	free(SlopeOfFixingRate_Rcv);																				// �Ҵ����� 68
	free(SlopeOfPayoff_Rcv);																					// �Ҵ����� 69
	free(FixedRate_Rcv);																						// �Ҵ����� 70
	free(Structured_Rcv);																						// �Ҵ����� 71
	free(RangeCpn_Rcv);																							// �Ҵ����� 72
	free(DeltatRcv);																							// �Ҵ����� 73
	free(ZeroCouponFlagRcv);																					// �Ҵ����� 74
	free(SlopeOfFixingRate_Pay);																				// �Ҵ����� 75
	free(SlopeOfPayoff_Pay);																					// �Ҵ����� 76
	free(FixedRate_Pay);																						// �Ҵ����� 77
	free(Structured_Pay);																						// �Ҵ����� 78
	free(RangeCpn_Pay);																							// �Ҵ����� 79
	free(DeltatPay);																							// �Ҵ����� 80
	free(ZeroCouponFlagPay);																					// �Ҵ����� 81

	free(Alpha_1Curve);																							// �Ҵ����� 82
	free(Beta_1Curve);																							// �Ҵ����� 83
	free(Gamma_1Curve);																							// �Ҵ����� 84
	free(Alpha_2Curve);																							// �Ҵ����� 85
	free(Beta_2Curve);																							// �Ҵ����� 86
	free(Gamma_2Curve);																							// �Ҵ����� 87
	free(FDMValue_1F);																							// �Ҵ����� 88
	free(FDMValue_2F_Reshaped);																					// �Ҵ����� 89
	free(FDMValue_2F);																							// �Ҵ����� 90
	free(RHSValue_2F_Reshaped);																					// �Ҵ����� 91
	free(RHSValue_2F);																							// �Ҵ����� 92

	free(TempAlphaArray);																						// �Ҵ����� 93
	free(TempBetaArray);																						// �Ҵ����� 94
	free(TempGammaArray);																						// �Ҵ����� 95
	free(TempCpnArrayRcv_1F);																					// �Ҵ����� 96
	free(TempCpnArrayPay_1F);																					// �Ҵ����� 97
	free(TempCpnArrayRcv_2F_Reshaped);																			// �Ҵ����� 98
	free(TempCpnArrayPay_2F_Reshaped);																			// �Ҵ����� 99
	free(TempCpnArrayRcv_2F);																					// �Ҵ����� 100										
	free(TempCpnArrayPay_2F);																					// �Ҵ����� 101

	free(OptionExerciseFlag_2F_Reshaped);																		// �Ҵ����� 102
	free(OptionExerciseFlag_2F);																				// �Ҵ����� 103
	free(OptionExerciseFlag_1F);																				// �Ҵ����� 104

	free(ForPrintVariable);																						// �Ҵ����� 105
	free(NBD_Fixing_to_End_Rcv);																				// �Ҵ����� 106
	free(NBD_Fixing_to_End_Pay);																				// �Ҵ����� 107

	//_CrtDumpMemoryLeaks();
	return 1;
}

DLLEXPORT(long) IRStructuredSwapFDM_Greek(
	long PriceDate,							// PricingDate As YYYYMMDD
	long EffectiveDate,						// EffeciveDate As YYYYMMDD
	long Maturity,							// Maturity As YYYYMMDD
	long NAFlag,							// Notional Use Flag
	double NA,								// Notional Amount

	long* NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
	long* AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
	long* NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
	long* NumCpnAnn,						// Number Coupon of 1y (len = 2)
	double* MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

	double* MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
	long* DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
	long* PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
	double* RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
	double* InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

	double RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
	double RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
	long RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
	double PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
	double PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

	long PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
	long Phase2UseFlag,						// Phase2UseFlag
	long Phase2Date,						// Phase2Date
	double Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
	double Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

	long Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
	double Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
	double Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
	long Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
	long* NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

	long NOption,							// Number of Option
	long* OptionDate,						// OptionDateArray As YYYYMMDD
	long* OptionPayDate,					// OptionPayDateArray
	long OptionType,						// 0 : Payer have option, 1: Receiver
	long NRcvRateHistory,					// Number of RcvRate History

	long* RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
	double* RcvRateHistory,					// Rcv FixingRate History Array
	long NPayRateHistory,					// Number of RcvRate History
	long* PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
	double* PayRateHistory,					// Pay FixingRate History Array

	long NZeroRate,
	double* ZeroTerm,
	double* ZeroRate,
	long NZeroDiscRate,
	double* ZeroDiscTerm,

	double* ZeroDiscRate,
	long HW2FFlag,
	long NHWVol,
	double* HWVolTerm,
	double* HWVol,

	double* kappa,
	double FactorCorrelation,
	long* RangeAccrualFlagRcvPay,
	long* InterestRateRoundingRcvPay,
	long* ResultCpnDateRcv,

	long* ResultCpnDatePay,
	double* ResultFixingRateCpn,
	double* Greek,	// Delta = (NZeroRate + NZeroDiscRate) + Gamma = (NZeroRate + NZeroDiscRate) + Vega = NHWVol + 2(For FRTBGamma)
	long GreekFlag, // 0: None Greek, 1: Greek ����
	long TextFlag
)
{
	long i, j, ResultCode;
	Preprocessing_TermAndRate(PriceDate, NZeroRate, ZeroTerm, ZeroRate);
	Preprocessing_TermAndRate(PriceDate, NZeroDiscRate, ZeroDiscTerm, ZeroDiscRate);
	double CSRUp[18] = { 0.005, 0.01, 0.05, 0.03, 0.03, 0.02, 0.015, 0.025, 0.02, 0.04, 0.12, 0.07, 0.085, 0.055, 0.05, 0.12, 0.015, 0.05 };
	double CSR_up = CSRUp[max(0,min(17, GreekFlag - 1))];
	double Price, Price2, Price3;
	long N1 = NCpnDate_Holiday_2Phase(EffectiveDate, Maturity, NumCpnAnn[0], Phase2UseFlag, NumCpnAnnPhase2RcvPay[0], Phase2Date, 1);
	long N2 = NCpnDate_Holiday_2Phase(EffectiveDate, Maturity, NumCpnAnn[1], Phase2UseFlag, NumCpnAnnPhase2RcvPay[1], Phase2Date, 1);
	long* Temp_ResultCpnDateRcv = (long*)malloc(sizeof(long) * (N1 * 8 + 1));
	long* Temp_ResultCpnDatePay = (long*)malloc(sizeof(long) * (N2 * 8 + 1));
	double* Temp_ResultFixingRateCpn = (double*)malloc(sizeof(double) * (N1 * 2 + N2 * 2 + 3));
	double* ZeroRateUp = (double*)malloc(sizeof(double) * NZeroRate);
	double* ZeroRateDn = (double*)malloc(sizeof(double) * NZeroRate);
	double* ZeroDiscRateUp = (double*)malloc(sizeof(double) * NZeroDiscRate);
	double* ZeroDiscRateDn = (double*)malloc(sizeof(double) * NZeroDiscRate);
	double* HWVolUp = (double*)malloc(sizeof(double) * NHWVol);
	ResultCode = IRStructuredSwapFDM(
		PriceDate,							// PricingDate As YYYYMMDD
		EffectiveDate,						// EffeciveDate As YYYYMMDD
		Maturity,							// Maturity As YYYYMMDD
		NAFlag,							// Notional Use Flag
		NA,								// Notional Amount

		NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
		AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
		NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
		NumCpnAnn,						// Number Coupon of 1y (len = 2)
		MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

		MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
		DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
		PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
		RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
		InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

		RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
		RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
		RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
		PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
		PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

		PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
		Phase2UseFlag,						// Phase2UseFlag
		Phase2Date,						// Phase2Date
		Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
		Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

		Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
		Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
		Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
		Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
		NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

		NOption,							// Number of Option
		OptionDate,						// OptionDateArray As YYYYMMDD
		OptionPayDate,					// OptionPayDateArray
		OptionType,						// 0 : Payer have option, 1: Receiver
		NRcvRateHistory,					// Number of RcvRate History

		RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
		RcvRateHistory,					// Rcv FixingRate History Array
		NPayRateHistory,					// Number of RcvRate History
		PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
		PayRateHistory,					// Pay FixingRate History Array

		NZeroRate,
		ZeroTerm,
		ZeroRate,
		NZeroDiscRate,
		ZeroDiscTerm,

		ZeroDiscRate,
		HW2FFlag,
		NHWVol,
		HWVolTerm,
		HWVol,

		kappa,
		FactorCorrelation,
		RangeAccrualFlagRcvPay,
		InterestRateRoundingRcvPay,
		ResultCpnDateRcv,
		ResultCpnDatePay,
		ResultFixingRateCpn,
		TextFlag
	);
	Price = ResultFixingRateCpn[0];
	if (GreekFlag)
	{
		for (i = 0; i < NZeroRate; i++)
		{
			for (j = 0; j < NZeroRate; j++)
			{
				if (i == j) ZeroRateUp[j] = ZeroRate[j] + 0.0001;
				else ZeroRateUp[j] = ZeroRate[j];

				if (i == j) ZeroRateDn[j] = ZeroRate[j] - 0.0001;
				else ZeroRateDn[j] = ZeroRate[j];
			}

			ResultCode = IRStructuredSwapFDM(
				PriceDate,							// PricingDate As YYYYMMDD
				EffectiveDate,						// EffeciveDate As YYYYMMDD
				Maturity,							// Maturity As YYYYMMDD
				NAFlag,							// Notional Use Flag
				NA,								// Notional Amount

				NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
				AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
				NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
				NumCpnAnn,						// Number Coupon of 1y (len = 2)
				MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

				MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
				DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
				PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
				RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
				InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

				RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
				RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
				RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
				PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
				PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

				PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
				Phase2UseFlag,						// Phase2UseFlag
				Phase2Date,						// Phase2Date
				Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
				Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

				Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
				Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
				Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
				Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
				NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

				NOption,							// Number of Option
				OptionDate,						// OptionDateArray As YYYYMMDD
				OptionPayDate,					// OptionPayDateArray
				OptionType,						// 0 : Payer have option, 1: Receiver
				NRcvRateHistory,					// Number of RcvRate History

				RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
				RcvRateHistory,					// Rcv FixingRate History Array
				NPayRateHistory,					// Number of RcvRate History
				PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
				PayRateHistory,					// Pay FixingRate History Array

				NZeroRate,
				ZeroTerm,
				ZeroRateUp,
				NZeroDiscRate,
				ZeroDiscTerm,

				ZeroDiscRate,
				HW2FFlag,
				NHWVol,
				HWVolTerm,
				HWVol,

				kappa,
				FactorCorrelation,
				RangeAccrualFlagRcvPay,
				InterestRateRoundingRcvPay,
				Temp_ResultCpnDateRcv,
				Temp_ResultCpnDatePay,
				Temp_ResultFixingRateCpn,
				TextFlag
			);
			Price2 = Temp_ResultFixingRateCpn[0];
			Greek[i] = (Price2 - Price);

			ResultCode = IRStructuredSwapFDM(
				PriceDate,							// PricingDate As YYYYMMDD
				EffectiveDate,						// EffeciveDate As YYYYMMDD
				Maturity,							// Maturity As YYYYMMDD
				NAFlag,							// Notional Use Flag
				NA,								// Notional Amount

				NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
				AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
				NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
				NumCpnAnn,						// Number Coupon of 1y (len = 2)
				MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

				MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
				DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
				PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
				RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
				InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

				RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
				RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
				RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
				PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
				PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

				PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
				Phase2UseFlag,						// Phase2UseFlag
				Phase2Date,						// Phase2Date
				Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
				Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

				Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
				Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
				Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
				Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
				NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

				NOption,							// Number of Option
				OptionDate,						// OptionDateArray As YYYYMMDD
				OptionPayDate,					// OptionPayDateArray
				OptionType,						// 0 : Payer have option, 1: Receiver
				NRcvRateHistory,					// Number of RcvRate History

				RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
				RcvRateHistory,					// Rcv FixingRate History Array
				NPayRateHistory,					// Number of RcvRate History
				PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
				PayRateHistory,					// Pay FixingRate History Array

				NZeroRate,
				ZeroTerm,
				ZeroRateDn,
				NZeroDiscRate,
				ZeroDiscTerm,

				ZeroDiscRate,
				HW2FFlag,
				NHWVol,
				HWVolTerm,
				HWVol,

				kappa,
				FactorCorrelation,
				RangeAccrualFlagRcvPay,
				InterestRateRoundingRcvPay,
				Temp_ResultCpnDateRcv,
				Temp_ResultCpnDatePay,
				Temp_ResultFixingRateCpn,
				TextFlag
			);
			Price3 = Temp_ResultFixingRateCpn[0];
			Greek[i + (NZeroRate + NZeroDiscRate)] = (Price2 + Price3 - 2.0 * Price);
		}

		for (i = 0; i < NZeroDiscRate; i++)
		{
			for (j = 0; j < NZeroDiscRate; j++)
			{
				if (i == j) ZeroDiscRateUp[j] = ZeroDiscRate[j] + 0.0001;
				else ZeroDiscRateUp[j] = ZeroDiscRate[j];

				if (i == j) ZeroDiscRateDn[j] = ZeroDiscRate[j] - 0.0001;
				else ZeroDiscRateDn[j] = ZeroDiscRate[j];

			}

			ResultCode = IRStructuredSwapFDM(
				PriceDate,							// PricingDate As YYYYMMDD
				EffectiveDate,						// EffeciveDate As YYYYMMDD
				Maturity,							// Maturity As YYYYMMDD
				NAFlag,							// Notional Use Flag
				NA,								// Notional Amount

				NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
				AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
				NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
				NumCpnAnn,						// Number Coupon of 1y (len = 2)
				MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

				MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
				DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
				PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
				RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
				InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

				RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
				RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
				RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
				PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
				PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

				PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
				Phase2UseFlag,						// Phase2UseFlag
				Phase2Date,						// Phase2Date
				Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
				Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

				Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
				Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
				Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
				Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
				NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

				NOption,							// Number of Option
				OptionDate,						// OptionDateArray As YYYYMMDD
				OptionPayDate,					// OptionPayDateArray
				OptionType,						// 0 : Payer have option, 1: Receiver
				NRcvRateHistory,					// Number of RcvRate History

				RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
				RcvRateHistory,					// Rcv FixingRate History Array
				NPayRateHistory,					// Number of RcvRate History
				PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
				PayRateHistory,					// Pay FixingRate History Array

				NZeroRate,
				ZeroTerm,
				ZeroRate,
				NZeroDiscRate,
				ZeroDiscTerm,

				ZeroDiscRateUp,
				HW2FFlag,
				NHWVol,
				HWVolTerm,
				HWVol,

				kappa,
				FactorCorrelation,
				RangeAccrualFlagRcvPay,
				InterestRateRoundingRcvPay,
				Temp_ResultCpnDateRcv,
				Temp_ResultCpnDatePay,
				Temp_ResultFixingRateCpn,
				TextFlag
			);
			Price2 = Temp_ResultFixingRateCpn[0];
			Greek[i + NZeroRate] = (Price2 - Price);

			ResultCode = IRStructuredSwapFDM(
				PriceDate,							// PricingDate As YYYYMMDD
				EffectiveDate,						// EffeciveDate As YYYYMMDD
				Maturity,							// Maturity As YYYYMMDD
				NAFlag,							// Notional Use Flag
				NA,								// Notional Amount

				NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
				AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
				NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
				NumCpnAnn,						// Number Coupon of 1y (len = 2)
				MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

				MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
				DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
				PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
				RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
				InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

				RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
				RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
				RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
				PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
				PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

				PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
				Phase2UseFlag,						// Phase2UseFlag
				Phase2Date,						// Phase2Date
				Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
				Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

				Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
				Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
				Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
				Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
				NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

				NOption,							// Number of Option
				OptionDate,						// OptionDateArray As YYYYMMDD
				OptionPayDate,					// OptionPayDateArray
				OptionType,						// 0 : Payer have option, 1: Receiver
				NRcvRateHistory,					// Number of RcvRate History

				RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
				RcvRateHistory,					// Rcv FixingRate History Array
				NPayRateHistory,					// Number of RcvRate History
				PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
				PayRateHistory,					// Pay FixingRate History Array

				NZeroRate,
				ZeroTerm,
				ZeroRate,
				NZeroDiscRate,
				ZeroDiscTerm,

				ZeroDiscRateDn,
				HW2FFlag,
				NHWVol,
				HWVolTerm,
				HWVol,

				kappa,
				FactorCorrelation,
				RangeAccrualFlagRcvPay,
				InterestRateRoundingRcvPay,
				Temp_ResultCpnDateRcv,
				Temp_ResultCpnDatePay,
				Temp_ResultFixingRateCpn,
				TextFlag
			);

			Price3 = Temp_ResultFixingRateCpn[0];
			Greek[i + (NZeroRate + NZeroDiscRate) + NZeroRate] = (Price2 + Price3 - 2.0 * Price);
		}

		for (i = 0; i < NHWVol; i++)
		{
			for (j = 0; j < NHWVol; j++)
			{
				if (i == j) HWVolUp[j] = HWVol[j] + 0.0001;
				else HWVolUp[j] = HWVol[j];
			}

			ResultCode = IRStructuredSwapFDM(
				PriceDate,							// PricingDate As YYYYMMDD
				EffectiveDate,						// EffeciveDate As YYYYMMDD
				Maturity,							// Maturity As YYYYMMDD
				NAFlag,							// Notional Use Flag
				NA,								// Notional Amount

				NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
				AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
				NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
				NumCpnAnn,						// Number Coupon of 1y (len = 2)
				MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

				MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
				DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
				PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
				RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
				InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

				RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
				RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
				RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
				PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
				PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

				PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
				Phase2UseFlag,						// Phase2UseFlag
				Phase2Date,						// Phase2Date
				Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
				Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

				Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
				Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
				Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
				Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
				NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

				NOption,							// Number of Option
				OptionDate,						// OptionDateArray As YYYYMMDD
				OptionPayDate,					// OptionPayDateArray
				OptionType,						// 0 : Payer have option, 1: Receiver
				NRcvRateHistory,					// Number of RcvRate History

				RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
				RcvRateHistory,					// Rcv FixingRate History Array
				NPayRateHistory,					// Number of RcvRate History
				PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
				PayRateHistory,					// Pay FixingRate History Array

				NZeroRate,
				ZeroTerm,
				ZeroRate,
				NZeroDiscRate,
				ZeroDiscTerm,

				ZeroDiscRate,
				HW2FFlag,
				NHWVol,
				HWVolTerm,
				HWVolUp,

				kappa,
				FactorCorrelation,
				RangeAccrualFlagRcvPay,
				InterestRateRoundingRcvPay,
				Temp_ResultCpnDateRcv,
				Temp_ResultCpnDatePay,
				Temp_ResultFixingRateCpn,
				TextFlag
			);
			Price2 = Temp_ResultFixingRateCpn[0];
			Greek[i + 2 * (NZeroRate + NZeroDiscRate)] = (Price2 - Price);
		}

		for (i = 0; i < NZeroRate; i++) ZeroRateUp[i] = ZeroRate[i] + 0.012020815; // FRTB Curvature Up
		for (i = 0; i < NZeroDiscRate; i++) ZeroDiscRateUp[i] = ZeroDiscRate[i] + 0.012020815;
		for (i = 0; i < NZeroRate; i++) ZeroRateDn[i] = ZeroRate[i] - 0.012020815; // FRTB Curvature Dn
		for (i = 0; i < NZeroDiscRate; i++) ZeroDiscRateDn[i] = ZeroDiscRate[i] - 0.012020815;
		ResultCode = IRStructuredSwapFDM(
			PriceDate,							// PricingDate As YYYYMMDD
			EffectiveDate,						// EffeciveDate As YYYYMMDD
			Maturity,							// Maturity As YYYYMMDD
			NAFlag,							// Notional Use Flag
			NA,								// Notional Amount

			NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
			AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
			NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
			NumCpnAnn,						// Number Coupon of 1y (len = 2)
			MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

			MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
			DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
			PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
			RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
			InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

			RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
			RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
			RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
			PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
			PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

			PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
			Phase2UseFlag,						// Phase2UseFlag
			Phase2Date,						// Phase2Date
			Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
			Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

			Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
			Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
			Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
			Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
			NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

			NOption,							// Number of Option
			OptionDate,						// OptionDateArray As YYYYMMDD
			OptionPayDate,					// OptionPayDateArray
			OptionType,						// 0 : Payer have option, 1: Receiver
			NRcvRateHistory,					// Number of RcvRate History

			RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
			RcvRateHistory,					// Rcv FixingRate History Array
			NPayRateHistory,					// Number of RcvRate History
			PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
			PayRateHistory,					// Pay FixingRate History Array

			NZeroRate,
			ZeroTerm,
			ZeroRateUp,
			NZeroDiscRate,
			ZeroDiscTerm,

			ZeroDiscRateUp,
			HW2FFlag,
			NHWVol,
			HWVolTerm,
			HWVol,

			kappa,
			FactorCorrelation,
			RangeAccrualFlagRcvPay,
			InterestRateRoundingRcvPay,
			Temp_ResultCpnDateRcv,
			Temp_ResultCpnDatePay,
			Temp_ResultFixingRateCpn,
			TextFlag
		);

		Price2 = Temp_ResultFixingRateCpn[0];
		Greek[2 * (NZeroRate + NZeroDiscRate) + NHWVol + 1] = (Price2);

		ResultCode = IRStructuredSwapFDM(
			PriceDate,							// PricingDate As YYYYMMDD
			EffectiveDate,						// EffeciveDate As YYYYMMDD
			Maturity,							// Maturity As YYYYMMDD
			NAFlag,							// Notional Use Flag
			NA,								// Notional Amount

			NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
			AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
			NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
			NumCpnAnn,						// Number Coupon of 1y (len = 2)
			MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

			MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
			DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
			PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
			RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
			InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

			RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
			RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
			RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
			PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
			PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

			PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
			Phase2UseFlag,						// Phase2UseFlag
			Phase2Date,						// Phase2Date
			Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
			Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

			Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
			Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
			Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
			Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
			NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

			NOption,							// Number of Option
			OptionDate,						// OptionDateArray As YYYYMMDD
			OptionPayDate,					// OptionPayDateArray
			OptionType,						// 0 : Payer have option, 1: Receiver
			NRcvRateHistory,					// Number of RcvRate History

			RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
			RcvRateHistory,					// Rcv FixingRate History Array
			NPayRateHistory,					// Number of RcvRate History
			PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
			PayRateHistory,					// Pay FixingRate History Array

			NZeroRate,
			ZeroTerm,
			ZeroRateDn,
			NZeroDiscRate,
			ZeroDiscTerm,

			ZeroDiscRateDn,
			HW2FFlag,
			NHWVol,
			HWVolTerm,
			HWVol,

			kappa,
			FactorCorrelation,
			RangeAccrualFlagRcvPay,
			InterestRateRoundingRcvPay,
			Temp_ResultCpnDateRcv,
			Temp_ResultCpnDatePay,
			Temp_ResultFixingRateCpn,
			TextFlag
		);

		Price2 = Temp_ResultFixingRateCpn[0];
		Greek[2 * (NZeroRate + NZeroDiscRate) + NHWVol + 2] = (Price2);

		for (i = 0; i < NZeroRate; i++) ZeroRateUp[i] = ZeroRate[i] + CSR_up; // FRTB Curvature Up
		for (i = 0; i < NZeroDiscRate; i++) ZeroDiscRateUp[i] = ZeroDiscRate[i] + CSR_up;
		for (i = 0; i < NZeroRate; i++) ZeroRateDn[i] = ZeroRate[i] - CSR_up; // FRTB Curvature Dn
		for (i = 0; i < NZeroDiscRate; i++) ZeroDiscRateDn[i] = ZeroDiscRate[i] - CSR_up;

		ResultCode = IRStructuredSwapFDM(
			PriceDate,							// PricingDate As YYYYMMDD
			EffectiveDate,						// EffeciveDate As YYYYMMDD
			Maturity,							// Maturity As YYYYMMDD
			NAFlag,							// Notional Use Flag
			NA,								// Notional Amount

			NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
			AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
			NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
			NumCpnAnn,						// Number Coupon of 1y (len = 2)
			MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

			MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
			DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
			PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
			RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
			InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

			RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
			RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
			RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
			PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
			PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

			PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
			Phase2UseFlag,						// Phase2UseFlag
			Phase2Date,						// Phase2Date
			Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
			Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

			Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
			Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
			Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
			Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
			NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

			NOption,							// Number of Option
			OptionDate,						// OptionDateArray As YYYYMMDD
			OptionPayDate,					// OptionPayDateArray
			OptionType,						// 0 : Payer have option, 1: Receiver
			NRcvRateHistory,					// Number of RcvRate History

			RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
			RcvRateHistory,					// Rcv FixingRate History Array
			NPayRateHistory,					// Number of RcvRate History
			PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
			PayRateHistory,					// Pay FixingRate History Array

			NZeroRate,
			ZeroTerm,
			ZeroRateUp,
			NZeroDiscRate,
			ZeroDiscTerm,

			ZeroDiscRateUp,
			HW2FFlag,
			NHWVol,
			HWVolTerm,
			HWVol,

			kappa,
			FactorCorrelation,
			RangeAccrualFlagRcvPay,
			InterestRateRoundingRcvPay,
			Temp_ResultCpnDateRcv,
			Temp_ResultCpnDatePay,
			Temp_ResultFixingRateCpn,
			TextFlag
		);

		Price2 = Temp_ResultFixingRateCpn[0];
		Greek[2 * (NZeroRate + NZeroDiscRate) + NHWVol + 3] = (Price2);

		ResultCode = IRStructuredSwapFDM(
			PriceDate,							// PricingDate As YYYYMMDD
			EffectiveDate,						// EffeciveDate As YYYYMMDD
			Maturity,							// Maturity As YYYYMMDD
			NAFlag,							// Notional Use Flag
			NA,								// Notional Amount

			NAdditionalHolidays,				// RcvLeg, PayLeg Additional NHolidays Custom(len = 2)
			AdditionalHolidays,				// RcvLeg, PayLeg Additional Holidays Custom(len = 2)
			NationFlag,						// RcvLeg, PayLeg Nation Flag 0 : KRW, 1 : USD, ...
			NumCpnAnn,						// Number Coupon of 1y (len = 2)
			MaxLossRetRcvPay,				// MaxLossRet of Rcv, Pay Leg (len = 4)

			MultipleRatefixPayoffRcvPay,	// Slope of Fixing And Payoff of Rcv, PayLeg(len = 4)
			DayCountRcvPay,					// DayCountFraction of Rcv, PayLeg (len = 2)
			PowerSpreadFlagRcvPay,			// PowerSpreadFlag Rcv, PayLeg (len = 2)
			RangeMaxMinRcvPay,				// FixingRate Max and Min (len = 4)
			InfoRefRateRcvPay,				// RefRate NCpnAn, T, T1, T2 of Rcv, PayLeg(len = 8)

			RcvLegFixedRate,					// Receive Leg Fixed Coupon Rate
			RcvLegRangeCoupon,				// Rcv Leg Range OK FixedCoupon Rate
			RcvLegStructuredFlag,				// Rcv Leg Structured Coupon Flag
			PayLegFixedRate,					// Pay Leg Fixed Coupon Rate
			PayLegRangeCoupon,				// Pay Leg Range OK FixedCoupon Rate

			PayLegStructuredFlag,				// Pay Leg Structured Coupon Flag
			Phase2UseFlag,						// Phase2UseFlag
			Phase2Date,						// Phase2Date
			Phase2RcvLegFixedRate,			// Receive Leg Fixed Coupon Rate
			Phase2RcvLegRangeCoupon,			// Rcv Leg Range OK FixedCoupon Rate

			Phase2RcvLegStructuredFlag,		// Rcv Leg Structured Coupon Flag
			Phase2PayLegFixedRate,			// Pay Leg Fixed Coupon Rate
			Phase2PayLegRangeCoupon,			// Pay Leg Range OK FixedCoupon Rate
			Phase2PayLegStructuredFlag,		// Pay Leg Structured Coupon Flag
			NumCpnAnnPhase2RcvPay,			// RcvPay Phase2 NumCpnAnn

			NOption,							// Number of Option
			OptionDate,						// OptionDateArray As YYYYMMDD
			OptionPayDate,					// OptionPayDateArray
			OptionType,						// 0 : Payer have option, 1: Receiver
			NRcvRateHistory,					// Number of RcvRate History

			RcvRateHistoryDate,				// Rcv FixingRate HistoryDate Array
			RcvRateHistory,					// Rcv FixingRate History Array
			NPayRateHistory,					// Number of RcvRate History
			PayRateHistoryDate,				// Pay FixingRate HistoryDate Array
			PayRateHistory,					// Pay FixingRate History Array

			NZeroRate,
			ZeroTerm,
			ZeroRateDn,
			NZeroDiscRate,
			ZeroDiscTerm,

			ZeroDiscRateDn,
			HW2FFlag,
			NHWVol,
			HWVolTerm,
			HWVol,

			kappa,
			FactorCorrelation,
			RangeAccrualFlagRcvPay,
			InterestRateRoundingRcvPay,
			Temp_ResultCpnDateRcv,
			Temp_ResultCpnDatePay,
			Temp_ResultFixingRateCpn,
			TextFlag
		);

		Price2 = Temp_ResultFixingRateCpn[0];
		Greek[2 * (NZeroRate + NZeroDiscRate) + NHWVol + 4] = (Price2);
	}

	if (Temp_ResultCpnDateRcv) free(Temp_ResultCpnDateRcv);
	if (Temp_ResultCpnDatePay) free(Temp_ResultCpnDatePay);
	if (Temp_ResultFixingRateCpn) free(Temp_ResultFixingRateCpn);
	if (ZeroRateUp) free(ZeroRateUp);
	if (ZeroRateDn) free(ZeroRateDn);
	if (ZeroDiscRateUp) free(ZeroDiscRateUp);
	if (ZeroDiscRateDn) free(ZeroDiscRateDn);
	if (HWVolUp) free(HWVolUp);
	return 1;
}

DLLEXPORT(long) FRTB_IRDelta_IRStructuredOneCurve(
	long PriceDate,
	long NZeroRate,
	double* ZeroTerm,
	double* ZeroRate,
	double* ZeroGreek,

	long NZeroDiscRate,
	double* ZeroDiscTerm,
	double* ZeroDiscRate,
	double* ZeroDiscGreek,
	
	long NHWVol,
	double* HWVolTerm1,
	double* HWVolTerm2,
	double* HWVol,
	double* HWVolGreek,
	
	double* AdjZeroTerm_10,
	double* AdjZeroGreek_10,
	double* AdjZeroDiscTerm_10,
	double* AdjZeroDiscGreek_10,
	double* AdjVegaTerm1_25,
	double* AdjVegaTerm2_25,
	double* AdjVega_25
)
{
	long i, j;
	Preprocessing_TermAndRate(PriceDate, NZeroRate, ZeroTerm, ZeroRate);
	Preprocessing_TermAndRate(PriceDate, NZeroDiscRate, ZeroDiscTerm, ZeroDiscRate);

	for (i = 0; i < NHWVol; i++) if (HWVol[i] >= 0.2) HWVol[i] /= 100.;
	AdjZeroTerm_10[0] = 0.25;
	AdjZeroTerm_10[1] = 0.5;
	AdjZeroTerm_10[2] = 1.0;
	AdjZeroTerm_10[3] = 2.0;
	AdjZeroTerm_10[4] = 3.0;
	AdjZeroTerm_10[5] = 5.0;
	AdjZeroTerm_10[6] = 10.0;
	AdjZeroTerm_10[7] = 15.0;
	AdjZeroTerm_10[8] = 20.0;
	AdjZeroTerm_10[9] = 30.0;
	for (i = 0; i < 10; i++) AdjZeroGreek_10[i] = 0.;
	for (i = 0; i < NZeroRate; i++)
	{
		if (ZeroTerm[i] < 0.259) AdjZeroGreek_10[0] += ZeroGreek[i]/0.0001;
		else if (ZeroTerm[i] < 0.59) AdjZeroGreek_10[1] += ZeroGreek[i] / 0.0001;
		else if (ZeroTerm[i] < 1.09) AdjZeroGreek_10[2] += ZeroGreek[i] / 0.0001;
		else if (ZeroTerm[i] < 2.09) AdjZeroGreek_10[3] += ZeroGreek[i] / 0.0001;
		else if (ZeroTerm[i] < 3.09) AdjZeroGreek_10[4] += ZeroGreek[i] / 0.0001;
		else if (ZeroTerm[i] < 5.09) AdjZeroGreek_10[5] += ZeroGreek[i] / 0.0001;
		else if (ZeroTerm[i] < 10.09) AdjZeroGreek_10[6] += ZeroGreek[i] / 0.0001;
		else if (ZeroTerm[i] < 15.09) AdjZeroGreek_10[7] += ZeroGreek[i] / 0.0001;
		else if (ZeroTerm[i] < 20.09) AdjZeroGreek_10[8] += ZeroGreek[i] / 0.0001;
		else AdjZeroGreek_10[9] += ZeroGreek[i] / 0.0001;
	}

	for (i = 0; i < 10; i++) AdjZeroDiscGreek_10[i] = 0.;
	for (i = 0; i < NZeroDiscRate; i++)
	{
		if (ZeroDiscTerm[i] < 0.259) AdjZeroDiscGreek_10[0] += ZeroDiscGreek[i] / 0.0001;
		else if (ZeroDiscTerm[i] < 0.59) AdjZeroDiscGreek_10[1] += ZeroDiscGreek[i] / 0.0001;
		else if (ZeroDiscTerm[i] < 1.09) AdjZeroDiscGreek_10[2] += ZeroDiscGreek[i] / 0.0001;
		else if (ZeroDiscTerm[i] < 2.09) AdjZeroDiscGreek_10[3] += ZeroDiscGreek[i] / 0.0001;
		else if (ZeroDiscTerm[i] < 3.09) AdjZeroDiscGreek_10[4] += ZeroDiscGreek[i] / 0.0001;
		else if (ZeroDiscTerm[i] < 5.09) AdjZeroDiscGreek_10[5] += ZeroDiscGreek[i] / 0.0001;
		else if (ZeroDiscTerm[i] < 10.09) AdjZeroDiscGreek_10[6] += ZeroDiscGreek[i] / 0.0001;
		else if (ZeroDiscTerm[i] < 15.09) AdjZeroDiscGreek_10[7] += ZeroDiscGreek[i] / 0.0001;
		else if (ZeroDiscTerm[i] < 20.09) AdjZeroDiscGreek_10[8] += ZeroDiscGreek[i] / 0.0001;
		else AdjZeroDiscGreek_10[9] += ZeroDiscGreek[i] / 0.0001;
	}

	for (i = 0; i < 25; i++) AdjVega_25[i] = 0.;
	for (i = 0; i < NHWVol; i++)
	{
		if (HWVolTerm1[i] < 0.59)
		{
			if (HWVolTerm2[i] < 0.59) AdjVega_25[0] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 1.09) AdjVega_25[1] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 3.09) AdjVega_25[2] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 5.09) AdjVega_25[3] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else AdjVega_25[4] += HWVolGreek[i] / 0.0001 * HWVol[i];
		}
		else if (HWVolTerm1[i] < 1.09)
		{
			if (HWVolTerm2[i] < 0.59) AdjVega_25[5] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 1.09) AdjVega_25[6] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 3.09) AdjVega_25[7] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 5.09) AdjVega_25[8] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else AdjVega_25[9] += HWVolGreek[i] / 0.0001 * HWVol[i];
		}
		else if (HWVolTerm1[i] < 3.09)
		{
			if (HWVolTerm2[i] < 0.59) AdjVega_25[10] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 1.09) AdjVega_25[11] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 3.09) AdjVega_25[12] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 5.09) AdjVega_25[13] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else AdjVega_25[14] += HWVolGreek[i] / 0.0001 * HWVol[i];
		}
		else if (HWVolTerm1[i] < 5.09)
		{
			if (HWVolTerm2[i] < 0.59) AdjVega_25[15] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 1.09) AdjVega_25[16] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 3.09) AdjVega_25[17] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 5.09) AdjVega_25[18] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else AdjVega_25[19] += HWVolGreek[i] / 0.0001 * HWVol[i];
		}
		else
		{
			if (HWVolTerm2[i] < 0.59) AdjVega_25[20] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 1.09) AdjVega_25[21] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 3.09) AdjVega_25[22] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else if (HWVolTerm2[i] < 5.09) AdjVega_25[23] += HWVolGreek[i] / 0.0001 * HWVol[i];
			else AdjVega_25[24] += HWVolGreek[i] / 0.0001 * HWVol[i];
		}
	}

	AdjVegaTerm1_25[0] = 0.5;
	AdjVegaTerm1_25[1] = 0.5;
	AdjVegaTerm1_25[2] = 0.5;
	AdjVegaTerm1_25[3] = 0.5;
	AdjVegaTerm1_25[4] = 0.5;
	AdjVegaTerm1_25[5] = 1.0;
	AdjVegaTerm1_25[6] = 1.0;
	AdjVegaTerm1_25[7] = 1.0;
	AdjVegaTerm1_25[8] = 1.0;
	AdjVegaTerm1_25[9] = 1.0;
	AdjVegaTerm1_25[10] = 3.0;
	AdjVegaTerm1_25[11] = 3.0;
	AdjVegaTerm1_25[12] = 3.0;
	AdjVegaTerm1_25[13] = 3.0;
	AdjVegaTerm1_25[14] = 3.0;
	AdjVegaTerm1_25[15] = 5.0;
	AdjVegaTerm1_25[16] = 5.0;
	AdjVegaTerm1_25[17] = 5.0;
	AdjVegaTerm1_25[18] = 5.0;
	AdjVegaTerm1_25[19] = 5.0;
	AdjVegaTerm1_25[20] = 10.0;
	AdjVegaTerm1_25[21] = 10.0;
	AdjVegaTerm1_25[22] = 10.0;
	AdjVegaTerm1_25[23] = 10.0;
	AdjVegaTerm1_25[24] = 10.0;

	AdjVegaTerm2_25[0] = 0.5;
	AdjVegaTerm2_25[1] = 1.0;
	AdjVegaTerm2_25[2] = 3.0;
	AdjVegaTerm2_25[3] = 5.0;
	AdjVegaTerm2_25[4] = 10.0;
	AdjVegaTerm2_25[5] = 0.5;
	AdjVegaTerm2_25[6] = 1.0;
	AdjVegaTerm2_25[7] = 3.0;
	AdjVegaTerm2_25[8] = 5.0;
	AdjVegaTerm2_25[9] = 10.0;
	AdjVegaTerm2_25[10] = 0.5;
	AdjVegaTerm2_25[11] = 1.0;
	AdjVegaTerm2_25[12] = 3.0;
	AdjVegaTerm2_25[13] = 5.0;
	AdjVegaTerm2_25[14] = 10.0;
	AdjVegaTerm2_25[15] = 0.5;
	AdjVegaTerm2_25[16] = 1.0;
	AdjVegaTerm2_25[17] = 3.0;
	AdjVegaTerm2_25[18] = 5.0;
	AdjVegaTerm2_25[19] = 10.0;
	AdjVegaTerm2_25[20] = 0.5;
	AdjVegaTerm2_25[21] = 1.0;
	AdjVegaTerm2_25[22] = 3.0;
	AdjVegaTerm2_25[23] = 5.0;
	AdjVegaTerm2_25[24] = 10.0;
	return 1;
}

/*int main()
{
	long i, j, n;
	long PriceDate = 20240727;
	long EffectiveDate = 20240727;
	long Maturity = 20340731;
	long NAFlag = 0;
	double NA = 10000.0;
	long NAdditionalHolidays[2] = { 1, 2 };
	long AddtionalHolidays[3] = { 20240101, 20240101, 20241225 };
	long NationFlag[2] = { 0, 0 };
	long NumCpnAnn[2] = { 4, 4 };
	long NumCpnAnnPhase2[2] = { 4,4 };
	double MaxLossRetRcvPay[4] = { 0.0, 0.99, 0.00, 0.99 };
	double MultipleRatefixPayoffRcvPay[4] = { 1.0, 1.0, 0.0, 0.0 };
	long DayCountRcvPay[2] = { 0, 0 };
	long PowerSpreadFlagRcvPay[2] = { 0, 0 };
	double RangeMaxMinRcvPay[4] = { 100.0, -1.0, 100.0, -1.0 };
	double InfoRefRateRcvPay[8] = { 4.0, 0.25, 10.0, 5.0, 4.0, 0.25, 30.0, 10.0 };

	double RcvLegFixedRate = 0.00;
	double RcvLegRangeCoupon = 0.00;
	long RcvLegStructuredFlag = 1;
	double PayLegFixedRate = 0.04;
	double PayLegRangeCoupon = 0.0;
	long PayLegStructuredFlag = 0;

	long Phase2UseFlag = 1;
	long Phase2Date = 20290727;
	double Phase2RcvLegFixedRate = 0.00;
	double Phase2RcvLegRangeCoupon = 0.00;
	long Phase2RcvLegStructuredFlag = 1;
	double Phase2PayLegFixedRate = 0.04;
	double Phase2PayLegRangeCoupon = 0.0;
	long Phase2PayLegStructuredFlag = 0;

	long NOption = 0;
	long OptionDate[2] = { 20250727, 20260727 };
	long OptionPayDate[2] = { 20250729, 20260729 };
	long OptionType = 1;

	long NRcvRateHistory = 2;
	long RcvRateHistoryDate[2] = { 20220819, 20220820 };
	double RcvRateHistory[2] = { 0.03914, 0.0392 };

	long NPayRateHistory = 1;
	long PayRateHistoryDate[1] = { 20220819 };
	double PayRateHistory[1] = { 0.0304 };

	long NZeroEstRate = 4;
	double ZeroEstTerm[4] = { 0.5, 1.0, 1.5, 2.0 };
	double ZeroEstRate[4] = { 0.0379, 0.0387, 0.0392, 0.0412 };
	long NZeroDiscRate = 4;
	double ZeroDiscTerm[4] = { 0.5, 1.0, 1.5, 2.0 };
	double ZeroDiscRate[4] = { 0.0379, 0.0387, 0.0392, 0.0412 };

	long HW2FFlag = 0;
	long NHWVol = 5;
	double HWVolTerm[5] = { 0.5, 1.0, 1.5, 2.0, 3.0 };
	double HWVol[10] = { 0.0096, 0.0111, 0.0112, 0.0112,0.0114,0.0052,0.0046,0.0066,0.0062,0.0061 };
	double kappa[2] = { 0.07, 0.011 };
	double FactorCorrelation = 0.132;
	long NCpn[2] = { 0.0 };

	long tempn1, tempn2;
	tempn1 = Number_of_Coupons(1, CDateToExcelDate(EffectiveDate), CDateToExcelDate(Maturity), NumCpnAnn[0], 0, 0, 0, 0);
	NCpn[0] = NCpnDate_Holiday_2Phase(EffectiveDate, Maturity, NumCpnAnn[0], 1, NumCpnAnnPhase2[0], Phase2Date);

	tempn2 = Number_of_Coupons(1, CDateToExcelDate(EffectiveDate), CDateToExcelDate(Maturity), NumCpnAnn[1], 0, 0, 0, 0);
	NCpn[1] = NCpnDate_Holiday_2Phase(EffectiveDate, Maturity, NumCpnAnn[1], 1, NumCpnAnnPhase2[1], Phase2Date);

	long* ResultCpnDateRcv = (long*)malloc(sizeof(long) * NCpn[0] * 5);
	long* ResultCpnDatePay = (long*)malloc(sizeof(long) * NCpn[1] * 5);
	double* ResultFixingRateCpn = (double*)malloc(sizeof(double) * (NCpn[0] * 2 + NCpn[1] * 2 + 1));

	IRStructuredSwapFDM(PriceDate, EffectiveDate, Maturity, NAFlag, NA,
		NAdditionalHolidays, NAdditionalHolidays, NationFlag, NumCpnAnn, MaxLossRetRcvPay,
		MultipleRatefixPayoffRcvPay, DayCountRcvPay, PowerSpreadFlagRcvPay, RangeMaxMinRcvPay, InfoRefRateRcvPay,
		RcvLegFixedRate, RcvLegRangeCoupon, RcvLegStructuredFlag, PayLegFixedRate, PayLegRangeCoupon,
		PayLegStructuredFlag, Phase2UseFlag, Phase2Date, Phase2RcvLegFixedRate, Phase2RcvLegRangeCoupon,
		Phase2RcvLegStructuredFlag, Phase2PayLegFixedRate, Phase2PayLegRangeCoupon, Phase2PayLegStructuredFlag, NumCpnAnnPhase2,
		NOption, OptionDate, OptionPayDate, OptionType, NRcvRateHistory,
		RcvRateHistoryDate, RcvRateHistory, NPayRateHistory, PayRateHistoryDate, PayRateHistory,
		NZeroEstRate, ZeroEstTerm, ZeroEstRate, NZeroDiscRate, ZeroDiscTerm, ZeroDiscRate,
		HW2FFlag, NHWVol, HWVolTerm, HWVol, kappa,
		FactorCorrelation, ResultCpnDateRcv, ResultCpnDatePay, ResultFixingRateCpn
	);
	free(ResultCpnDateRcv);
	free(ResultCpnDatePay);
	free(ResultFixingRateCpn);
	_CrtDumpMemoryLeaks();
}*/